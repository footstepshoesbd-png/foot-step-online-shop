import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext.tsx';
import { Header } from './components/customer/Header.tsx';
import { HeroSlider } from './components/customer/HeroSlider.tsx';
import { CategoriesBar } from './components/customer/CategoriesBar.tsx';
import { ProductList } from './components/customer/ProductList.tsx';
import { CartDrawer } from './components/customer/CartDrawer.tsx';
import { CheckoutModal } from './components/customer/CheckoutModal.tsx';
import { OrderSuccessModal } from './components/customer/OrderSuccessModal.tsx';
import { TrackOrderModal } from './components/customer/TrackOrderModal.tsx';
import { CustomerReviewsSection } from './components/customer/CustomerReviewsSection.tsx';
import { AboutAndContactSection } from './components/customer/AboutAndContactSection.tsx';
import { Footer } from './components/customer/Footer.tsx';
import { FloatingButtons } from './components/customer/FloatingButtons.tsx';
import { AdminLayout } from './components/admin/AdminLayout.tsx';
import { ShieldCheck, Truck, RefreshCw, Award, ArrowRight, Zap, Sparkles } from 'lucide-react';

const CustomerStorefront: React.FC = () => {
  const { sections, deliverySettings, setIsCheckoutOpen } = useStore();

  // Sort visible sections
  const visibleSections = [...sections]
    .filter((s) => s.isVisible)
    .sort((a, b) => a.order - b.order);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans">
      <Header />

      <main className="flex-1">
        {visibleSections.map((sec) => {
          switch (sec.key) {
            case 'hero':
              return <HeroSlider key={sec.id} />;

            case 'categories':
              return <CategoriesBar key={sec.id} />;

            case 'features':
              return (
                <section key={sec.id} id="features" className="py-12 bg-white border-b border-slate-100">
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center max-w-xl mx-auto mb-8">
                      <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">
                        আমাদের অঙ্গীকার
                      </span>
                      <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-1">
                        {sec.title || 'কেন FOOT STEPS SHOES নির্বাচন করবেন'}
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-500 mt-1">
                        {sec.subtitle || 'আমরা দিচ্ছি সেরা গুণগত মান ও সর্বোচ্চ গ্রাহক সেবা'}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {/* 1 */}
                      <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/90 hover:border-emerald-300 transition-colors flex items-start gap-3.5">
                        <div className="p-3 rounded-xl bg-emerald-100 text-emerald-800 shrink-0">
                          <ShieldCheck className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="font-bold text-slate-900 text-sm">১০০% অরিজিনাল লেদার</h3>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                            কোনো কৃত্রিম রেক্সিন নয়, খাঁটি গরুর চামড়া দিয়ে তৈরি প্রিমিয়াম ফুটওয়্যার।
                          </p>
                        </div>
                      </div>

                      {/* 2 */}
                      <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/90 hover:border-emerald-300 transition-colors flex items-start gap-3.5">
                        <div className="p-3 rounded-xl bg-emerald-100 text-emerald-800 shrink-0">
                          <Truck className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="font-bold text-slate-900 text-sm">ফেনী সিটিতে হোম ডেলিভারি</h3>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                            ডেলিভারি চার্জ মাত্র ৳{deliverySettings?.feniCityCharge || 80}! ২৪-৪৮ ঘণ্টায় বাসায় পৌঁছে যাবে।
                          </p>
                        </div>
                      </div>

                      {/* 3 */}
                      <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/90 hover:border-emerald-300 transition-colors flex items-start gap-3.5">
                        <div className="p-3 rounded-xl bg-emerald-100 text-emerald-800 shrink-0">
                          <RefreshCw className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="font-bold text-slate-900 text-sm">৭ দিন সাইজ এক্সচেঞ্জ</h3>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                            সাইজে কোনো সমস্যা হলে ৭ দিনের মধ্যে কোনো ঝামেলা ছাড়াই পরিবর্তনযোগ্য।
                          </p>
                        </div>
                      </div>

                      {/* 4 */}
                      <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/90 hover:border-emerald-300 transition-colors flex items-start gap-3.5">
                        <div className="p-3 rounded-xl bg-emerald-100 text-emerald-800 shrink-0">
                          <Award className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="font-bold text-slate-900 text-sm">ক্যাশ অন ডেলিভারি</h3>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                            সারা দেশে পণ্য হাতে পেয়ে চেক করে মূল্য পরিশোধের ১০০% নিশ্চয়তা।
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              );

            case 'products':
              return <ProductList key={sec.id} />;

            case 'deal':
              return (
                <section key={sec.id} className="py-12 bg-gradient-to-r from-emerald-900 via-emerald-800 to-emerald-950 text-white relative overflow-hidden">
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
                    <div className="max-w-xl text-center md:text-left">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400 text-emerald-950 text-xs font-black mb-3">
                        <Sparkles className="w-3.5 h-3.5" />
                        লিমিটেড টাইম স্পেশাল ধামাকা অফার
                      </span>
                      <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight leading-tight">
                        ২,৫০০ টাকার অর্ডারে সারা দেশে সম্পূর্ণ ফ্রি ডেলিভারি!
                      </h2>
                      <p className="text-xs sm:text-sm text-emerald-100 mt-2 font-medium">
                        ফেনী সিটিতে হোম ডেলিভারি মাত্র ৮০ টাকা। আপনার পছন্দের চামড়ার জুতো এখনই অর্ডার করে দ্রুততম ডেলিভারি বুঝে নিন।
                      </p>
                    </div>

                    <a
                      href="#products"
                      className="px-8 py-4 bg-white text-emerald-900 hover:bg-emerald-50 rounded-2xl font-black text-sm sm:text-base shadow-2xl transition-all active:scale-95 flex items-center gap-2 shrink-0"
                    >
                      <span>এখনই কালেকশন দেখুন</span>
                      <ArrowRight className="w-4 h-4 text-emerald-700" />
                    </a>
                  </div>
                </section>
              );

            case 'reviews':
              return <CustomerReviewsSection key={sec.id} />;

            case 'about':
            case 'contact':
              // Handled combined in AboutAndContactSection
              return <AboutAndContactSection key={sec.id} />;

            default:
              return null;
          }
        })}
      </main>

      <Footer />

      {/* Shared Modals */}
      <CartDrawer />
      <CheckoutModal />
      <OrderSuccessModal />
      <TrackOrderModal />
      <FloatingButtons />
    </div>
  );
};

const RootApp: React.FC = () => {
  const { isAdminOpen } = useStore();

  if (isAdminOpen) {
    return <AdminLayout />;
  }

  return <CustomerStorefront />;
};

export default function App() {
  return (
    <StoreProvider>
      <RootApp />
    </StoreProvider>
  );
}
