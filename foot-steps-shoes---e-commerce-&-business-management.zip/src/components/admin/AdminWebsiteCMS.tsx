import React, { useState } from 'react';
import {
  Globe,
  Sliders,
  Image as ImageIcon,
  Layers,
  FileText,
  Phone,
  MessageCircle,
  Share2,
  Palette,
  Search,
  Check,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  Star,
  Save,
  AlertCircle
} from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';
import { Banner, WebsiteSection, Category, CustomerReview } from '../../types/index.ts';

export const AdminWebsiteCMS: React.FC = () => {
  const {
    settings,
    sections,
    banners,
    categories,
    reviews,
    refreshData,
    updateSettingsState
  } = useStore();

  const [activeTab, setActiveTab] = useState<
    'general' | 'banners' | 'sections' | 'categories' | 'about' | 'contact' | 'theme' | 'seo' | 'announcement'
  >('general');

  // Form states initialized from settings
  const [formData, setFormData] = useState({
    brandName: settings?.brandName || 'FOOT STEPS SHOES',
    brandTagline: settings?.brandTagline || 'ফেনীর সেরা প্রিমিয়াম লেদার কালেকশন',
    websiteTitle: settings?.websiteTitle || 'FOOT STEPS SHOES - প্রিমিয়াম জুতোর বিশ্বস্ত ঠিকানা',
    metaDescription: settings?.metaDescription || '',
    keywords: settings?.keywords || '',
    logoUrl: settings?.logoUrl || '',
    primaryColor: settings?.primaryColor || '#047857',
    accentColor: settings?.accentColor || '#10B981',
    shopAddress: settings?.shopAddress || '',
    shopCity: settings?.shopCity || 'ফেনী',
    openingHours: settings?.openingHours || '',
    phoneNumber: settings?.phoneNumber || '',
    secondaryPhone: settings?.secondaryPhone || '',
    whatsappNumber: settings?.whatsappNumber || '',
    email: settings?.email || '',
    facebookUrl: settings?.facebookUrl || '',
    instagramUrl: settings?.instagramUrl || '',
    youtubeUrl: settings?.youtubeUrl || '',
    tiktokUrl: settings?.tiktokUrl || '',
    announcementText: settings?.announcementText || '',
    announcementActive: settings?.announcementActive !== undefined ? settings.announcementActive : true,
    footerAbout: settings?.footerAbout || '',
    copyrightText: settings?.copyrightText || '',
    aboutTitle: settings?.aboutUsContent?.title || '',
    aboutDesc: settings?.aboutUsContent?.description || '',
    aboutExp: settings?.aboutUsContent?.experienceYears || '১০+ বছর',
    aboutHappy: settings?.aboutUsContent?.happyCustomers || '১৫,০০০+',
    aboutImage: settings?.aboutUsContent?.image || ''
  });

  const [saving, setSaving] = useState(false);
  const [successToast, setSuccessToast] = useState(false);

  // New Banner Modal state
  const [bannerModalOpen, setBannerModalOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [bannerForm, setBannerForm] = useState({
    title: '',
    subtitle: '',
    tag: '',
    image: '',
    ctaText: 'অর্ডার করুন',
    ctaLink: '#products'
  });

  // Category Modal state
  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [categoryForm, setCategoryForm] = useState({
    name: '',
    banglaName: '',
    icon: 'Footprints'
  });

  const handleGeneralSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      await api.updateGeneralSettings({
        brandName: formData.brandName,
        brandTagline: formData.brandTagline,
        websiteTitle: formData.websiteTitle,
        metaDescription: formData.metaDescription,
        keywords: formData.keywords,
        logoUrl: formData.logoUrl,
        primaryColor: formData.primaryColor,
        accentColor: formData.accentColor,
        shopAddress: formData.shopAddress,
        shopCity: formData.shopCity,
        openingHours: formData.openingHours,
        phoneNumber: formData.phoneNumber,
        secondaryPhone: formData.secondaryPhone,
        whatsappNumber: formData.whatsappNumber,
        email: formData.email,
        facebookUrl: formData.facebookUrl,
        instagramUrl: formData.instagramUrl,
        youtubeUrl: formData.youtubeUrl,
        tiktokUrl: formData.tiktokUrl,
        announcementText: formData.announcementText,
        announcementActive: formData.announcementActive,
        footerAbout: formData.footerAbout,
        copyrightText: formData.copyrightText,
        aboutUsContent: {
          title: formData.aboutTitle,
          description: formData.aboutDesc,
          experienceYears: formData.aboutExp,
          happyCustomers: formData.aboutHappy,
          qualityGuarantee: '১০০% অরিজিনাল লেদার',
          image: formData.aboutImage
        }
      });
      updateSettingsState(formData);
      setSuccessToast(true);
      setTimeout(() => setSuccessToast(false), 2000);
      await refreshData();
    } catch (err) {
      console.error(err);
      alert('সেটিংস সংরক্ষণ করতে সমস্যা হয়েছে');
    } finally {
      setSaving(false);
    }
  };

  // Section toggle & reorder
  const handleToggleSection = async (secId: string) => {
    const updated = sections.map((s) => (s.id === secId ? { ...s, isVisible: !s.isVisible } : s));
    await api.updateSections(updated);
    await refreshData();
  };

  const handleMoveSection = async (index: number, direction: 'up' | 'down') => {
    const newIdx = direction === 'up' ? index - 1 : index + 1;
    if (newIdx < 0 || newIdx >= sections.length) return;
    const clone = [...sections];
    const temp = clone[index];
    clone[index] = clone[newIdx];
    clone[newIdx] = temp;
    // update orders
    const reordered = clone.map((s, i) => ({ ...s, order: i + 1 }));
    await api.updateSections(reordered);
    await refreshData();
  };

  // Banner Actions
  const handleOpenBannerModal = (banner?: Banner) => {
    if (banner) {
      setEditingBanner(banner);
      setBannerForm({
        title: banner.title,
        subtitle: banner.subtitle,
        tag: banner.tag || '',
        image: banner.image,
        ctaText: banner.ctaText,
        ctaLink: banner.ctaLink
      });
    } else {
      setEditingBanner(null);
      setBannerForm({
        title: 'নতুন ধামাকা অফার কালেকশন',
        subtitle: 'হাতে তৈরি ১০০% অরিজিনাল লেদার জুতো',
        tag: '🔥 হট অফার',
        image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1200',
        ctaText: 'অর্ডার করুন',
        ctaLink: '#products'
      });
    }
    setBannerModalOpen(true);
  };

  const handleSaveBanner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingBanner) {
      await api.updateBanner(editingBanner.id, bannerForm);
    } else {
      await api.createBanner(bannerForm);
    }
    setBannerModalOpen(false);
    await refreshData();
  };

  const handleDeleteBanner = async (id: string) => {
    if (!confirm('আপনি কি নিশ্চিত যে এই ব্যানারটি মুছে ফেলতে চান?')) return;
    await api.deleteBanner(id);
    await refreshData();
  };

  // Category Actions
  const handleOpenCategoryModal = (cat?: Category) => {
    if (cat) {
      setEditingCategory(cat);
      setCategoryForm({
        name: cat.name,
        banglaName: cat.banglaName,
        icon: cat.icon || 'Footprints'
      });
    } else {
      setEditingCategory(null);
      setCategoryForm({
        name: 'New Category',
        banglaName: 'নতুন ক্যাটাগরি',
        icon: 'Footprints'
      });
    }
    setCategoryModalOpen(true);
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCategory) {
      await api.updateCategory(editingCategory.id, categoryForm);
    } else {
      await api.createCategory(categoryForm);
    }
    setCategoryModalOpen(false);
    await refreshData();
  };

  const handleDeleteCategory = async (id: string) => {
    if (!confirm('আপনি কি নিশ্চিত যে এই ক্যাটাগরি মুছে ফেলতে চান?')) return;
    await api.deleteCategory(id);
    await refreshData();
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            ওয়েবসাইট কন্টেন্ট ও CMS নিয়ন্ত্রণ
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            ওয়েবসাইটের লোগো, নাম, ব্যানার, সেকশন, এবাউট এবং যোগাযোগ তথ্য পরিবর্তন করুন
          </p>
        </div>

        {successToast && (
          <div className="px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl shadow-lg flex items-center gap-2 animate-in fade-in">
            <Check className="w-4 h-4" />
            <span>সফলভাবে ডাটাবেজে সেভ হয়েছে!</span>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1.5 bg-slate-100 rounded-2xl border border-slate-200">
        {[
          { id: 'general', label: 'ব্র্যান্ড ও লোগো', icon: Globe },
          { id: 'banners', label: 'হিরো স্লাইডার ব্যানার', icon: ImageIcon },
          { id: 'sections', label: 'হোমপেজ সেকশন নিয়ন্ত্রণ', icon: Layers },
          { id: 'categories', label: 'ক্যাটাগরি সমূহ', icon: Sliders },
          { id: 'announcement', label: 'প্রমোশনাল নোটিশ', icon: MessageCircle },
          { id: 'about', label: 'আমাদের গল্প ও শোরুম', icon: FileText },
          { id: 'contact', label: 'ঠিকানা ও ফোন হটলাইন', icon: Phone },
          { id: 'theme', label: 'কালার ও সোশ্যাল মিডিয়া', icon: Palette },
          { id: 'seo', label: 'SEO ও মেটা ট্যাগ', icon: Search }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === tab.id
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-emerald-800 hover:bg-white/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. General Info & Brand Tab */}
      {activeTab === 'general' && (
        <form onSubmit={handleGeneralSave} className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2">
            ব্র্যান্ডিং ও সাধারণ তথ্য
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ব্র্যান্ডের নাম (Brand Name) *
              </label>
              <input
                type="text"
                required
                value={formData.brandName}
                onChange={(e) => setFormData({ ...formData, brandName: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:bg-white focus:border-emerald-600 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ওয়েবসাইটের ট্যাগলাইন (Tagline)
              </label>
              <input
                type="text"
                value={formData.brandTagline}
                onChange={(e) => setFormData({ ...formData, brandTagline: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ওয়েবসাইট টাইটেল (Browser Tab Title)
              </label>
              <input
                type="text"
                value={formData.websiteTitle}
                onChange={(e) => setFormData({ ...formData, websiteTitle: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                লোগো ইমেজ লিঙ্ক (Logo Image URL)
              </label>
              <input
                type="text"
                value={formData.logoUrl}
                onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              ফুটার সংক্ষিপ্ত পরিচয় (Footer About Snippet)
            </label>
            <textarea
              rows={3}
              value={formData.footerAbout}
              onChange={(e) => setFormData({ ...formData, footerAbout: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              কপিরাইট টেক্সট (Copyright Notice)
            </label>
            <input
              type="text"
              value={formData.copyrightText}
              onChange={(e) => setFormData({ ...formData, copyrightText: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'সেটিংস সেভ করুন'}</span>
            </button>
          </div>
        </form>
      )}

      {/* 2. Banners & Sliders Tab */}
      {activeTab === 'banners' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
                হোমপেজ স্লাইডার ব্যানার ({banners.length})
              </h3>
              <p className="text-xs text-slate-500">
                ব্যানারের ছবি, শিরোনাম, সাবটাইটেল এবং বোতামের লিঙ্ক পরিবর্তন বা নতুন ব্যানার যোগ করুন
              </p>
            </div>
            <button
              onClick={() => handleOpenBannerModal()}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Plus className="w-4 h-4" />
              নতুন ব্যানার যোগ
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {banners.map((b, idx) => (
              <div
                key={b.id}
                className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-50 flex flex-col justify-between"
              >
                <div className="relative aspect-16/9 bg-slate-900">
                  <img src={b.image} alt={b.title} className="w-full h-full object-cover opacity-80" />
                  <div className="absolute top-2 left-2 flex gap-1">
                    <span className="px-2 py-0.5 bg-black/60 text-white font-bold text-[10px] rounded backdrop-blur-xs">
                      #{idx + 1}
                    </span>
                    {b.tag && (
                      <span className="px-2 py-0.5 bg-emerald-600 text-white font-bold text-[10px] rounded">
                        {b.tag}
                      </span>
                    )}
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{b.title}</h4>
                    <p className="text-xs text-slate-500 line-clamp-2 mt-1">{b.subtitle}</p>
                    <span className="inline-block mt-2 text-[11px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-mono">
                      CTA: {b.ctaText} ({b.ctaLink})
                    </span>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between">
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                        b.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {b.isActive ? 'সক্রিয়' : 'নিষ্ক্রিয়'}
                    </span>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleOpenBannerModal(b)}
                        className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold"
                      >
                        এডিট
                      </button>
                      <button
                        onClick={() => handleDeleteBanner(b.id)}
                        className="p-1 text-slate-400 hover:text-red-600 rounded"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Sections Visibility & Order Tab */}
      {activeTab === 'sections' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              ওয়েবসাইট সেকশন সমূহের দৃশ্যমানতা ও ক্রমবিন্যাস
            </h3>
            <p className="text-xs text-slate-500">
              যে কোনো সেকশন চালু/বন্ধ করতে চোখের আইকনে ক্লিক করুন, অথবা তীরের সাহায্যে ক্রম পরিবর্তন করুন।
            </p>
          </div>

          <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden">
            {sections.map((sec, idx) => (
              <div
                key={sec.id}
                className={`p-4 flex items-center justify-between transition-colors ${
                  sec.isVisible ? 'bg-white' : 'bg-slate-50 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-600 font-bold text-xs flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{sec.name}</h4>
                    <span className="text-[11px] text-slate-400 font-mono">আইডি: {sec.key}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Toggle Visibility */}
                  <button
                    onClick={() => handleToggleSection(sec.id)}
                    className={`p-2 rounded-xl border flex items-center gap-1.5 text-xs font-bold transition-all ${
                      sec.isVisible
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-slate-100 text-slate-500 border-slate-300'
                    }`}
                  >
                    {sec.isVisible ? (
                      <>
                        <Eye className="w-4 h-4 text-emerald-600" />
                        <span>প্রদর্শিত হচ্ছে</span>
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-4 h-4 text-slate-400" />
                        <span>লুকানো</span>
                      </>
                    )}
                  </button>

                  {/* Move Up */}
                  <button
                    disabled={idx === 0}
                    onClick={() => handleMoveSection(idx, 'up')}
                    className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 disabled:opacity-30 disabled:cursor-not-allowed"
                    title="উপরে নিন"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>

                  {/* Move Down */}
                  <button
                    disabled={idx === sections.length - 1}
                    onClick={() => handleMoveSection(idx, 'down')}
                    className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 disabled:opacity-30 disabled:cursor-not-allowed"
                    title="নিচে নিন"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Categories Management Tab */}
      {activeTab === 'categories' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
                জুতো ক্যাটাগরি সমূহ ({categories.length})
              </h3>
              <p className="text-xs text-slate-500">নতুন ক্যাটাগরি তৈরি করুন অথবা নাম এডিট করুন</p>
            </div>
            <button
              onClick={() => handleOpenCategoryModal()}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Plus className="w-4 h-4" />
              নতুন ক্যাটাগরি
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {categories.map((c) => (
              <div
                key={c.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50 flex items-center justify-between"
              >
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{c.banglaName}</h4>
                  <span className="text-[11px] text-slate-500 font-mono block">{c.name}</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleOpenCategoryModal(c)}
                    className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border border-slate-200"
                  >
                    এডিট
                  </button>
                  <button
                    onClick={() => handleDeleteCategory(c.id)}
                    className="p-1 text-slate-400 hover:text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. Promotional Announcement Tab */}
      {activeTab === 'announcement' && (
        <form onSubmit={handleGeneralSave} className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-1">
            টপ বার প্রমোশনাল নোটিশ (Marquee Announcement)
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            ওয়েবসাইটের একদম উপরে যে কোনো অফার বা নোটিশ তাৎক্ষণিকভাবে প্রদর্শন করুন
          </p>

          <div className="flex items-center gap-3 p-3 bg-emerald-50 rounded-xl border border-emerald-200">
            <input
              type="checkbox"
              id="annActive"
              checked={formData.announcementActive}
              onChange={(e) => setFormData({ ...formData, announcementActive: e.target.checked })}
              className="w-4 h-4 accent-emerald-700 cursor-pointer"
            />
            <label htmlFor="annActive" className="text-xs font-bold text-emerald-900 cursor-pointer">
              টপ প্রমোশনাল নোটিশ প্রদর্শন চালু রাখুন
            </label>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              নোটিশ টেক্সট *
            </label>
            <input
              type="text"
              required
              value={formData.announcementText}
              onChange={(e) => setFormData({ ...formData, announcementText: e.target.value })}
              placeholder="🔥 ধামাকা অফার: ২,৫০০ টাকার অর্ডারে সারা বাংলাদেশে ফ্রি ডেলিভারি!"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'নোটিশ আপডেট করুন'}</span>
            </button>
          </div>
        </form>
      )}

      {/* 6. About Us Tab */}
      {activeTab === 'about' && (
        <form onSubmit={handleGeneralSave} className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2">
            আমাদের সম্পর্কে (About Us Section)
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">শিরোনাম</label>
            <input
              type="text"
              value={formData.aboutTitle}
              onChange={(e) => setFormData({ ...formData, aboutTitle: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:bg-white focus:border-emerald-600 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">বিবরণ</label>
            <textarea
              rows={4}
              value={formData.aboutDesc}
              onChange={(e) => setFormData({ ...formData, aboutDesc: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">অভিজ্ঞতার বছর (যেমন: ১০+ বছর)</label>
              <input
                type="text"
                value={formData.aboutExp}
                onChange={(e) => setFormData({ ...formData, aboutExp: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">সন্তুষ্ট গ্রাহক সংখ্যা (যেমন: ১৫,০০০+)</label>
              <input
                type="text"
                value={formData.aboutHappy}
                onChange={(e) => setFormData({ ...formData, aboutHappy: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">শোরুম ইমেজ লিঙ্ক</label>
            <input
              type="text"
              value={formData.aboutImage}
              onChange={(e) => setFormData({ ...formData, aboutImage: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'সেভ করুন'}</span>
            </button>
          </div>
        </form>
      )}

      {/* 7. Contact Info Tab */}
      {activeTab === 'contact' && (
        <form onSubmit={handleGeneralSave} className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2">
            শোরুমের ঠিকানা ও যোগাযোগের তথ্য
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                প্রধান মোবাইল নম্বর (হটলাইন) *
              </label>
              <input
                type="text"
                required
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:border-emerald-600 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                হোয়াটসঅ্যাপ নম্বর *
              </label>
              <input
                type="text"
                required
                value={formData.whatsappNumber}
                onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">বিকল্প ফোন নম্বর</label>
              <input
                type="text"
                value={formData.secondaryPhone}
                onChange={(e) => setFormData({ ...formData, secondaryPhone: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ইমেইল ঠিকানা</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                শোরুমের পূর্ণ ঠিকানা *
              </label>
              <input
                type="text"
                required
                value={formData.shopAddress}
                onChange={(e) => setFormData({ ...formData, shopAddress: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">খোলা থাকার সময়</label>
              <input
                type="text"
                value={formData.openingHours}
                onChange={(e) => setFormData({ ...formData, openingHours: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'যোগাযোগ তথ্য সেভ করুন'}</span>
            </button>
          </div>
        </form>
      )}

      {/* 8. Theme Colors & Social Media Tab */}
      {activeTab === 'theme' && (
        <form onSubmit={handleGeneralSave} className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2">
            কালার থিম ও সোশ্যাল মিডিয়া লিঙ্ক
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                প্রাইমারি গ্রিন কালার (Primary Brand Color)
              </label>
              <div className="flex gap-2">
                <input
                  type="color"
                  value={formData.primaryColor}
                  onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                  className="h-10 w-16 rounded-xl border border-slate-300 cursor-pointer"
                />
                <input
                  type="text"
                  value={formData.primaryColor}
                  onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                  className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                অ্যাকসেন্ট কালার (Accent Color)
              </label>
              <div className="flex gap-2">
                <input
                  type="color"
                  value={formData.accentColor}
                  onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                  className="h-10 w-16 rounded-xl border border-slate-300 cursor-pointer"
                />
                <input
                  type="text"
                  value={formData.accentColor}
                  onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                  className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 space-y-3">
            <h4 className="text-xs font-bold text-slate-700">সোশ্যাল মিডিয়া লিঙ্কসমূহ:</h4>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-0.5">ফেসবুক পেজ লিঙ্ক</label>
              <input
                type="text"
                value={formData.facebookUrl}
                onChange={(e) => setFormData({ ...formData, facebookUrl: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:border-emerald-600 outline-none"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-0.5">ইনস্টাগ্রাম লিঙ্ক</label>
              <input
                type="text"
                value={formData.instagramUrl}
                onChange={(e) => setFormData({ ...formData, instagramUrl: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:border-emerald-600 outline-none"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-0.5">টিকটক লিঙ্ক</label>
              <input
                type="text"
                value={formData.tiktokUrl}
                onChange={(e) => setFormData({ ...formData, tiktokUrl: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'থিম ও সোশ্যাল লিঙ্ক সেভ'}</span>
            </button>
          </div>
        </form>
      )}

      {/* 9. SEO & Meta Tab */}
      {activeTab === 'seo' && (
        <form onSubmit={handleGeneralSave} className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2">
            সার্চ ইঞ্জিন অপ্টিমাইজেশন (SEO) ও মেটা ট্যাগ
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              মেটা ডেসক্রিপশন (Google Search Description)
            </label>
            <textarea
              rows={3}
              value={formData.metaDescription}
              onChange={(e) => setFormData({ ...formData, metaDescription: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              কিওয়ার্ডস (Keywords - কমা দিয়ে আলাদা করুন)
            </label>
            <input
              type="text"
              value={formData.keywords}
              onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'SEO ট্যাগ সংরক্ষণ করুন'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Banner Modal */}
      {bannerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl">
            <h3 className="font-bold text-sm text-slate-900 mb-4">
              {editingBanner ? 'ব্যানার এডিট করুন' : 'নতুন ব্যানার যোগ করুন'}
            </h3>
            <form onSubmit={handleSaveBanner} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ব্যানার শিরোনাম *</label>
                <input
                  type="text"
                  required
                  value={bannerForm.title}
                  onChange={(e) => setBannerForm({ ...bannerForm, title: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">সাবটাইটেল</label>
                <textarea
                  rows={2}
                  value={bannerForm.subtitle}
                  onChange={(e) => setBannerForm({ ...bannerForm, subtitle: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ট্যাগ ব্যাজ (ঐচ্ছিক)</label>
                <input
                  type="text"
                  value={bannerForm.tag}
                  onChange={(e) => setBannerForm({ ...bannerForm, tag: e.target.value })}
                  placeholder="যেমন: 🔥 ২৫% পর্যন্ত ছাড়"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ইমেজ লিঙ্ক (URL) *</label>
                <input
                  type="text"
                  required
                  value={bannerForm.image}
                  onChange={(e) => setBannerForm({ ...bannerForm, image: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">বোতামের লেখা</label>
                  <input
                    type="text"
                    value={bannerForm.ctaText}
                    onChange={(e) => setBannerForm({ ...bannerForm, ctaText: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">বোতামের লিঙ্ক</label>
                  <input
                    type="text"
                    value={bannerForm.ctaLink}
                    onChange={(e) => setBannerForm({ ...bannerForm, ctaLink: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setBannerModalOpen(false)}
                  className="flex-1 py-2 text-xs font-bold bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-bold bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Category Modal */}
      {categoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="relative w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl">
            <h3 className="font-bold text-sm text-slate-900 mb-4">
              {editingCategory ? 'ক্যাটাগরি এডিট' : 'নতুন ক্যাটাগরি তৈরি'}
            </h3>
            <form onSubmit={handleSaveCategory} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">বাংলা নাম *</label>
                <input
                  type="text"
                  required
                  value={categoryForm.banglaName}
                  onChange={(e) => setCategoryForm({ ...categoryForm, banglaName: e.target.value })}
                  placeholder="যেমন: ফরমাল শু"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ইংরেজি নাম *</label>
                <input
                  type="text"
                  required
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  placeholder="Formal Shoes"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                />
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setCategoryModalOpen(false)}
                  className="flex-1 py-2 text-xs font-bold bg-slate-100 rounded-xl"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-bold bg-emerald-700 text-white rounded-xl"
                >
                  সেভ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
