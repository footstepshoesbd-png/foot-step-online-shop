import React, { useState } from 'react';
import { Truck, ShieldCheck, Clock, Plus, Trash2, Save, Check, AlertCircle } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';

export const AdminDeliverySettings: React.FC = () => {
  const { deliverySettings, updateDeliverySettingsState, refreshData } = useStore();

  const [formData, setFormData] = useState({
    feniCityCharge: deliverySettings?.feniCityCharge || 80,
    outsideFeniCharge: deliverySettings?.outsideFeniCharge || 140,
    expressCharge: deliverySettings?.expressCharge || 150,
    freeDeliveryEnabled: deliverySettings?.freeDeliveryEnabled !== undefined ? deliverySettings.freeDeliveryEnabled : true,
    freeDeliveryThreshold: deliverySettings?.freeDeliveryThreshold || 2500,
    minOrderAmount: deliverySettings?.minOrderAmount || 300,
    estimatedTimeFeni: deliverySettings?.estimatedTimeFeni || '২৪-৪৮ ঘন্টা',
    estimatedTimeOutside: deliverySettings?.estimatedTimeOutside || '২-৪ দিন',
    deliveryInstructions: deliverySettings?.deliveryInstructions || '',
    returnPolicyText: deliverySettings?.returnPolicyText || '',
    customDistrictCharges: deliverySettings?.customDistrictCharges || []
  });

  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  // New district charge state
  const [newDistrict, setNewDistrict] = useState('');
  const [newDistrictCharge, setNewDistrictCharge] = useState(120);

  const handleAddDistrictCharge = () => {
    if (!newDistrict.trim()) return;
    setFormData((prev) => ({
      ...prev,
      customDistrictCharges: [
        ...prev.customDistrictCharges,
        { district: newDistrict.trim(), charge: Number(newDistrictCharge) || 120 }
      ]
    }));
    setNewDistrict('');
    setNewDistrictCharge(120);
  };

  const handleRemoveDistrictCharge = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      customDistrictCharges: prev.customDistrictCharges.filter((_, i) => i !== index)
    }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      await api.updateDeliverySettings({
        feniCityCharge: Number(formData.feniCityCharge),
        outsideFeniCharge: Number(formData.outsideFeniCharge),
        expressCharge: Number(formData.expressCharge),
        freeDeliveryEnabled: Boolean(formData.freeDeliveryEnabled),
        freeDeliveryThreshold: Number(formData.freeDeliveryThreshold),
        minOrderAmount: Number(formData.minOrderAmount),
        estimatedTimeFeni: formData.estimatedTimeFeni,
        estimatedTimeOutside: formData.estimatedTimeOutside,
        deliveryInstructions: formData.deliveryInstructions,
        returnPolicyText: formData.returnPolicyText,
        customDistrictCharges: formData.customDistrictCharges
      });

      updateDeliverySettingsState(formData);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 2000);
      await refreshData();
    } catch (err) {
      console.error(err);
      alert('ডেলিভারি সেটিংস সংরক্ষণ করতে সমস্যা হয়েছে');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            ডেলিভারি ও শিপিং চার্জ নিয়ন্ত্রণ
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            ফেনী সদর ও সারা দেশের ডেলিভারি ফি, ফ্রি ডেলিভারি শর্ত ও পলিসি নির্ধারণ করুন
          </p>
        </div>

        {success && (
          <div className="px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl shadow-lg flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>ডেলিভারি সেটিংস সফলভাবে আপডেট হয়েছে!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* 1. Core Delivery Charges */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
            <Truck className="w-4 h-4 text-emerald-600" />
            প্রধান ডেলিভারি চার্জসমূহ
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Feni City */}
            <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl">
              <label className="block text-xs font-bold text-emerald-950 mb-1">
                ফেনী সিটি ডেলিভারি চার্জ (টাকা) *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-emerald-700">৳</span>
                <input
                  type="number"
                  required
                  value={formData.feniCityCharge}
                  onChange={(e) => setFormData({ ...formData, feniCityCharge: Number(e.target.value) })}
                  className="w-full pl-8 pr-3 py-2 bg-white border border-emerald-300 rounded-xl font-black text-sm text-emerald-900 outline-none"
                />
              </div>
              <p className="text-[11px] text-emerald-700 mt-1">ডিফল্ট: ৮০ টাকা</p>
            </div>

            {/* Outside Feni */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
              <label className="block text-xs font-bold text-slate-900 mb-1">
                ফেনীর বাইরে সারা দেশ (টাকা) *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-500">৳</span>
                <input
                  type="number"
                  required
                  value={formData.outsideFeniCharge}
                  onChange={(e) => setFormData({ ...formData, outsideFeniCharge: Number(e.target.value) })}
                  className="w-full pl-8 pr-3 py-2 bg-white border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">ডিফল্ট: ১৪০ টাকা (Steadfast)</p>
            </div>

            {/* Express Delivery */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
              <label className="block text-xs font-bold text-slate-900 mb-1">
                জরুরি এক্সপ্রেস ডেলিভারি (টাকা)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-500">৳</span>
                <input
                  type="number"
                  value={formData.expressCharge}
                  onChange={(e) => setFormData({ ...formData, expressCharge: Number(e.target.value) })}
                  className="w-full pl-8 pr-3 py-2 bg-white border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">সেম ডে / দ্রুত ডেলিভারি</p>
            </div>
          </div>
        </div>

        {/* 2. Free Delivery & Minimum Order Rules */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            ফ্রি ডেলিভারি ও অর্ডার রুলস
          </h3>

          <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 flex items-center justify-between">
            <div>
              <span className="font-bold text-xs text-emerald-950 block">
                নির্দিষ্ট পরিমাণের অর্ডারে ফ্রি ডেলিভারি অফার
              </span>
              <span className="text-[11px] text-emerald-700">
                গ্রাহক নির্ধারিত টাকার বেশি অর্ডার করলে ডেলিভারি ফি শূন্য (৳০) হয়ে যাবে
              </span>
            </div>
            <input
              type="checkbox"
              checked={formData.freeDeliveryEnabled}
              onChange={(e) => setFormData({ ...formData, freeDeliveryEnabled: e.target.checked })}
              className="w-5 h-5 accent-emerald-700 cursor-pointer"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ফ্রি ডেলিভারির জন্য সর্বনিম্ন অর্ডার পরিমাণ (টাকা)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-500">৳</span>
                <input
                  type="number"
                  value={formData.freeDeliveryThreshold}
                  onChange={(e) => setFormData({ ...formData, freeDeliveryThreshold: Number(e.target.value) })}
                  className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold outline-none"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">যেমন: ২,৫০০ টাকা</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ওয়েবসাইটে সর্বনিম্ন অর্ডারের লিমিট (টাকা)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-500">৳</span>
                <input
                  type="number"
                  value={formData.minOrderAmount}
                  onChange={(e) => setFormData({ ...formData, minOrderAmount: Number(e.target.value) })}
                  className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold outline-none"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">যেমন: ৩০০ টাকা</p>
            </div>
          </div>
        </div>

        {/* 3. Delivery Estimated Time & Policy */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-600" />
            ডেলিভারি সময়সীমা ও নির্দেশিকা
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ফেনী সিটিতে সম্ভাব্য সময়
              </label>
              <input
                type="text"
                value={formData.estimatedTimeFeni}
                onChange={(e) => setFormData({ ...formData, estimatedTimeFeni: e.target.value })}
                placeholder="২৪-৪৮ ঘন্টা"
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                বাইরে সম্ভাব্য সময়
              </label>
              <input
                type="text"
                value={formData.estimatedTimeOutside}
                onChange={(e) => setFormData({ ...formData, estimatedTimeOutside: e.target.value })}
                placeholder="২-৪ দিন"
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              চেকআউটে প্রদর্শিত ডেলিভারি নির্দেশনা (Delivery Instructions)
            </label>
            <input
              type="text"
              value={formData.deliveryInstructions}
              onChange={(e) => setFormData({ ...formData, deliveryInstructions: e.target.value })}
              placeholder="ডেলিভারি ম্যানের সামনে চেক করে মূল্য পরিশোধ করুন।"
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              রিটার্ন ও সাইজ এক্সচেঞ্জ পলিসি (Return & Exchange Policy)
            </label>
            <textarea
              rows={2}
              value={formData.returnPolicyText}
              onChange={(e) => setFormData({ ...formData, returnPolicyText: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-none"
            />
          </div>
        </div>

        {/* 4. Custom District Charges List */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
            জেলা ভিত্তিক কাস্টম ডেলিভারি চার্জ ({formData.customDistrictCharges.length})
          </h3>

          <div className="flex gap-2">
            <input
              type="text"
              value={newDistrict}
              onChange={(e) => setNewDistrict(e.target.value)}
              placeholder="জেলার নাম (যেমন: ব্রাহ্মণবাড়িয়া)"
              className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
            />
            <div className="relative w-28">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">৳</span>
              <input
                type="number"
                value={newDistrictCharge}
                onChange={(e) => setNewDistrictCharge(Number(e.target.value))}
                className="w-full pl-7 pr-2 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold outline-none"
              />
            </div>
            <button
              type="button"
              onClick={handleAddDistrictCharge}
              className="px-4 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800 flex items-center gap-1 shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              যোগ করুন
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
            {formData.customDistrictCharges.map((item, idx) => (
              <div
                key={idx}
                className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-slate-800 block truncate max-w-[110px]">{item.district}</span>
                  <span className="font-mono text-emerald-800 font-bold">৳{item.charge}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveDistrictCharge(idx)}
                  className="text-slate-400 hover:text-red-500 p-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Save button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="px-8 py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl font-bold text-sm shadow-xl shadow-emerald-700/25 flex items-center gap-2 active:scale-95 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'ডেলিভারি সেটিংস ডাটাবেজে সংরক্ষণ করুন'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
