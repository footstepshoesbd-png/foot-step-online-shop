import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  ShoppingBag,
  Package,
  AlertTriangle,
  Truck,
  Wallet,
  Clock,
  Printer,
  ChevronRight,
  PlusCircle,
  FileText,
  DollarSign,
  CheckCircle2
} from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';
import { Order } from '../../types/index.ts';
import { PrintInvoiceModal } from '../shared/PrintInvoiceModal.tsx';

interface AdminDashboardHomeProps {
  onNavigate: (tab: string) => void;
}

export const AdminDashboardHome: React.FC<AdminDashboardHomeProps> = ({ onNavigate }) => {
  const { orders, products, settings } = useStore();
  const [accountingSummary, setAccountingSummary] = useState<any>(null);
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);

  useEffect(() => {
    api.getAccountingSummary().then(setAccountingSummary).catch(console.error);
  }, [orders]);

  const pendingOrders = orders.filter((o) => o.status === 'pending');
  const deliveredOrders = orders.filter((o) => o.status === 'delivered');
  const shippedOrders = orders.filter((o) => o.status === 'shipped');
  const lowStockProducts = products.filter((p) => p.isActive && p.totalStock <= 5);

  const totalSales = orders
    .filter((o) => ['confirmed', 'processing', 'shipped', 'delivered'].includes(o.status))
    .reduce((sum, o) => sum + o.total, 0);

  const statusLabels: { [k: string]: { label: string; badge: string } } = {
    pending: { label: 'অপেক্ষমান', badge: 'bg-amber-100 text-amber-800' },
    confirmed: { label: 'নিশ্চিত', badge: 'bg-blue-100 text-blue-800' },
    processing: { label: 'প্যাকিং', badge: 'bg-indigo-100 text-indigo-800' },
    shipped: { label: 'কুরিয়ারে শিফট', badge: 'bg-purple-100 text-purple-800' },
    delivered: { label: 'ডেলিভার্ড', badge: 'bg-emerald-100 text-emerald-800' },
    cancelled: { label: 'বাতিল', badge: 'bg-red-100 text-red-800' },
    returned: { label: 'রিটার্ন', badge: 'bg-orange-100 text-orange-800' }
  };

  return (
    <div className="space-y-6">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-emerald-800 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider block mb-1">
            ম্যানেজমেন্ট ড্যাশবোর্ড ওভারভিউ
          </span>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            স্বাগতম, {settings?.brandName || 'FOOT STEPS SHOES'} অ্যাডমিন!
          </h1>
          <p className="text-xs sm:text-sm text-emerald-100/90 mt-1 max-w-xl">
            ওয়েবসাইটের সকল কন্টেন্ট, পণ্য স্টক, Steadfast কুরিয়ার বুকিং, এবং হিসাব নিকাশ সম্পূর্ণ ডাইনামিকভাবে এখান থেকে নিয়ন্ত্রণ করুন।
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => onNavigate('orders')}
            className="px-4 py-2.5 bg-white text-emerald-900 hover:bg-emerald-50 rounded-xl font-bold text-xs shadow-md transition-all active:scale-95 flex items-center gap-1.5"
          >
            <ShoppingBag className="w-4 h-4 text-emerald-700" />
            পেন্ডিং অর্ডার ({pendingOrders.length})
          </button>
          <button
            onClick={() => onNavigate('products')}
            className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl font-bold text-xs shadow-md transition-all active:scale-95 flex items-center gap-1.5 border border-emerald-600"
          >
            <PlusCircle className="w-4 h-4" />
            নতুন পণ্য যোগ
          </button>
        </div>
      </div>

      {/* 2. Key Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Sales */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              মোট কার্যকর বিক্রি
            </span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div>
            <span className="text-2xl font-black text-slate-900 tracking-tight block">
              ৳{totalSales.toLocaleString()}
            </span>
            <span className="text-[11px] font-semibold text-emerald-700 mt-1 block">
              সফল ডেলিভারি: {deliveredOrders.length} টি
            </span>
          </div>
        </div>

        {/* Pending Orders */}
        <div
          onClick={() => onNavigate('orders')}
          className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs flex flex-col justify-between cursor-pointer hover:border-amber-400 transition-colors"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              পেন্ডিং অর্ডার
            </span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div>
            <span className="text-2xl font-black text-amber-700 tracking-tight block">
              {pendingOrders.length} টি
            </span>
            <span className="text-[11px] font-semibold text-slate-500 mt-1 block">
              কনফার্ম করার অপেক্ষায়
            </span>
          </div>
        </div>

        {/* Shipped / Steadfast */}
        <div
          onClick={() => onNavigate('steadfast')}
          className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs flex flex-col justify-between cursor-pointer hover:border-purple-400 transition-colors"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              কুরিয়ার ডেলিভারিতে
            </span>
            <div className="p-2 rounded-xl bg-purple-50 text-purple-700">
              <Truck className="w-5 h-5" />
            </div>
          </div>
          <div>
            <span className="text-2xl font-black text-purple-900 tracking-tight block">
              {shippedOrders.length} টি পার্সেল
            </span>
            <span className="text-[11px] font-semibold text-purple-700 mt-1 block">
              Steadfast Courier
            </span>
          </div>
        </div>

        {/* Cash & Bank balance */}
        <div
          onClick={() => onNavigate('accounting')}
          className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs flex flex-col justify-between cursor-pointer hover:border-emerald-400 transition-colors"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              মোট ক্যাশ ও ব্যাংক
            </span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div>
            <span className="text-2xl font-black text-emerald-900 tracking-tight block">
              ৳{(accountingSummary?.totalCashBank || 201200).toLocaleString()}
            </span>
            <span className="text-[11px] font-semibold text-slate-500 mt-1 block">
              দোকান ড্রয়ার + বিকাশ + ব্যাংক
            </span>
          </div>
        </div>
      </div>

      {/* 3. Low stock warning alert if any */}
      {lowStockProducts.length > 0 && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-xs font-bold text-amber-900 uppercase tracking-wider">
              স্টক আউট সতর্কতা ({lowStockProducts.length} টি জুতোর স্টক ৫ বা তার কম)
            </h3>
            <p className="text-xs text-amber-800 mt-0.5">
              {lowStockProducts.map((p) => `${p.banglaName} (বাকি: ${p.totalStock})`).join(', ')}
            </p>
          </div>
          <button
            onClick={() => onNavigate('products')}
            className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold shrink-0"
          >
            স্টক আপডেট
          </button>
        </div>
      )}

      {/* 4. Recent Orders Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">সাম্প্রতিক অর্ডার সমূহ</h3>
            <p className="text-xs text-slate-500">ওয়েবসাইট থেকে আসা সর্বশেষ অর্ডার ও বুকিং</p>
          </div>
          <button
            onClick={() => onNavigate('orders')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
          >
            সব অর্ডার দেখুন ({orders.length}) →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
              <tr>
                <th className="py-3 px-3">অর্ডার আইডি</th>
                <th className="py-3 px-3">গ্রাহক ও ফোন</th>
                <th className="py-3 px-3">এলাকা</th>
                <th className="py-3 px-3">জুতো ও সাইজ</th>
                <th className="py-3 px-3 text-right">মোট COD</th>
                <th className="py-3 px-3 text-center">স্ট্যাটাস</th>
                <th className="py-3 px-3 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {orders.slice(0, 5).map((order) => (
                <tr key={order.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-3 font-mono font-bold text-slate-800">#{order.id}</td>
                  <td className="py-3 px-3">
                    <span className="font-bold text-slate-900 block">{order.customerName}</span>
                    <span className="text-slate-500 font-mono text-[11px]">{order.customerPhone}</span>
                  </td>
                  <td className="py-3 px-3 text-slate-600">
                    <span className="font-semibold block">{order.district}</span>
                    <span className="text-[10px] text-slate-400">
                      {order.deliveryArea === 'feni_city' ? 'ফেনী সিটি' : 'বাইরে'}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-700">
                    {order.items.map((it, idx) => (
                      <span key={idx} className="block truncate max-w-[180px]">
                        {it.productName} ({it.size}) × {it.quantity}
                      </span>
                    ))}
                  </td>
                  <td className="py-3 px-3 text-right font-black text-emerald-800">
                    ৳{order.total.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        statusLabels[order.status]?.badge || 'bg-slate-100'
                      }`}
                    >
                      {statusLabels[order.status]?.label || order.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right space-x-1">
                    <button
                      onClick={() => setSelectedInvoiceOrder(order)}
                      className="p-1.5 rounded-lg bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800"
                      title="ইনভয়েস প্রিন্ট"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onNavigate('orders')}
                      className="px-2 py-1 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-[11px]"
                    >
                      ভিউ
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice modal */}
      <PrintInvoiceModal
        order={selectedInvoiceOrder}
        settings={settings}
        isOpen={Boolean(selectedInvoiceOrder)}
        onClose={() => setSelectedInvoiceOrder(null)}
      />
    </div>
  );
};
