import React, { useState, useEffect } from 'react';
import { Users, Phone, MessageCircle, ShoppingBag, Search, ExternalLink, Eye } from 'lucide-react';
import { api } from '../../lib/api.ts';
import { useStore } from '../../context/StoreContext.tsx';

export const AdminCustomerManager: React.FC = () => {
  const [customers, setCustomers] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<any | null>(null);

  const loadCustomers = async () => {
    try {
      const data = await api.getCustomers();
      setCustomers(data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const filtered = customers.filter((c) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      (c.address && c.address.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            গ্রাহক ডাটাবেজ (Customer Management)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            অর্ডার থেকে সংগৃহীত গ্রাহকদের তথ্য, ক্রয় ইতিহাস, লাইফটাইম স্পেন্ডিং ও দ্রুত যোগাযোগ
          </p>
        </div>

        <div className="px-4 py-2 bg-emerald-50 text-emerald-800 rounded-xl font-bold text-xs border border-emerald-200">
          মোট নিবন্ধিত গ্রাহক: {customers.length} জন
        </div>
      </div>

      {/* Search */}
      <div className="bg-white rounded-3xl border border-slate-200 p-4 space-y-4">
        <div className="relative max-w-md">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="গ্রাহকের নাম বা মোবাইল নম্বর দিয়ে খুঁজুন..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
              <tr>
                <th className="py-3 px-3">গ্রাহকের নাম</th>
                <th className="py-3 px-3">মোবাইল নম্বর</th>
                <th className="py-3 px-3">ঠিকানা ও জেলা</th>
                <th className="py-3 px-3 text-center">মোট অর্ডার</th>
                <th className="py-3 px-3 text-right">লাইফটাইম কেনাকাটা</th>
                <th className="py-3 px-3 text-right">যোগাযোগ ও অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((cust) => {
                const cleanPhone = cust.phone.replace(/[^0-9]/g, '');
                return (
                  <tr key={cust.phone} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3 font-bold text-slate-900">{cust.name}</td>
                    <td className="py-3 px-3 font-mono font-semibold text-slate-700">{cust.phone}</td>
                    <td className="py-3 px-3 text-slate-600">
                      <span className="block truncate max-w-xs">{cust.address}</span>
                      <span className="text-[10px] text-slate-400 font-bold">{cust.district}</span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                        {cust.totalOrders} টি
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-black text-emerald-800">
                      ৳{cust.totalSpent.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-right space-x-1 whitespace-nowrap">
                      <a
                        href={`tel:${cust.phone}`}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 inline-block"
                        title="সরাসরি কল দিন"
                      >
                        <Phone className="w-3.5 h-3.5" />
                      </a>
                      <a
                        href={`https://wa.me/${cleanPhone}`}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-emerald-100 text-emerald-700 inline-block"
                        title="হোয়াটসঅ্যাপে চ্যাট"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                      </a>
                      <button
                        onClick={() => setSelectedCustomer(cust)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold"
                      >
                        ইতিহাস
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* History Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full text-xs space-y-4">
            <div className="flex justify-between items-start border-b border-slate-100 pb-3">
              <div>
                <h4 className="font-bold text-sm text-slate-900">{selectedCustomer.name}</h4>
                <p className="text-slate-500 font-mono text-[11px]">{selectedCustomer.phone}</p>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-1">
              <span className="font-bold text-slate-700">অর্ডারের ইতিহাস:</span>
              <div className="space-y-2 max-h-48 overflow-y-auto pt-1">
                {selectedCustomer.orders.map((ord: any) => (
                  <div key={ord.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                    <div>
                      <span className="font-mono font-bold text-slate-900 block">#{ord.id}</span>
                      <span className="text-[10px] text-slate-400">{new Date(ord.date).toLocaleDateString()}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-black text-emerald-800 block">৳{ord.total.toLocaleString()}</span>
                      <span className="text-[10px] font-bold text-slate-500 uppercase">{ord.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-3 bg-emerald-50 rounded-xl text-emerald-900 flex justify-between font-bold">
              <span>মোট ব্যয় (Lifetime Spent):</span>
              <span>৳{selectedCustomer.totalSpent.toLocaleString()}</span>
            </div>

            <button
              onClick={() => setSelectedCustomer(null)}
              className="w-full py-2 bg-slate-800 text-white font-bold rounded-xl"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
