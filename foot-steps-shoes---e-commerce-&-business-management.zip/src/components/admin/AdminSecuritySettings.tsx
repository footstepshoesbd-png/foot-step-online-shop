import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  KeyRound,
  Users,
  History,
  Download,
  Upload,
  Save,
  Check,
  AlertCircle,
  Plus,
  Trash2,
  FileText
} from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';
import { StaffUser, ActivityLog } from '../../types/index.ts';

export const AdminSecuritySettings: React.FC = () => {
  const { currentUser, systemSettings, refreshData } = useStore();

  const [activeTab, setActiveTab] = useState<'password' | 'staff' | 'logs' | 'backup' | 'system'>('password');

  // Change Password state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwMsg, setPwMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Staff state
  const [staffList, setStaffList] = useState<StaffUser[]>([]);
  const [staffModalOpen, setStaffModalOpen] = useState(false);
  const [newStaffForm, setNewStaffForm] = useState({
    username: '',
    fullName: '',
    phone: '',
    role: 'order_staff' as any,
    password: ''
  });

  // Activity logs state
  const [logs, setLogs] = useState<ActivityLog[]>([]);

  // System settings state
  const [sysForm, setSysForm] = useState({
    invoicePrefix: systemSettings?.invoicePrefix || 'FS-',
    autoConfirmOrders: Boolean(systemSettings?.autoConfirmOrders),
    enableSMS: Boolean(systemSettings?.enableSMS),
    smsApiKey: systemSettings?.smsApiKey || '',
    smsSenderId: systemSettings?.smsSenderId || '',
    taxPercentage: systemSettings?.taxPercentage || 0,
    taxEnabled: Boolean(systemSettings?.taxEnabled),
    currencySymbol: systemSettings?.currencySymbol || '৳',
    tradeLicenseNo: systemSettings?.tradeLicenseNo || '',
    tinNo: systemSettings?.tinNo || ''
  });

  const [savingSys, setSavingSys] = useState(false);
  const [sysToast, setSysToast] = useState(false);

  useEffect(() => {
    api.getStaff().then(setStaffList).catch(console.error);
    api.getActivityLogs().then(setLogs).catch(console.error);
  }, []);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwMsg(null);
    if (newPassword !== confirmPassword) {
      setPwMsg({ type: 'error', text: 'নতুন পাসওয়ার্ড ও কনফার্ম পাসওয়ার্ড মিলছে না।' });
      return;
    }
    if (newPassword.length < 4) {
      setPwMsg({ type: 'error', text: 'পাসওয়ার্ড ন্যূনতম ৪ অক্ষরের হতে হবে।' });
      return;
    }

    try {
      const res = await api.changePassword(currentUser?.username || 'admin', oldPassword, newPassword);
      if (res.success) {
        setPwMsg({ type: 'success', text: 'পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!' });
        setOldPassword('');
        setNewPassword('');
        setConfirmPassword('');
      }
    } catch (err: any) {
      setPwMsg({ type: 'error', text: err.message || 'পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে।' });
    }
  };

  const handleCreateStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createStaff(newStaffForm);
      setStaffModalOpen(false);
      setNewStaffForm({ username: '', fullName: '', phone: '', role: 'order_staff', password: '' });
      const updated = await api.getStaff();
      setStaffList(updated);
    } catch (e) {
      alert('স্টাফ যোগ করতে সমস্যা হয়েছে');
    }
  };

  const handleDeleteStaff = async (id: string) => {
    if (!confirm('আপনি কি এই স্টাফ একাউন্টটি মুছে ফেলতে চান?')) return;
    await api.deleteStaff(id);
    const updated = await api.getStaff();
    setStaffList(updated);
  };

  const handleSaveSystemSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSavingSys(true);
      await api.updateSystemSettings(sysForm);
      setSysToast(true);
      setTimeout(() => setSysToast(false), 2000);
      await refreshData();
    } catch (e) {
      alert('সিস্টেম সেটিংস সংরক্ষণ ব্যর্থ হয়েছে');
    } finally {
      setSavingSys(false);
    }
  };

  // 1-Click Backup Download
  const handleDownloadBackup = () => {
    window.location.href = '/api/backup';
  };

  // 1-Click Restore Upload
  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (!confirm('আপনি কি এই ব্যাকআপ ফাইলটি থেকে সম্পূর্ণ ডাটাবেজ রিস্টোর করতে চান?')) return;
        await api.restoreBackup(json);
        alert('ডাটাবেজ সফলভাবে রিস্টোর হয়েছে!');
        await refreshData();
      } catch (err) {
        alert('ব্যাকআপ ফাইলটি সঠিক ফরম্যাটে নেই');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
          নিরাপত্তা, স্টাফ অ্যাকাউন্ট ও সিস্টেম সেটিংস
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          অ্যাডমিন পাসওয়ার্ড পরিবর্তন, স্টাফ রোল, অ্যাক্টিভিটি লগ ও ডাটাবেজ ব্যাকআপ
        </p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1.5 bg-slate-100 rounded-2xl border border-slate-200 text-xs font-bold">
        {[
          { id: 'password', label: 'পাসওয়ার্ড পরিবর্তন', icon: KeyRound },
          { id: 'staff', label: `স্টাফ একাউন্ট (${staffList.length})`, icon: Users },
          { id: 'logs', label: `অ্যাক্টিভিটি লগ (${logs.length})`, icon: History },
          { id: 'backup', label: 'ডাটাবেজ ব্যাকআপ ও রিস্টোর', icon: Download },
          { id: 'system', label: 'সিস্টেম সেটিংস ও ভ্যাট', icon: FileText }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition-all ${
                activeTab === tab.id
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-emerald-800 hover:bg-white/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. Change Password Tab */}
      {activeTab === 'password' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 max-w-md">
          <h3 className="text-sm font-bold text-slate-900 mb-1">অ্যাডমিন পাসওয়ার্ড পরিবর্তন করুন</h3>
          <p className="text-xs text-slate-500 mb-4">
            লগইন করা অ্যাকাউন্ট: <span className="font-bold text-emerald-800">{currentUser?.username || 'admin'}</span>
          </p>

          {pwMsg && (
            <div
              className={`mb-4 p-3 rounded-xl text-xs flex items-center gap-2 ${
                pwMsg.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-red-50 text-red-700 border border-red-200'
              }`}
            >
              {pwMsg.type === 'success' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{pwMsg.text}</span>
            </div>
          )}

          <form onSubmit={handleChangePassword} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">বর্তমান পাসওয়ার্ড</label>
              <input
                type="password"
                required
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">নতুন পাসওয়ার্ড</label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">নতুন পাসওয়ার্ড পুনরায় লিখুন</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition-all active:scale-98"
            >
              পাসওয়ার্ড আপডেট করুন
            </button>
          </form>
        </div>
      )}

      {/* 2. Staff Accounts Tab */}
      {activeTab === 'staff' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">স্টাফ অ্যাকাউন্ট ও পদবী</h3>
            <button
              onClick={() => setStaffModalOpen(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Plus className="w-4 h-4" />
              নতুন স্টাফ যোগ করুন
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
                <tr>
                  <th className="py-3 px-3">নাম ও ফোন</th>
                  <th className="py-3 px-3">ইউজারনেম</th>
                  <th className="py-3 px-3">রোল (ভূমিকা)</th>
                  <th className="py-3 px-3">স্ট্যাটাস</th>
                  <th className="py-3 px-3 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {staffList.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3">
                      <span className="font-bold text-slate-900 block">{s.fullName}</span>
                      <span className="text-slate-400 font-mono text-[11px]">{s.phone}</span>
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-slate-700">@{s.username}</td>
                    <td className="py-3 px-3">
                      <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px] uppercase">
                        {s.role}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-emerald-700 font-bold text-[11px]">সক্রিয়</span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      {s.role !== 'super_admin' && (
                        <button
                          onClick={() => handleDeleteStaff(s.id)}
                          className="p-1 text-slate-400 hover:text-red-600 rounded"
                          title="মুছে ফেলুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Activity Logs Tab */}
      {activeTab === 'logs' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-900">সিস্টেম অ্যাক্টিভিটি অডিট লগ (Security Logs)</h3>
          <p className="text-xs text-slate-500">কে কখন কোন পণ্য আপডেট করেছেন বা অর্ডার পরিবর্তন করেছেন তার রেকর্ড</p>

          <div className="space-y-2 max-h-96 overflow-y-auto divide-y divide-slate-100">
            {logs.map((log) => (
              <div key={log.id} className="pt-2.5 first:pt-0 flex items-start justify-between text-xs gap-3">
                <div>
                  <span className="font-bold text-slate-900">{log.staffName}</span>
                  <span className="mx-2 text-slate-300">•</span>
                  <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-bold">
                    {log.module}
                  </span>
                  <p className="text-slate-600 mt-0.5">{log.details}</p>
                </div>
                <span className="text-[10px] text-slate-400 shrink-0 font-medium whitespace-nowrap">
                  {new Date(log.timestamp).toLocaleString('bn-BD', {
                    dateStyle: 'short',
                    timeStyle: 'short'
                  })}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Backup & Restore Tab */}
      {activeTab === 'backup' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Download Backup */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-4">
                <Download className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">
                ১-ক্লিক সম্পূর্ণ ডাটাবেজ ব্যাকআপ (JSON)
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                আপনার ওয়েবসাইটের সমস্ত পণ্য, অর্ডার, সেটিংস, কাস্টমার তথ্য এবং হিসাবের একটি সম্পূর্ণ সুরক্ষিত কপি আপনার কম্পিউটারে ডাউনলোড করে রাখুন।
              </p>
            </div>

            <button
              onClick={handleDownloadBackup}
              className="mt-6 w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 active:scale-98 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>ব্যাকআপ ফাইল ডাউনলোড করুন</span>
            </button>
          </div>

          {/* Restore Backup */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-800 flex items-center justify-center mb-4">
                <Upload className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-1">
                ডাটাবেজ রিস্টোর (Restore from JSON)
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                পূর্বে সেভ করা কোনো ব্যাকআপ ফাইল আপলোড করে এক নিমেষেই পূর্বের সমস্ত তথ্য ফেরত আনুন।
              </p>
            </div>

            <div className="mt-6">
              <label className="w-full py-3 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all">
                <Upload className="w-4 h-4" />
                <span>ব্যাকআপ ফাইল সিলেক্ট করুন</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleRestoreFile}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      )}

      {/* 5. System Settings & Tax Tab */}
      {activeTab === 'system' && (
        <form onSubmit={handleSaveSystemSettings} className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 max-w-xl">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              সিস্টেম ও ইনভয়েস কনফিগারেশন
            </h3>
            {sysToast && (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg">
                ✓ সংরক্ষিত
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">ইনভয়েস প্রিফিক্স (Prefix) *</label>
              <input
                type="text"
                required
                value={sysForm.invoicePrefix}
                onChange={(e) => setSysForm({ ...sysForm, invoicePrefix: e.target.value })}
                placeholder="FS-"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">মুদ্রা প্রতীক (Currency) *</label>
              <input
                type="text"
                required
                value={sysForm.currencySymbol}
                onChange={(e) => setSysForm({ ...sysForm, currencySymbol: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl flex items-center justify-between text-xs">
            <div>
              <span className="font-bold text-slate-800 block">নতুন অর্ডার অটো-কনফার্ম মোড</span>
              <span className="text-slate-500 text-[11px]">অনলাইনে অর্ডার আসলেই সরাসরি 'কনফার্ম' তালিকায় যুক্ত হবে</span>
            </div>
            <input
              type="checkbox"
              checked={sysForm.autoConfirmOrders}
              onChange={(e) => setSysForm({ ...sysForm, autoConfirmOrders: e.target.checked })}
              className="w-4 h-4 accent-emerald-700"
            />
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">ট্রেড লাইসেন্স নম্বর</label>
              <input
                type="text"
                value={sysForm.tradeLicenseNo}
                onChange={(e) => setSysForm({ ...sysForm, tradeLicenseNo: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">টি আই এন (TIN No)</label>
              <input
                type="text"
                value={sysForm.tinNo}
                onChange={(e) => setSysForm({ ...sysForm, tinNo: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={savingSys}
            className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1.5"
          >
            <Save className="w-4 h-4" />
            <span>{savingSys ? 'সংরক্ষণ হচ্ছে...' : 'সিস্টেম সেটিংস সেভ করুন'}</span>
          </button>
        </form>
      )}

      {/* Staff Modal */}
      {staffModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full text-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900">নতুন স্টাফ অ্যাকাউন্ট তৈরি</h4>
            <form onSubmit={handleCreateStaff} className="space-y-3">
              <div>
                <label className="block font-bold mb-1">স্টাফের পুরো নাম *</label>
                <input
                  type="text"
                  required
                  value={newStaffForm.fullName}
                  onChange={(e) => setNewStaffForm({ ...newStaffForm, fullName: e.target.value })}
                  placeholder="যেমন: সোহেল রানা"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">ইউজারনেম (Login ID) *</label>
                <input
                  type="text"
                  required
                  value={newStaffForm.username}
                  onChange={(e) => setNewStaffForm({ ...newStaffForm, username: e.target.value })}
                  placeholder="sohel"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">মোবাইল নম্বর</label>
                <input
                  type="text"
                  value={newStaffForm.phone}
                  onChange={(e) => setNewStaffForm({ ...newStaffForm, phone: e.target.value })}
                  placeholder="01812345678"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">ভূমিকা (Role) *</label>
                <select
                  value={newStaffForm.role}
                  onChange={(e) => setNewStaffForm({ ...newStaffForm, role: e.target.value as any })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                >
                  <option value="manager">শোরুম ম্যানেজার (Manager)</option>
                  <option value="order_staff">অর্ডার এক্সিকিউটিভ (Order Staff)</option>
                  <option value="accounts">অ্যাকাউন্টিং অফিসার (Accounts)</option>
                  <option value="delivery_staff">ডেলিভারি সমন্বয়ক (Delivery Staff)</option>
                </select>
              </div>
              <div>
                <label className="block font-bold mb-1">পাসওয়ার্ড *</label>
                <input
                  type="password"
                  required
                  value={newStaffForm.password}
                  onChange={(e) => setNewStaffForm({ ...newStaffForm, password: e.target.value })}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                />
              </div>
              <div className="flex gap-2 pt-3">
                <button type="button" onClick={() => setStaffModalOpen(false)} className="flex-1 py-2 font-bold bg-slate-100 rounded-xl">বাতিল</button>
                <button type="submit" className="flex-1 py-2 font-bold bg-emerald-700 text-white rounded-xl">যোগ করুন</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
