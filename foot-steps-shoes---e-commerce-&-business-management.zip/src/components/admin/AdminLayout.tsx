import React, { useState } from 'react';
import {
  LayoutDashboard,
  Globe,
  ShoppingBag,
  Package,
  Truck,
  RotateCcw,
  DollarSign,
  Users,
  ShieldCheck,
  LogOut,
  ExternalLink,
  Menu,
  X,
  Bell
} from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { AdminLogin } from './AdminLogin.tsx';
import { AdminDashboardHome } from './AdminDashboardHome.tsx';
import { AdminWebsiteCMS } from './AdminWebsiteCMS.tsx';
import { AdminOrderManager } from './AdminOrderManager.tsx';
import { AdminProductManager } from './AdminProductManager.tsx';
import { AdminDeliverySettings } from './AdminDeliverySettings.tsx';
import { AdminSteadfastCourier } from './AdminSteadfastCourier.tsx';
import { AdminShippingManager } from './AdminShippingManager.tsx';
import { AdminAccounting } from './AdminAccounting.tsx';
import { AdminCustomerManager } from './AdminCustomerManager.tsx';
import { AdminSecuritySettings } from './AdminSecuritySettings.tsx';

export const AdminLayout: React.FC = () => {
  const { currentUser, logout, setIsAdminOpen, orders, products, settings } = useStore();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // If not logged in, show login form
  if (!currentUser) {
    return <AdminLogin onBackToSite={() => setIsAdminOpen(false)} />;
  }

  const pendingCount = orders.filter((o) => o.status === 'pending').length;
  const lowStockCount = products.filter((p) => p.isActive && p.totalStock <= 5).length;

  const navItems = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: LayoutDashboard, badge: null },
    { id: 'cms', label: 'ওয়েবসাইট নিয়ন্ত্রণ (CMS)', icon: Globe, badge: null },
    { id: 'orders', label: 'অর্ডার ম্যানেজমেন্ট', icon: ShoppingBag, badge: pendingCount > 0 ? pendingCount : null },
    { id: 'products', label: 'পণ্য ম্যানেজমেন্ট', icon: Package, badge: lowStockCount > 0 ? '!' : null },
    { id: 'delivery', label: 'ডেলিভারি সেটিংস', icon: Truck, badge: null },
    { id: 'steadfast', label: 'স্টেডফাস্ট কুরিয়ার', icon: Truck, badge: 'API' },
    { id: 'shipping', label: 'ডেলিভারি ও শিপিং', icon: RotateCcw, badge: null },
    { id: 'accounting', label: 'হিসাব ও রিপোর্ট', icon: DollarSign, badge: null },
    { id: 'customers', label: 'গ্রাহক ডাটাবেজ', icon: Users, badge: null },
    { id: 'security', label: 'নিরাপত্তা ও সেটিংস', icon: ShieldCheck, badge: null }
  ];

  const handleSelectTab = (tabId: string) => {
    setActiveTab(tabId);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* Top Bar */}
      <header className="sticky top-0 z-30 bg-emerald-950 text-white px-4 sm:px-6 py-3 shadow-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-lg bg-emerald-900 text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center font-black text-sm">
              FS
            </div>
            <div>
              <span className="font-black text-sm sm:text-base tracking-tight block leading-tight">
                {settings?.brandName || 'FOOT STEPS SHOES'}
              </span>
              <span className="text-[10px] text-emerald-300 font-semibold block">
                অ্যাডমিন কন্ট্রোল প্যানেল
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* Back to Live Website Button */}
          <button
            onClick={() => setIsAdminOpen(false)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-all backdrop-blur-sm border border-white/10 active:scale-95"
            title="লাইভ ওয়েবসাইট দেখুন"
          >
            <ExternalLink className="w-3.5 h-3.5 text-emerald-300" />
            <span className="hidden sm:inline">লাইভ ওয়েবসাইট</span>
          </button>

          {/* User profile pill */}
          <div className="hidden md:flex items-center gap-2 px-2.5 py-1 bg-emerald-900/60 rounded-xl border border-emerald-800">
            <div className="w-6 h-6 rounded-full bg-amber-400 text-emerald-950 flex items-center justify-center font-bold text-xs">
              {currentUser.fullName.charAt(0)}
            </div>
            <div className="text-left text-[11px]">
              <span className="font-bold text-white block leading-none">{currentUser.fullName}</span>
              <span className="text-[9px] text-emerald-300 font-mono uppercase">{currentUser.role}</span>
            </div>
          </div>

          {/* Logout */}
          <button
            onClick={logout}
            className="p-2 rounded-xl bg-red-900/40 hover:bg-red-800/60 text-red-200 transition-colors"
            title="লগআউট"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar (Desktop) */}
        <aside className="hidden lg:flex w-64 bg-emerald-900 text-emerald-100 flex-col justify-between shrink-0 p-4 border-r border-emerald-950/40 shadow-inner">
          <nav className="space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400/80 px-3 py-1 block">
              মেনু মডিউল
            </span>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isSelected = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-emerald-700 text-white shadow-md shadow-emerald-950/30'
                      : 'text-emerald-100/90 hover:bg-emerald-800/70 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold ${
                        item.badge === '!'
                          ? 'bg-amber-400 text-emerald-950'
                          : 'bg-emerald-500 text-white'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          <div className="pt-4 border-t border-emerald-800/60 text-[11px] text-emerald-300/80">
            <p className="font-semibold">FOOT STEPS SHOES v2.6</p>
            <p className="text-[10px] text-emerald-400/60">ফেনী সদর, বাংলাদেশ</p>
          </div>
        </aside>

        {/* Mobile Sidebar Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-40 lg:hidden flex">
            <div onClick={() => setMobileMenuOpen(false)} className="fixed inset-0 bg-black/60" />
            <div className="relative w-64 bg-emerald-900 text-white p-4 flex flex-col justify-between shadow-2xl z-50">
              <nav className="space-y-1">
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-emerald-800">
                  <span className="font-bold text-xs text-emerald-300">অ্যাডমিন মেনু</span>
                  <button onClick={() => setMobileMenuOpen(false)}>
                    <X className="w-5 h-5 text-emerald-300" />
                  </button>
                </div>
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isSelected = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleSelectTab(item.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold ${
                        isSelected ? 'bg-emerald-700 text-white' : 'text-emerald-100 hover:bg-emerald-800'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </div>
                      {item.badge && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-400 text-emerald-950 text-[10px]">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>

              <button
                onClick={() => setIsAdminOpen(false)}
                className="w-full py-2 bg-emerald-800 rounded-xl text-xs font-bold text-emerald-200 mt-4"
              >
                ওয়েবসাইট দেখুন
              </button>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-7xl">
          {activeTab === 'dashboard' && <AdminDashboardHome onNavigate={setActiveTab} />}
          {activeTab === 'cms' && <AdminWebsiteCMS />}
          {activeTab === 'orders' && <AdminOrderManager />}
          {activeTab === 'products' && <AdminProductManager />}
          {activeTab === 'delivery' && <AdminDeliverySettings />}
          {activeTab === 'steadfast' && <AdminSteadfastCourier />}
          {activeTab === 'shipping' && <AdminShippingManager />}
          {activeTab === 'accounting' && <AdminAccounting />}
          {activeTab === 'customers' && <AdminCustomerManager />}
          {activeTab === 'security' && <AdminSecuritySettings />}
        </main>
      </div>
    </div>
  );
};
