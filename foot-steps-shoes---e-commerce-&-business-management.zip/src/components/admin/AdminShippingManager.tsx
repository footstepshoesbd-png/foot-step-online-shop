import React, { useState } from 'react';
import { Truck, CheckCircle2, RotateCcw, AlertTriangle, TrendingUp, Search, Plus, ExternalLink } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';
import { Order, OrderStatus } from '../../types/index.ts';

export const AdminShippingManager: React.FC = () => {
  const { orders, refreshData, deliverySettings } = useStore();

  const [activeTab, setActiveTab] = useState<'all' | 'shipped' | 'delivered' | 'returned'>('all');
  const [manualModal, setManualModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [courierName, setCourierName] = useState('Pathao Courier');
  const [trackingNumber, setTrackingNumber] = useState('');

  // Performance calculations
  const totalShippedOrDone = orders.filter((o) => ['shipped', 'delivered', 'returned'].includes(o.status));
  const deliveredCount = orders.filter((o) => o.status === 'delivered').length;
  const returnedCount = orders.filter((o) => o.status === 'returned').length;

  const successRate = totalShippedOrDone.length > 0 ? Math.round((deliveredCount / totalShippedOrDone.length) * 100) : 100;
  const returnRate = totalShippedOrDone.length > 0 ? Math.round((returnedCount / totalShippedOrDone.length) * 100) : 0;
  const returnLoss = returnedCount * ((deliverySettings?.outsideFeniCharge || 140) * 1.5);

  const filteredOrders = orders.filter((o) => {
    if (activeTab === 'shipped') return o.status === 'shipped';
    if (activeTab === 'delivered') return o.status === 'delivered';
    if (activeTab === 'returned') return o.status === 'returned';
    return ['shipped', 'delivered', 'returned', 'confirmed'].includes(o.status);
  });

  const handleOpenManualBooking = (o: Order) => {
    setSelectedOrder(o);
    setCourierName('Pathao Courier');
    setTrackingNumber(`PTH-${Math.floor(100000 + Math.random() * 900000)}`);
    setManualModal(true);
  };

  const handleSaveManualBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder) return;

    await api.updateOrder(selectedOrder.id, {
      status: 'shipped',
      courierName: 'manual',
      courierDetails: {
        trackingCode: trackingNumber,
        courierStatus: 'shipped',
        bookedAt: new Date().toISOString(),
        deliveryCharge: selectedOrder.deliveryCharge,
        codAmount: selectedOrder.codAmount,
        notes: `${courierName} এর মাধ্যমে পাঠানো হয়েছে`
      }
    });

    setManualModal(false);
    await refreshData();
  };

  const handleMarkReturned = async (orderId: string) => {
    if (!confirm('পার্সেলটি রিটার্ন হিসেবে চিহ্নিত করতে চান? (রিটার্ন ক্ষতি অ্যাকাউন্টিংয়ে যুক্ত হবে)')) return;
    await api.updateOrderStatus(orderId, 'returned', 'কুরিয়ার থেকে পার্সেল রিটার্ন এসেছে');
    await refreshData();
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            ডেলিভারি ও কুরিয়ার পারফরম্যান্স ড্যাশবোর্ড
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            সকল কুরিয়ার শিপমেন্ট ট্র্যাকিং, ম্যানুয়াল কুরিয়ার বুকিং, রিটার্ন পার্সেল ও ডেলিভারি পারফরম্যান্স
          </p>
        </div>
      </div>

      {/* Performance Analytics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200">
          <span className="text-xs font-bold text-slate-500 uppercase">ডেলিভারি সাকসেস রেট</span>
          <span className="text-2xl font-black text-emerald-800 block mt-1">{successRate}%</span>
          <span className="text-[11px] text-emerald-600 font-semibold">সফলভাবে গ্রাহকের হাতে পৌঁছেছে</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200">
          <span className="text-xs font-bold text-slate-500 uppercase">পার্সেল রিটার্ন রেট</span>
          <span className="text-2xl font-black text-orange-700 block mt-1">{returnRate}%</span>
          <span className="text-[11px] text-orange-600 font-semibold">মোট রিটার্ন: {returnedCount} টি</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200">
          <span className="text-xs font-bold text-slate-500 uppercase">রিটার্নজনিত ডেলিভারি ক্ষতি</span>
          <span className="text-2xl font-black text-red-600 block mt-1">৳{returnLoss.toLocaleString()}</span>
          <span className="text-[11px] text-slate-400">কুরিয়ারের রিটার্ন চার্জ বাবদ</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200">
          <span className="text-xs font-bold text-slate-500 uppercase">বর্তমানে কুরিয়ারে রানিং</span>
          <span className="text-2xl font-black text-purple-900 block mt-1">
            {orders.filter((o) => o.status === 'shipped').length} টি
          </span>
          <span className="text-[11px] text-purple-600 font-semibold">ডেলিভারির পথে</span>
        </div>
      </div>

      {/* Tab Filter */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
        <div className="flex gap-2 border-b border-slate-100 pb-3">
          {[
            { id: 'all', label: 'সব শিপমেন্ট' },
            { id: 'shipped', label: 'চলতি ডেলিভারি (Shipped)' },
            { id: 'delivered', label: 'সফল ডেলিভারি (Delivered)' },
            { id: 'returned', label: 'রিটার্ন পার্সেল (Returned)' }
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === t.id
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Shipments List */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
              <tr>
                <th className="py-3 px-3">অর্ডার নং</th>
                <th className="py-3 px-3">কুরিয়ার সার্ভিস</th>
                <th className="py-3 px-3">ট্র্যাকিং কোড</th>
                <th className="py-3 px-3">গ্রাহক ও জেলা</th>
                <th className="py-3 px-3 text-right">COD মূল্য</th>
                <th className="py-3 px-3 text-center">স্ট্যাটাস</th>
                <th className="py-3 px-3 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.map((ord) => (
                <tr key={ord.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-3 font-mono font-bold text-slate-900">#{ord.id}</td>
                  <td className="py-3 px-3 font-bold text-slate-800">
                    {ord.courierName === 'steadfast' ? 'Steadfast Courier' : ord.courierName ? 'ম্যানুয়াল কুরিয়ার' : 'অনির্ধারিত'}
                  </td>
                  <td className="py-3 px-3 font-mono text-purple-900 font-bold">
                    {ord.courierDetails?.trackingCode || 'বুকিং বাকি'}
                  </td>
                  <td className="py-3 px-3">
                    <span className="font-bold text-slate-900 block">{ord.customerName}</span>
                    <span className="text-slate-500 text-[11px]">{ord.district}</span>
                  </td>
                  <td className="py-3 px-3 text-right font-black text-emerald-800">
                    ৳{ord.total.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        ord.status === 'delivered'
                          ? 'bg-emerald-100 text-emerald-800'
                          : ord.status === 'returned'
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-purple-100 text-purple-800'
                      }`}
                    >
                      {ord.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right space-x-1">
                    {!ord.courierDetails?.trackingCode && (
                      <button
                        onClick={() => handleOpenManualBooking(ord)}
                        className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold"
                      >
                        ম্যানুয়াল বুকিং
                      </button>
                    )}
                    {ord.status === 'shipped' && (
                      <button
                        onClick={() => handleMarkReturned(ord.id)}
                        className="px-2 py-1 bg-orange-50 hover:bg-orange-100 text-orange-800 rounded-lg text-xs font-bold border border-orange-200"
                      >
                        রিটার্ন চিহ্নিত
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Booking Modal */}
      {manualModal && selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full text-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900">ম্যানুয়াল কুরিয়ার বুকিং - #{selectedOrder.id}</h4>
            <form onSubmit={handleSaveManualBooking} className="space-y-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">কুরিয়ার সার্ভিসের নাম</label>
                <select
                  value={courierName}
                  onChange={(e) => setCourierName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                >
                  <option value="Pathao Courier">Pathao Courier</option>
                  <option value="RedX Logistics">RedX Logistics</option>
                  <option value="Sundarban Courier">সুন্দরবন কুরিয়ার (Sundarban)</option>
                  <option value="Paperfly">Paperfly</option>
                  <option value="SA Paribahan">এস এ পরিবহন (SA Paribahan)</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">ট্র্যাকিং নম্বর বা চালান কোড *</label>
                <input
                  type="text"
                  required
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                />
              </div>
              <div className="flex gap-2 pt-3">
                <button type="button" onClick={() => setManualModal(false)} className="flex-1 py-2 font-bold bg-slate-100 rounded-xl">বাতিল</button>
                <button type="submit" className="flex-1 py-2 font-bold bg-emerald-700 text-white rounded-xl">বুকিং নিশ্চিত করুন</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
