import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  ShoppingBag,
  FileSpreadsheet,
  Printer,
  Plus,
  Trash2,
  Calendar,
  Wallet,
  CheckCircle,
  Building,
  Users,
  CreditCard,
  Layers,
  ArrowRight
} from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';
import {
  PurchaseRecord,
  ExpenseRecord,
  SalaryRecord,
  CustomerDueRecord,
  FinancialAccount
} from '../../types/index.ts';

export const AdminAccounting: React.FC = () => {
  const { orders } = useStore();

  const [summary, setSummary] = useState<any>(null);
  const [purchases, setPurchases] = useState<PurchaseRecord[]>([]);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>([]);
  const [salaries, setSalaries] = useState<SalaryRecord[]>([]);
  const [customerDues, setCustomerDues] = useState<CustomerDueRecord[]>([]);
  const [accounts, setAccounts] = useState<FinancialAccount[]>([]);

  const [activeTab, setActiveTab] = useState<'overview' | 'purchases' | 'expenses' | 'salaries' | 'dues' | 'accounts' | 'pnl'>('overview');

  // Modals
  const [purchaseModal, setPurchaseModal] = useState(false);
  const [purForm, setPurForm] = useState({
    supplierName: '',
    invoiceNo: `PUR-${Date.now().toString().slice(-4)}`,
    itemsDescription: 'চামড়ার জুতো ও সোল চালান',
    quantity: 20,
    totalCost: 28000,
    paidAmount: 28000,
    paymentMethod: 'ক্যাশ',
    date: new Date().toISOString().split('T')[0],
    notes: ''
  });

  const [expenseModal, setExpenseModal] = useState(false);
  const [expForm, setExpForm] = useState({
    category: 'rent' as any,
    title: '',
    amount: 1500,
    paymentMethod: 'ক্যাশ',
    date: new Date().toISOString().split('T')[0],
    recipient: '',
    notes: ''
  });

  const [salaryModal, setSalaryModal] = useState(false);
  const [salForm, setSalForm] = useState({
    staffName: '',
    designation: 'সেলস এক্সিকিউটিভ',
    month: 'মার্চ ২০২৬',
    amount: 12000,
    bonus: 0,
    paymentStatus: 'paid' as any,
    paymentMethod: 'ক্যাশ'
  });

  const [dueModal, setDueModal] = useState(false);
  const [dueForm, setDueForm] = useState({
    customerName: '',
    customerPhone: '',
    totalBill: 3500,
    paidAmount: 2000,
    dueAmount: 1500,
    notes: ''
  });

  const loadData = async () => {
    try {
      const [sum, pur, exp, sal, dues, acc] = await Promise.all([
        api.getAccountingSummary(),
        api.getPurchases(),
        api.getExpenses(),
        api.getSalaries(),
        api.getCustomerDues(),
        api.getAccounts()
      ]);
      setSummary(sum);
      setPurchases(pur);
      setExpenses(exp);
      setSalaries(sal);
      setCustomerDues(dues);
      setAccounts(acc);
    } catch (e) {
      console.error('Accounting load error', e);
    }
  };

  useEffect(() => {
    loadData();
  }, [orders]);

  // Handle Add Purchase
  const handleSavePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    await api.createPurchase(purForm);
    setPurchaseModal(false);
    await loadData();
  };

  // Handle Add Expense
  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    await api.createExpense(expForm);
    setExpenseModal(false);
    await loadData();
  };

  // Handle Add Salary
  const handleSaveSalary = async (e: React.FormEvent) => {
    e.preventDefault();
    await api.createSalary(salForm);
    setSalaryModal(false);
    await loadData();
  };

  // Handle Add Due
  const handleSaveDue = async (e: React.FormEvent) => {
    e.preventDefault();
    await api.createCustomerDue(dueForm);
    setDueModal(false);
    await loadData();
  };

  // Settle Customer Due
  const handleSettleDue = async (id: string, due: CustomerDueRecord) => {
    await api.updateCustomerDue(id, { isSettled: !due.isSettled });
    await loadData();
  };

  // Print PNL
  const handlePrintReport = () => {
    window.print();
  };

  // Export PNL CSV
  const handleExportCSV = () => {
    const csv = [
      ['FOOT STEPS SHOES - Accounting Report'],
      ['Date', new Date().toLocaleDateString()],
      [],
      ['Metric', 'Amount (BDT)'],
      ['Total Delivered Revenue', summary?.totalDeliveredRevenue || 0],
      ['Cost of Goods Sold (COGS)', summary?.totalCOGS || 0],
      ['Gross Profit', summary?.grossProfit || 0],
      ['Total Shop Expenses', summary?.totalExpenses || 0],
      ['Total Staff Salaries', summary?.totalSalaries || 0],
      ['Courier Return Losses', summary?.courierReturnLoss || 0],
      ['Net Profit', summary?.netProfit || 0],
      ['Total Stock Cost Value', summary?.totalStockCost || 0],
      ['Total Stock Retail Potential', summary?.totalStockRetail || 0],
      ['Total Cash & Bank Balance', summary?.totalCashBank || 0]
    ]
      .map((row) => row.join(','))
      .join('\n');

    const encodedUri = encodeURI('data:text/csv;charset=utf-8,\uFEFF' + csv);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `footsteps_accounting_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            হিসাব নিকাশ ও আর্থিক রিপোর্ট (Accounting & Reports)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            লাভ-ক্ষতির হিসাব, মোট বিক্রি, খরচ, কর্মচারীদের বেতন, বাকি খাতা ও স্টক ভ্যালুয়েশন
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Excel / CSV</span>
          </button>
          <button
            onClick={handlePrintReport}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>রিপোর্ট প্রিন্ট</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1.5 bg-slate-100 rounded-2xl border border-slate-200 text-xs font-bold">
        {[
          { id: 'overview', label: 'আর্থিক ওভারভিউ' },
          { id: 'pnl', label: 'লাভ-ক্ষতি বিবরণী (P&L)' },
          { id: 'purchases', label: `ইনভেন্টরি ক্রয় (${purchases.length})` },
          { id: 'expenses', label: `দোকানের খরচ (${expenses.length})` },
          { id: 'salaries', label: `বেতন-ভাতা (${salaries.length})` },
          { id: 'dues', label: `কাস্টমার বাকি খাতা (${customerDues.filter((d) => !d.isSettled).length})` },
          { id: 'accounts', label: `ক্যাশ ও ব্যাংক (${accounts.length})` }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3.5 py-2 rounded-xl transition-all ${
              activeTab === tab.id
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'text-slate-600 hover:text-emerald-800 hover:bg-white/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Financial Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Main Profit Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-white border border-slate-200">
              <span className="text-xs font-bold text-slate-500 uppercase">মোট ডেলিভার্ড বিক্রয়</span>
              <span className="text-2xl font-black text-emerald-900 block mt-1">
                ৳{(summary?.totalDeliveredRevenue || 0).toLocaleString()}
              </span>
              <span className="text-[11px] text-slate-400">ডেলিভার্ড পার্সেল থেকে আয়</span>
            </div>

            <div className="p-5 rounded-2xl bg-white border border-slate-200">
              <span className="text-xs font-bold text-slate-500 uppercase">পণ্যের ক্রয় খরচ (COGS)</span>
              <span className="text-2xl font-black text-slate-800 block mt-1">
                ৳{(summary?.totalCOGS || 0).toLocaleString()}
              </span>
              <span className="text-[11px] text-slate-400">বিক্রিত জুতোর মোট খরচ</span>
            </div>

            <div className="p-5 rounded-2xl bg-white border border-slate-200">
              <span className="text-xs font-bold text-slate-500 uppercase">মোট গ্রস প্রফিট</span>
              <span className="text-2xl font-black text-emerald-700 block mt-1">
                ৳{(summary?.grossProfit || 0).toLocaleString()}
              </span>
              <span className="text-[11px] text-emerald-600 font-semibold">বিক্রি বিয়োগ ক্রয় খরচ</span>
            </div>

            <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-800 to-emerald-950 text-white shadow-md">
              <span className="text-xs font-bold text-emerald-300 uppercase">নিট প্রফিট (Net Profit)</span>
              <span className="text-2xl font-black text-white block mt-1">
                ৳{(summary?.netProfit || 0).toLocaleString()}
              </span>
              <span className="text-[11px] text-emerald-200">সকল খরচ ও বেতন বাদে</span>
            </div>
          </div>

          {/* Secondary stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 bg-white rounded-2xl border border-slate-200">
              <span className="text-[11px] font-bold text-slate-500 uppercase">দোকানের মোট খরচ</span>
              <span className="text-lg font-black text-slate-900 block mt-1">
                ৳{(summary?.totalExpenses || 0).toLocaleString()}
              </span>
              <span className="text-[10px] text-slate-400">ভাড়া, বিদ্যুৎ, প্যাকেজিং</span>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200">
              <span className="text-[11px] font-bold text-slate-500 uppercase">কর্মচারীদের মোট বেতন</span>
              <span className="text-lg font-black text-slate-900 block mt-1">
                ৳{(summary?.totalSalaries || 0).toLocaleString()}
              </span>
              <span className="text-[10px] text-slate-400">পরিশোধিত বেতন ও বোনাস</span>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200">
              <span className="text-[11px] font-bold text-slate-500 uppercase">কাস্টমার বাকি পাওনা</span>
              <span className="text-lg font-black text-amber-700 block mt-1">
                ৳{(summary?.totalCustomerDue || 0).toLocaleString()}
              </span>
              <span className="text-[10px] text-amber-600 font-semibold">আদায়যোগ্য বকেয়া</span>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200">
              <span className="text-[11px] font-bold text-slate-500 uppercase">বর্তমান স্টক ভ্যালু</span>
              <span className="text-lg font-black text-slate-900 block mt-1">
                ৳{(summary?.totalStockCost || 0).toLocaleString()}
              </span>
              <span className="text-[10px] text-slate-400">
                খুচরা বিক্রয় মূল্য: ৳{(summary?.totalStockRetail || 0).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Profit & Loss Statement (P&L) */}
      {activeTab === 'pnl' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-8 max-w-3xl mx-auto shadow-xs">
          <div className="text-center border-b-2 border-emerald-800 pb-4 mb-6">
            <h3 className="text-2xl font-black text-emerald-900">FOOT STEPS SHOES</h3>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-0.5">
              লাভ ও ক্ষতি বিবরণী (Profit & Loss Statement)
            </p>
            <p className="text-xs text-slate-400 mt-1">
              প্রস্তুতের তারিখ: {new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>

          <div className="space-y-4 text-xs">
            {/* 1. Revenue */}
            <div>
              <div className="flex justify-between font-bold text-sm text-slate-900 border-b border-slate-200 pb-1.5">
                <span>১. পরিচালন বিক্রয় রাজস্ব (Gross Revenue):</span>
                <span>৳{(summary?.totalSalesRevenue || 0).toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 text-slate-600 pl-4">
                <span>সফলভাবে ডেলিভার্ড ও ক্যাশ আদায়:</span>
                <span>৳{(summary?.totalDeliveredRevenue || 0).toLocaleString()}</span>
              </div>
            </div>

            {/* 2. COGS */}
            <div>
              <div className="flex justify-between font-bold text-sm text-slate-900 border-b border-slate-200 pb-1.5">
                <span>২. বিক্রিত পণ্যের ক্রয় খরচ (Cost of Goods Sold - COGS):</span>
                <span className="text-red-700">- ৳{(summary?.totalCOGS || 0).toLocaleString()}</span>
              </div>
            </div>

            {/* 3. Gross Profit */}
            <div className="flex justify-between py-2 px-3 bg-emerald-50 rounded-xl font-black text-sm text-emerald-900">
              <span>মোট মোট লাভ (Gross Profit):</span>
              <span>৳{(summary?.grossProfit || 0).toLocaleString()}</span>
            </div>

            {/* 4. Operating Expenses */}
            <div>
              <div className="font-bold text-sm text-slate-900 border-b border-slate-200 pb-1.5">
                ৩. পরিচালন ও শোরুম খরচাবলী (Operating Expenses):
              </div>
              <div className="space-y-1.5 pl-4 py-2">
                <div className="flex justify-between text-slate-600">
                  <span>শোরুম ভাড়া, বিদ্যুৎ ও মার্কেটিং খরচ:</span>
                  <span className="font-bold text-slate-800">৳{(summary?.totalExpenses || 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>কর্মচারীদের বেতন ও বোনাস:</span>
                  <span className="font-bold text-slate-800">৳{(summary?.totalSalaries || 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>কুরিয়ার রিটার্ন পার্সেল ক্ষতি:</span>
                  <span className="font-bold text-slate-800">৳{(summary?.courierReturnLoss || 0).toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* 5. Net Profit */}
            <div className="flex justify-between py-3 px-4 bg-emerald-900 text-white rounded-2xl font-black text-base shadow-lg">
              <span>প্রকৃত নিট মুনাফা (Net Profit):</span>
              <span className="text-emerald-300">৳{(summary?.netProfit || 0).toLocaleString()}</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Inventory Purchases */}
      {activeTab === 'purchases' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              ইনভেন্টরি ও চামড়া ক্রয় চালান সমূহ
            </h3>
            <button
              onClick={() => setPurchaseModal(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Plus className="w-4 h-4" />
              নতুন ক্রয় চালান এন্ট্রি
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
                <tr>
                  <th className="py-3 px-3">তারিখ</th>
                  <th className="py-3 px-3">চালান নং</th>
                  <th className="py-3 px-3">সাপ্লায়ার নাম</th>
                  <th className="py-3 px-3">বিবরণ</th>
                  <th className="py-3 px-3 text-center">পরিমাণ</th>
                  <th className="py-3 px-3 text-right">মোট বিল</th>
                  <th className="py-3 px-3 text-right">পরিশোধ</th>
                  <th className="py-3 px-3 text-right">বাকি</th>
                  <th className="py-3 px-3 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {purchases.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3 text-slate-500">{p.date}</td>
                    <td className="py-3 px-3 font-mono font-bold">{p.invoiceNo}</td>
                    <td className="py-3 px-3 font-bold text-slate-900">{p.supplierName}</td>
                    <td className="py-3 px-3 text-slate-600 truncate max-w-xs">{p.itemsDescription}</td>
                    <td className="py-3 px-3 text-center font-bold text-slate-700">{p.quantity} পিস</td>
                    <td className="py-3 px-3 text-right font-bold text-slate-900">৳{p.totalCost.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right text-emerald-700 font-bold">৳{p.paidAmount.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right text-red-600 font-bold">৳{p.dueAmount.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={async () => {
                          if (confirm('মুছে ফেলতে চান?')) {
                            await api.deletePurchase(p.id);
                            await loadData();
                          }
                        }}
                        className="text-slate-400 hover:text-red-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: Expenses */}
      {activeTab === 'expenses' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              দোকানের সাধারণ খরচসমূহ (Expenses)
            </h3>
            <button
              onClick={() => setExpenseModal(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Plus className="w-4 h-4" />
              নতুন খরচ এন্ট্রি
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
                <tr>
                  <th className="py-3 px-3">তারিখ</th>
                  <th className="py-3 px-3">ক্যাটাগরি</th>
                  <th className="py-3 px-3">খরচের শিরোনাম</th>
                  <th className="py-3 px-3">প্রাপক</th>
                  <th className="py-3 px-3">মাধ্যম</th>
                  <th className="py-3 px-3 text-right">পরিমাণ (৳)</th>
                  <th className="py-3 px-3 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {expenses.map((e) => (
                  <tr key={e.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3 text-slate-500">{e.date}</td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                        {e.category}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-bold text-slate-900">{e.title}</td>
                    <td className="py-3 px-3 text-slate-600">{e.recipient || '-'}</td>
                    <td className="py-3 px-3 text-slate-500">{e.paymentMethod}</td>
                    <td className="py-3 px-3 text-right font-black text-red-600">৳{e.amount.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={async () => {
                          if (confirm('মুছে ফেলতে চান?')) {
                            await api.deleteExpense(e.id);
                            await loadData();
                          }
                        }}
                        className="text-slate-400 hover:text-red-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 5: Salaries */}
      {activeTab === 'salaries' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              কর্মচারীদের বেতন-ভাতা বিবরণী
            </h3>
            <button
              onClick={() => setSalaryModal(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Plus className="w-4 h-4" />
              বেতন প্রদান এন্ট্রি
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
                <tr>
                  <th className="py-3 px-3">কর্মচারীর নাম</th>
                  <th className="py-3 px-3">পদবী</th>
                  <th className="py-3 px-3">মাস</th>
                  <th className="py-3 px-3 text-right">মূল বেতন</th>
                  <th className="py-3 px-3 text-right">বোনাস</th>
                  <th className="py-3 px-3 text-right">সর্বমোট</th>
                  <th className="py-3 px-3 text-center">স্ট্যাটাস</th>
                  <th className="py-3 px-3 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {salaries.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3 font-bold text-slate-900">{s.staffName}</td>
                    <td className="py-3 px-3 text-slate-600">{s.designation}</td>
                    <td className="py-3 px-3 font-medium text-slate-700">{s.month}</td>
                    <td className="py-3 px-3 text-right font-bold text-slate-800">৳{s.amount.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right text-emerald-700 font-bold">৳{(s.bonus || 0).toLocaleString()}</td>
                    <td className="py-3 px-3 text-right font-black text-slate-900">
                      ৳{(s.amount + (s.bonus || 0)).toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                        {s.paymentStatus === 'paid' ? 'পরিশোধিত' : 'পেন্ডিং'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={async () => {
                          if (confirm('মুছে ফেলতে চান?')) {
                            await api.deleteSalary(s.id);
                            await loadData();
                          }
                        }}
                        className="text-slate-400 hover:text-red-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 6: Customer Dues */}
      {activeTab === 'dues' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              কাস্টমার বাকি খাতা (Customer Dues)
            </h3>
            <button
              onClick={() => setDueModal(true)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95"
            >
              <Plus className="w-4 h-4" />
              নতুন বাকি এন্ট্রি
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
                <tr>
                  <th className="py-3 px-3">গ্রাহকের নাম</th>
                  <th className="py-3 px-3">মোবাইল নম্বর</th>
                  <th className="py-3 px-3 text-right">মোট বিল</th>
                  <th className="py-3 px-3 text-right">পরিশোধ</th>
                  <th className="py-3 px-3 text-right">বাকি টাকা</th>
                  <th className="py-3 px-3">নোট</th>
                  <th className="py-3 px-3 text-center">স্ট্যাটাস</th>
                  <th className="py-3 px-3 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {customerDues.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3 font-bold text-slate-900">{d.customerName}</td>
                    <td className="py-3 px-3 font-mono">{d.customerPhone}</td>
                    <td className="py-3 px-3 text-right font-bold">৳{d.totalBill.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right text-emerald-700 font-bold">৳{d.paidAmount.toLocaleString()}</td>
                    <td className="py-3 px-3 text-right text-red-600 font-black">৳{d.dueAmount.toLocaleString()}</td>
                    <td className="py-3 px-3 text-slate-500 truncate max-w-xs">{d.notes || '-'}</td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          d.isSettled ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {d.isSettled ? 'পরিশোধিত' : 'বকেয়া আছে'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleSettleDue(d.id, d)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                          d.isSettled
                            ? 'bg-slate-100 text-slate-600'
                            : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800'
                        }`}
                      >
                        {d.isSettled ? 'পুনরায় বকেয়া' : 'পরিশোধ চিহ্নিত'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 7: Accounts (Cash, bKash, Bank) */}
      {activeTab === 'accounts' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
            ক্যাশ ও ব্যাংক অ্যাকাউন্ট ব্যালেন্স ট্র্যাকার
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {accounts.map((acc) => (
              <div key={acc.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-800 block">{acc.name}</span>
                  {acc.accountNumber && (
                    <span className="text-[11px] text-slate-500 font-mono block mt-0.5">{acc.accountNumber}</span>
                  )}
                  <span className="text-xl font-black text-emerald-900 block mt-2">
                    ৳{acc.balance.toLocaleString()}
                  </span>
                </div>
                <div className="mt-4 pt-2 border-t border-slate-200 flex justify-between items-center text-[11px]">
                  <span className="text-slate-400">আপডেট: {new Date(acc.updatedAt).toLocaleDateString()}</span>
                  <button
                    onClick={async () => {
                      const newBal = prompt(`"${acc.name}" এর নতুন ব্যালেন্স কত লিখবেন?`, String(acc.balance));
                      if (newBal !== null) {
                        await api.updateAccount(acc.id, { balance: Number(newBal) || 0 });
                        await loadData();
                      }
                    }}
                    className="font-bold text-emerald-700 hover:underline"
                  >
                    হালনাগাদ
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Purchase Modal */}
      {purchaseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full text-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900">নতুন ইনভেন্টরি ক্রয় এন্ট্রি</h4>
            <form onSubmit={handleSavePurchase} className="space-y-3">
              <div>
                <label className="block font-bold mb-1">সাপ্লায়ার নাম *</label>
                <input
                  type="text"
                  required
                  value={purForm.supplierName}
                  onChange={(e) => setPurForm({ ...purForm, supplierName: e.target.value })}
                  placeholder="যেমন: ঢাকা ট্যানারি"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">চালান বিবরণ *</label>
                <input
                  type="text"
                  required
                  value={purForm.itemsDescription}
                  onChange={(e) => setPurForm({ ...purForm, itemsDescription: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold mb-1">পরিমাণ (পিস)</label>
                  <input
                    type="number"
                    value={purForm.quantity}
                    onChange={(e) => setPurForm({ ...purForm, quantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">মোট মূল্য (৳) *</label>
                  <input
                    type="number"
                    required
                    value={purForm.totalCost}
                    onChange={(e) => setPurForm({ ...purForm, totalCost: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold mb-1">পরিশোধ (৳)</label>
                  <input
                    type="number"
                    value={purForm.paidAmount}
                    onChange={(e) => setPurForm({ ...purForm, paidAmount: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">তারিখ</label>
                  <input
                    type="date"
                    value={purForm.date}
                    onChange={(e) => setPurForm({ ...purForm, date: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>
              <div className="flex gap-2 pt-3">
                <button type="button" onClick={() => setPurchaseModal(false)} className="flex-1 py-2 bg-slate-100 rounded-xl font-bold">বাতিল</button>
                <button type="submit" className="flex-1 py-2 bg-emerald-700 text-white rounded-xl font-bold">সেভ করুন</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Expense Modal */}
      {expenseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full text-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900">নতুন খরচ এন্ট্রি</h4>
            <form onSubmit={handleSaveExpense} className="space-y-3">
              <div>
                <label className="block font-bold mb-1">খরচের খাত *</label>
                <select
                  value={expForm.category}
                  onChange={(e) => setExpForm({ ...expForm, category: e.target.value as any })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                >
                  <option value="rent">দোকান ভাড়া</option>
                  <option value="utility">বিদ্যুৎ / ওয়াইফাই বিল</option>
                  <option value="packaging">প্যাকেজিং বক্স ও ব্যাগ</option>
                  <option value="marketing">ফেসবুক বিজ্ঞাপন / মার্কেটিং</option>
                  <option value="transport">পরিবহন খরচ</option>
                  <option value="other">অন্যান্য সাধারণ খরচ</option>
                </select>
              </div>
              <div>
                <label className="block font-bold mb-1">খরচের শিরোনাম *</label>
                <input
                  type="text"
                  required
                  value={expForm.title}
                  onChange={(e) => setExpForm({ ...expForm, title: e.target.value })}
                  placeholder="যেমন: মার্চ মাসের দোকান ভাড়া"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold mb-1">টাকার পরিমাণ (৳) *</label>
                  <input
                    type="number"
                    required
                    value={expForm.amount}
                    onChange={(e) => setExpForm({ ...expForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">পরিশোধের মাধ্যম</label>
                  <input
                    type="text"
                    value={expForm.paymentMethod}
                    onChange={(e) => setExpForm({ ...expForm, paymentMethod: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>
              <div className="flex gap-2 pt-3">
                <button type="button" onClick={() => setExpenseModal(false)} className="flex-1 py-2 bg-slate-100 rounded-xl font-bold">বাতিল</button>
                <button type="submit" className="flex-1 py-2 bg-emerald-700 text-white rounded-xl font-bold">সেভ করুন</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Salary Modal */}
      {salaryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full text-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900">বেতন প্রদান এন্ট্রি</h4>
            <form onSubmit={handleSaveSalary} className="space-y-3">
              <div>
                <label className="block font-bold mb-1">কর্মচারীর নাম *</label>
                <input
                  type="text"
                  required
                  value={salForm.staffName}
                  onChange={(e) => setSalForm({ ...salForm, staffName: e.target.value })}
                  placeholder="যেমন: মোঃ সোহেল রানা"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">পদবী</label>
                <input
                  type="text"
                  value={salForm.designation}
                  onChange={(e) => setSalForm({ ...salForm, designation: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold mb-1">বেতন (৳) *</label>
                  <input
                    type="number"
                    required
                    value={salForm.amount}
                    onChange={(e) => setSalForm({ ...salForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">বোনাস (৳)</label>
                  <input
                    type="number"
                    value={salForm.bonus}
                    onChange={(e) => setSalForm({ ...salForm, bonus: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>
              <div className="flex gap-2 pt-3">
                <button type="button" onClick={() => setSalaryModal(false)} className="flex-1 py-2 bg-slate-100 rounded-xl font-bold">বাতিল</button>
                <button type="submit" className="flex-1 py-2 bg-emerald-700 text-white rounded-xl font-bold">সেভ করুন</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Due Modal */}
      {dueModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full text-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900">নতুন কাস্টমার বাকি এন্ট্রি</h4>
            <form onSubmit={handleSaveDue} className="space-y-3">
              <div>
                <label className="block font-bold mb-1">গ্রাহকের নাম *</label>
                <input
                  type="text"
                  required
                  value={dueForm.customerName}
                  onChange={(e) => setDueForm({ ...dueForm, customerName: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">মোবাইল নম্বর</label>
                <input
                  type="text"
                  value={dueForm.customerPhone}
                  onChange={(e) => setDueForm({ ...dueForm, customerPhone: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold mb-1">মোট বিল (৳)</label>
                  <input
                    type="number"
                    value={dueForm.totalBill}
                    onChange={(e) => setDueForm({ ...dueForm, totalBill: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">বাকি টাকা (৳) *</label>
                  <input
                    type="number"
                    required
                    value={dueForm.dueAmount}
                    onChange={(e) => setDueForm({ ...dueForm, dueAmount: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-black text-red-600"
                  />
                </div>
              </div>
              <div className="flex gap-2 pt-3">
                <button type="button" onClick={() => setDueModal(false)} className="flex-1 py-2 bg-slate-100 rounded-xl font-bold">বাতিল</button>
                <button type="submit" className="flex-1 py-2 bg-emerald-700 text-white rounded-xl font-bold">সেভ করুন</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
