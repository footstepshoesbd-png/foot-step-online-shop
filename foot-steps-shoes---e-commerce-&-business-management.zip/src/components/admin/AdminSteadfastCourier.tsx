import React, { useState, useEffect } from 'react';
import {
  Truck,
  Key,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  DollarSign,
  AlertCircle,
  Package,
  Clock,
  Save,
  Send
} from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';
import { Order, SteadfastSettings } from '../../types/index.ts';

export const AdminSteadfastCourier: React.FC = () => {
  const { orders, refreshData } = useStore();

  const [settings, setSettings] = useState<any>({
    apiKey: '',
    secretKey: '',
    baseUrl: 'https://portal.steadfast.com.bd/api/v1',
    senderName: 'FOOT STEPS SHOES',
    senderPhone: '01819876543',
    senderAddress: 'Shop 12, Green Tower, Trunk Road, Feni',
    isLive: false,
    autoBookOnConfirm: false
  });

  const [savingSettings, setSavingSettings] = useState(false);
  const [saveMsg, setSaveMsg] = useState(false);

  // Booking Modal
  const [bookingModalOrder, setBookingModalOrder] = useState<Order | null>(null);
  const [bookingCodAmount, setBookingCodAmount] = useState<number>(0);
  const [bookingNote, setBookingNote] = useState('');
  const [isBooking, setIsBooking] = useState(false);
  const [bookingResult, setBookingResult] = useState<any>(null);

  // Live status checking
  const [statusLoadingMap, setStatusLoadingMap] = useState<{ [trackingCode: string]: boolean }>({});

  useEffect(() => {
    api.getSteadfastSettings().then((data) => {
      setSettings(data);
    }).catch(console.error);
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSavingSettings(true);
      await api.updateSteadfastSettings(settings);
      setSaveMsg(true);
      setTimeout(() => setSaveMsg(false), 2000);
    } catch (err) {
      alert('সেটিংস সংরক্ষণ ব্যর্থ হয়েছে');
    } finally {
      setSavingSettings(false);
    }
  };

  const openBookModal = (order: Order) => {
    setBookingModalOrder(order);
    setBookingCodAmount(order.codAmount || order.total);
    setBookingNote(`FOOT STEPS SHOES Order #${order.id} - ${order.customerName}`);
    setBookingResult(null);
  };

  const handleExecuteBooking = async () => {
    if (!bookingModalOrder) return;
    try {
      setIsBooking(true);
      const res = await api.bookSteadfast(bookingModalOrder.id, bookingCodAmount, bookingNote);
      if (res.success) {
        setBookingResult(res.consignment);
        await refreshData();
      }
    } catch (err: any) {
      alert(err.message || 'বুকিং ব্যর্থ হয়েছে');
    } finally {
      setIsBooking(false);
    }
  };

  const handleCheckStatus = async (trackingCode: string) => {
    try {
      setStatusLoadingMap((prev) => ({ ...prev, [trackingCode]: true }));
      const statusRes = await api.checkSteadfastStatus(trackingCode);
      await refreshData();
      alert(`লাইভ স্ট্যাটাস: ${statusRes.delivery_status || 'ইন-রিভিউ'}`);
    } catch (e: any) {
      alert('স্ট্যাটাস জানতে সমস্যা হয়েছে');
    } finally {
      setStatusLoadingMap((prev) => ({ ...prev, [trackingCode]: false }));
    }
  };

  // Orders eligible for booking
  const eligibleOrders = orders.filter((o) => !o.courierDetails?.trackingCode && ['confirmed', 'pending', 'processing'].includes(o.status));
  // Booked parcels
  const bookedOrders = orders.filter((o) => Boolean(o.courierDetails?.trackingCode));

  // Metrics
  const totalBookedCod = bookedOrders.reduce((sum, o) => sum + (o.courierDetails?.codAmount || o.codAmount), 0);
  const deliveredParcels = bookedOrders.filter((o) => o.status === 'delivered');
  const deliveredCod = deliveredParcels.reduce((sum, o) => sum + (o.courierDetails?.codAmount || o.codAmount), 0);
  const pendingSettlement = totalBookedCod - deliveredCod;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-700 text-white flex items-center justify-center font-bold">
              <Truck className="w-4 h-4" />
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              অফিসিয়াল স্টেডফাস্ট কুরিয়ার (Steadfast Courier API)
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            ১-ক্লিকে পার্সেল বুকিং, লাইভ ট্র্যাকিং, কনসাইনমেন্ট আইডি ও COD সেটেলমেন্ট হিসাব
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`px-3 py-1 text-xs font-bold rounded-full border ${
              settings.hasKeys
                ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                : 'bg-amber-100 text-amber-800 border-amber-300'
            }`}
          >
            {settings.hasKeys ? 'API চাবি কনফিগার করা আছে' : 'API চাবি পেন্ডিং (সিমুলেশন মোড)'}
          </span>
        </div>
      </div>

      {/* 1. Steadfast Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white border border-slate-200">
          <span className="text-[11px] font-bold text-slate-500 uppercase">মোট বুক করা পার্সেল</span>
          <span className="text-2xl font-black text-purple-900 block mt-1">{bookedOrders.length} টি</span>
          <span className="text-[10px] text-slate-400">স্টেডফাস্ট নেটওয়ার্কে</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200">
          <span className="text-[11px] font-bold text-slate-500 uppercase">সফল ডেলিভারি</span>
          <span className="text-2xl font-black text-emerald-800 block mt-1">{deliveredParcels.length} টি</span>
          <span className="text-[10px] text-emerald-600 font-semibold">আদায়কৃত: ৳{deliveredCod.toLocaleString()}</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200">
          <span className="text-[11px] font-bold text-slate-500 uppercase">বুকিংয়ের জন্য প্রস্তুত</span>
          <span className="text-2xl font-black text-amber-700 block mt-1">{eligibleOrders.length} টি</span>
          <span className="text-[10px] text-amber-600 font-semibold">কনফার্মকৃত অর্ডার</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200">
          <span className="text-[11px] font-bold text-slate-500 uppercase">মোট প্রদেয় COD</span>
          <span className="text-2xl font-black text-slate-900 block mt-1">৳{totalBookedCod.toLocaleString()}</span>
          <span className="text-[10px] text-slate-500">পেন্ডিং সেটেলমেন্ট: ৳{pendingSettlement.toLocaleString()}</span>
        </div>
      </div>

      {/* 2. Steadfast API Configuration Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-purple-700" />
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              স্টেডফাস্ট API ক্রেডেনশিয়াল ও সেটিংস
            </h3>
          </div>
          {saveMsg && (
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg">
              ✓ সংরক্ষিত হয়েছে
            </span>
          )}
        </div>

        <form onSubmit={handleSaveSettings} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Steadfast API Key *
              </label>
              <input
                type="text"
                value={settings.apiKey}
                onChange={(e) => setSettings({ ...settings, apiKey: e.target.value })}
                placeholder="আপনার স্টেডফাস্ট পোর্টাল থেকে প্রাপ্ত Api-Key"
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:border-purple-600 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Steadfast Secret Key *
              </label>
              <input
                type="password"
                value={settings.secretKey}
                onChange={(e) => setSettings({ ...settings, secretKey: e.target.value })}
                placeholder="••••••••••••••••"
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:border-purple-600 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                প্রেরকের নাম (Sender Name)
              </label>
              <input
                type="text"
                value={settings.senderName}
                onChange={(e) => setSettings({ ...settings, senderName: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                প্রেরকের ফোন (Sender Phone)
              </label>
              <input
                type="text"
                value={settings.senderPhone}
                onChange={(e) => setSettings({ ...settings, senderPhone: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                লাইভ মোড চালুকরণ
              </label>
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="isLive"
                  checked={settings.isLive}
                  onChange={(e) => setSettings({ ...settings, isLive: e.target.checked })}
                  className="w-4 h-4 accent-purple-700 cursor-pointer"
                />
                <label htmlFor="isLive" className="text-xs font-bold text-slate-700 cursor-pointer">
                  {settings.isLive ? 'লাইভ API সংযোগ সক্রিয়' : 'টেস্ট / সিমুলেটর মোড (নিরাপদ)'}
                </label>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center pt-2">
            <span className="text-[11px] text-slate-500">
              * আপনার এপিআই তথ্য সার্ভার সাইডে সুরক্ষিতভাবে এনক্রিপ্ট করে সেভ রাখা হয়।
            </span>
            <button
              type="submit"
              disabled={savingSettings}
              className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{savingSettings ? 'সংরক্ষণ হচ্ছে...' : 'API সেটিংস সেভ করুন'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* 3. Orders Ready to Book */}
      {eligibleOrders.length > 0 && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Package className="w-4 h-4 text-amber-600" />
              বুকিংয়ের জন্য প্রস্তুত অর্ডার ({eligibleOrders.length})
            </h3>
            <span className="text-xs text-slate-500">১-ক্লিকে কুরিয়ারে পাঠান</span>
          </div>

          <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden">
            {eligibleOrders.map((ord) => (
              <div key={ord.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white hover:bg-slate-50">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-slate-900 text-sm">#{ord.id}</span>
                    <span className="text-xs font-bold text-slate-800">{ord.customerName}</span>
                    <span className="text-[11px] text-slate-500 font-mono">({ord.customerPhone})</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5 truncate max-w-md">
                    {ord.customerAddress} ({ord.district})
                  </p>
                  <p className="text-[11px] text-slate-500 font-semibold mt-0.5">
                    পণ্য: {ord.items.map((i) => `${i.productName} (${i.size})`).join(', ')}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-xs text-slate-400 block text-[10px]">COD আদায়</span>
                    <span className="text-sm font-black text-emerald-800">৳{ord.codAmount.toLocaleString()}</span>
                  </div>

                  <button
                    onClick={() => openBookModal(ord)}
                    className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 active:scale-95 transition-all"
                  >
                    <Send className="w-3.5 h-3.5" />
                    স্টেডফাস্টে বুক করুন
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Booked Parcels Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          স্টেডফাস্টে বুক করা পার্সেল সমূহ ({bookedOrders.length})
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
              <tr>
                <th className="py-3 px-3">অর্ডার নং</th>
                <th className="py-3 px-3">কনসাইনমেন্ট ও ট্র্যাকিং</th>
                <th className="py-3 px-3">গ্রাহক ও এলাকা</th>
                <th className="py-3 px-3 text-right">COD মূল্য</th>
                <th className="py-3 px-3 text-center">কুরিয়ার স্ট্যাটাস</th>
                <th className="py-3 px-3 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {bookedOrders.map((ord) => {
                const trk = ord.courierDetails?.trackingCode || '';
                const isLoading = statusLoadingMap[trk];
                return (
                  <tr key={ord.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3 font-mono font-bold text-slate-900">#{ord.id}</td>
                    <td className="py-3 px-3">
                      <span className="font-mono font-black text-purple-900 block text-[13px]">
                        {ord.courierDetails?.trackingCode}
                      </span>
                      {ord.courierDetails?.consignmentId && (
                        <span className="text-[10px] text-slate-400 font-mono">
                          CID: #{ord.courierDetails.consignmentId}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-bold text-slate-800 block">{ord.customerName}</span>
                      <span className="text-slate-500 text-[11px]">{ord.district}</span>
                    </td>
                    <td className="py-3 px-3 text-right font-black text-emerald-800">
                      ৳{(ord.courierDetails?.codAmount || ord.codAmount).toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800">
                        {ord.courierDetails?.courierStatus || ord.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        disabled={isLoading}
                        onClick={() => handleCheckStatus(trk)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-purple-50 text-purple-800 border border-slate-200 rounded-lg text-xs font-bold inline-flex items-center gap-1"
                      >
                        <RefreshCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
                        <span>চেক স্ট্যাটাস</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Booking Confirmation Modal */}
      {bookingModalOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl">
            <h3 className="font-bold text-base text-slate-900 mb-1">
              স্টেডফাস্ট কুরিয়ার বুকিং - #{bookingModalOrder.id}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              গ্রাহকের তথ্য যাচাই করে বুকিং নিশ্চিত করুন
            </p>

            {bookingResult ? (
              <div className="py-6 text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                <h4 className="font-bold text-slate-900 text-base">পার্সেল সফলভাবে বুক করা হয়েছে!</h4>
                <div className="p-3 bg-purple-50 rounded-xl text-xs font-mono text-purple-900">
                  <p>ট্র্যাকিং কোড: <span className="font-black">{bookingResult.tracking_code}</span></p>
                  <p>কনসাইনমেন্ট আইডি: #{bookingResult.consignment_id}</p>
                </div>
                <button
                  onClick={() => setBookingModalOrder(null)}
                  className="w-full py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold"
                >
                  সম্পন্ন
                </button>
              </div>
            ) : (
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <p><span className="font-bold text-slate-700">গ্রাহক:</span> {bookingModalOrder.customerName}</p>
                  <p><span className="font-bold text-slate-700">ফোন:</span> {bookingModalOrder.customerPhone}</p>
                  <p><span className="font-bold text-slate-700">ঠিকানা:</span> {bookingModalOrder.customerAddress}</p>
                  <p><span className="font-bold text-slate-700">জেলা:</span> {bookingModalOrder.district}</p>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    ক্যাশ অন ডেলিভারি (COD) পরিমাণ (টাকা) *
                  </label>
                  <input
                    type="number"
                    value={bookingCodAmount}
                    onChange={(e) => setBookingCodAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black text-emerald-900 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">পার্সেল নোট</label>
                  <input
                    type="text"
                    value={bookingNote}
                    onChange={(e) => setBookingNote(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                  />
                </div>

                <div className="flex gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setBookingModalOrder(null)}
                    className="flex-1 py-2.5 font-bold bg-slate-100 rounded-xl text-slate-700"
                  >
                    বাতিল
                  </button>
                  <button
                    type="button"
                    disabled={isBooking}
                    onClick={handleExecuteBooking}
                    className="flex-1 py-2.5 font-bold bg-purple-700 hover:bg-purple-800 text-white rounded-xl shadow-md"
                  >
                    {isBooking ? 'বুকিং হচ্ছে...' : 'নিশ্চিত করুন'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
