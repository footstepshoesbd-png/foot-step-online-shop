import React, { useState } from 'react';
import {
  ShoppingBag,
  Search,
  Filter,
  Printer,
  Truck,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  Download,
  FileSpreadsheet,
  Clock,
  Eye,
  Check
} from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';
import { Order, OrderStatus } from '../../types/index.ts';
import { PrintInvoiceModal } from '../shared/PrintInvoiceModal.tsx';

export const AdminOrderManager: React.FC = () => {
  const { orders, refreshData, settings } = useStore();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);

  // Edit Order modal state
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [editFormData, setEditFormData] = useState({
    customerName: '',
    customerPhone: '',
    customerAddress: '',
    district: '',
    status: 'pending' as OrderStatus,
    adminNotes: ''
  });

  // Filter orders
  const filteredOrders = orders.filter((o) => {
    if (statusFilter !== 'all' && o.status !== statusFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchId = o.id.toLowerCase().includes(q);
      const matchName = o.customerName.toLowerCase().includes(q);
      const matchPhone = o.customerPhone.includes(q);
      const matchDist = o.district.toLowerCase().includes(q);
      if (!matchId && !matchName && !matchPhone && !matchDist) return false;
    }
    return true;
  });

  const handleQuickStatusChange = async (orderId: string, newStatus: OrderStatus) => {
    try {
      await api.updateOrderStatus(orderId, newStatus, `অ্যাডমিন স্ট্যাটাস পরিবর্তন করেছেন: ${newStatus}`);
      await refreshData();
    } catch (e) {
      alert('স্ট্যাটাস পরিবর্তনে সমস্যা হয়েছে');
    }
  };

  const handleOpenEdit = (order: Order) => {
    setEditingOrder(order);
    setEditFormData({
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      customerAddress: order.customerAddress,
      district: order.district,
      status: order.status,
      adminNotes: order.adminNotes || ''
    });
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOrder) return;
    try {
      await api.updateOrder(editingOrder.id, editFormData);
      setEditingOrder(null);
      await refreshData();
    } catch (e) {
      alert('অর্ডার আপডেট ব্যর্থ হয়েছে');
    }
  };

  const handleDelete = async (orderId: string) => {
    if (!confirm(`আপনি কি নিশ্চিত যে অর্ডার #${orderId} ডিলিট করতে চান?`)) return;
    await api.deleteOrder(orderId);
    await refreshData();
  };

  // Export to Excel / CSV
  const handleExportCSV = () => {
    const headers = ['Order ID', 'Customer Name', 'Phone', 'Address', 'District', 'Total', 'Status', 'Date'];
    const rows = filteredOrders.map((o) => [
      o.id,
      `"${o.customerName}"`,
      `"${o.customerPhone}"`,
      `"${o.customerAddress}"`,
      `"${o.district}"`,
      o.total,
      o.status,
      o.createdAt
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `footsteps_orders_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const statusBadges: { [k: string]: { label: string; badge: string } } = {
    pending: { label: 'অপেক্ষমান (Pending)', badge: 'bg-amber-100 text-amber-800' },
    confirmed: { label: 'নিশ্চিত (Confirmed)', badge: 'bg-blue-100 text-blue-800' },
    processing: { label: 'প্যাকিং (Processing)', badge: 'bg-indigo-100 text-indigo-800' },
    shipped: { label: 'শিফট (Shipped)', badge: 'bg-purple-100 text-purple-800' },
    delivered: { label: 'ডেলিভার্ড (Delivered)', badge: 'bg-emerald-100 text-emerald-800' },
    cancelled: { label: 'বাতিল (Cancelled)', badge: 'bg-red-100 text-red-800' },
    returned: { label: 'রিটার্ন (Returned)', badge: 'bg-orange-100 text-orange-800' }
  };

  return (
    <div className="space-y-6">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            অর্ডার ম্যানেজমেন্ট ({orders.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            সব অর্ডারের তালিকা, স্ট্যাটাস পরিবর্তন, গ্রাহক তথ্য এডিট, ইনভয়েস প্রিন্ট ও এক্সেল ডাউনলোড
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Excel / CSV ডাউনলোড</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search */}
      <div className="bg-white rounded-3xl border border-slate-200 p-4 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="অর্ডার আইডি, গ্রাহকের নাম বা মোবাইল নম্বর দিয়ে খুঁজুন..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>

          {/* Status count pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-bold">
            {[
              { id: 'all', label: `সব (${orders.length})` },
              { id: 'pending', label: `পেন্ডিং (${orders.filter((o) => o.status === 'pending').length})` },
              { id: 'confirmed', label: `নিশ্চিত (${orders.filter((o) => o.status === 'confirmed').length})` },
              { id: 'shipped', label: `শিফট (${orders.filter((o) => o.status === 'shipped').length})` },
              { id: 'delivered', label: `ডেলিভার্ড (${orders.filter((o) => o.status === 'delivered').length})` },
              { id: 'cancelled', label: `বাতিল (${orders.filter((o) => o.status === 'cancelled').length})` },
              { id: 'returned', label: `রিটার্ন (${orders.filter((o) => o.status === 'returned').length})` }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id)}
                className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
                  statusFilter === tab.id
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Orders Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
              <tr>
                <th className="py-3 px-3">অর্ডার আইডি</th>
                <th className="py-3 px-3">তারিখ</th>
                <th className="py-3 px-3">গ্রাহক ও ফোন</th>
                <th className="py-3 px-3">ডেলিভারি ঠিকানা</th>
                <th className="py-3 px-3">পণ্যের বিবরণ</th>
                <th className="py-3 px-3 text-right">মূল্য (৳)</th>
                <th className="py-3 px-3 text-center">স্ট্যাটাস পরিবর্তন</th>
                <th className="py-3 px-3 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.length > 0 ? (
                filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3">
                      <span className="font-mono font-black text-slate-900 block">#{order.id}</span>
                      {order.courierDetails?.trackingCode && (
                        <span className="text-[10px] text-purple-700 font-mono font-bold">
                          {order.courierDetails.trackingCode}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-slate-500 text-[11px] whitespace-nowrap">
                      {new Date(order.createdAt).toLocaleDateString('bn-BD', { month: 'short', day: 'numeric' })}
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-bold text-slate-900 block">{order.customerName}</span>
                      <a href={`tel:${order.customerPhone}`} className="text-emerald-700 font-mono font-semibold text-[11px] hover:underline">
                        {order.customerPhone}
                      </a>
                    </td>
                    <td className="py-3 px-3 text-slate-600 max-w-[200px]">
                      <span className="truncate block">{order.customerAddress}</span>
                      <span className="text-[10px] text-slate-400 font-bold">{order.district}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-700">
                      {order.items.map((it, idx) => (
                        <span key={idx} className="block truncate max-w-[170px]">
                          {it.productName} ({it.size}) × {it.quantity}
                        </span>
                      ))}
                    </td>
                    <td className="py-3 px-3 text-right font-black text-emerald-800 whitespace-nowrap">
                      ৳{order.total.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <select
                        value={order.status}
                        onChange={(e) => handleQuickStatusChange(order.id, e.target.value as OrderStatus)}
                        className={`text-[11px] font-bold px-2 py-1 rounded-lg border outline-none cursor-pointer ${
                          statusBadges[order.status]?.badge || 'bg-slate-100'
                        }`}
                      >
                        <option value="pending">পেন্ডিং</option>
                        <option value="confirmed">কনফার্ম</option>
                        <option value="processing">প্রসেসিং</option>
                        <option value="shipped">শিফট (কুরিয়ার)</option>
                        <option value="delivered">ডেলিভার্ড</option>
                        <option value="cancelled">বাতিল</option>
                        <option value="returned">রিটার্ন</option>
                      </select>
                    </td>
                    <td className="py-3 px-3 text-right whitespace-nowrap space-x-1">
                      {/* Print Invoice */}
                      <button
                        onClick={() => setSelectedInvoiceOrder(order)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800"
                        title="ইনভয়েস প্রিন্ট"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                      {/* Edit */}
                      <button
                        onClick={() => handleOpenEdit(order)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-blue-100 text-slate-700 hover:text-blue-800"
                        title="এডিট"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      {/* Delete */}
                      <button
                        onClick={() => handleDelete(order.id)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-red-100 text-slate-400 hover:text-red-700"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    কোনো অর্ডার পাওয়া যায়নি।
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Order Modal */}
      {editingOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl">
            <h3 className="font-bold text-sm text-slate-900 mb-4">
              অর্ডার সম্পাদনা - #{editingOrder.id}
            </h3>
            <form onSubmit={handleSaveEdit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">গ্রাহকের নাম</label>
                <input
                  type="text"
                  required
                  value={editFormData.customerName}
                  onChange={(e) => setEditFormData({ ...editFormData, customerName: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
                <input
                  type="text"
                  required
                  value={editFormData.customerPhone}
                  onChange={(e) => setEditFormData({ ...editFormData, customerPhone: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">ঠিকানা</label>
                <textarea
                  rows={2}
                  value={editFormData.customerAddress}
                  onChange={(e) => setEditFormData({ ...editFormData, customerAddress: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">জেলা</label>
                <input
                  type="text"
                  value={editFormData.district}
                  onChange={(e) => setEditFormData({ ...editFormData, district: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">স্ট্যাটাস</label>
                <select
                  value={editFormData.status}
                  onChange={(e) => setEditFormData({ ...editFormData, status: e.target.value as OrderStatus })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold"
                >
                  <option value="pending">পেন্ডিং</option>
                  <option value="confirmed">কনফার্ম</option>
                  <option value="processing">প্রসেসিং</option>
                  <option value="shipped">শিফট</option>
                  <option value="delivered">ডেলিভার্ড</option>
                  <option value="cancelled">বাতিল</option>
                  <option value="returned">রিটার্ন</option>
                </select>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingOrder(null)}
                  className="flex-1 py-2 font-bold bg-slate-100 rounded-xl"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 font-bold bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl"
                >
                  আপডেট করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invoice Modal */}
      <PrintInvoiceModal
        order={selectedInvoiceOrder}
        settings={settings}
        isOpen={Boolean(selectedInvoiceOrder)}
        onClose={() => setSelectedInvoiceOrder(null)}
      />
    </div>
  );
};
