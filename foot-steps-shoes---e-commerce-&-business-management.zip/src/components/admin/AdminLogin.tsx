import React, { useState } from 'react';
import { ShieldCheck, Lock, User, ArrowLeft, KeyRound, AlertCircle } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';

interface AdminLoginProps {
  onBackToSite: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onBackToSite }) => {
  const { login } = useStore();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const ok = await login(username, password);
      if (!ok) {
        setError('ইউজারনেম বা পাসওয়ার্ড সঠিক নয়। (ডিফল্ট: admin / admin)');
      }
    } catch (err: any) {
      setError(err.message || 'লগইন করতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoFill = (u: string, p: string) => {
    setUsername(u);
    setPassword(p);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 flex flex-col justify-center items-center p-4">
      {/* Back to site button */}
      <button
        onClick={onBackToSite}
        className="absolute top-6 left-6 text-emerald-200 hover:text-white flex items-center gap-2 text-xs sm:text-sm font-semibold transition-colors bg-white/10 px-4 py-2 rounded-xl backdrop-blur-sm"
      >
        <ArrowLeft className="w-4 h-4" />
        ওয়েবসাইটে ফিরে যান
      </button>

      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-8 border border-slate-100">
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-br from-emerald-700 to-emerald-900 flex items-center justify-center text-white shadow-xl shadow-emerald-900/30">
            <ShieldCheck className="w-8 h-8 text-emerald-300" />
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">
            FOOT STEPS SHOES
          </h1>
          <p className="text-xs font-bold text-emerald-700 uppercase tracking-wider mt-0.5">
            সেন্ট্রাল অ্যাডমিন কন্ট্রোল প্যানেল
          </p>
          <p className="text-xs text-slate-500 mt-1">
            নিরাপদ অ্যাক্সেসের জন্য আপনার ক্রেডেনশিয়াল প্রদান করুন
          </p>
        </div>

        {error && (
          <div className="mb-6 p-3.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              ইউজারনেম (Username)
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:bg-white focus:border-emerald-600 transition-colors"
              />
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              পাসওয়ার্ড (Password)
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:bg-white focus:border-emerald-600 transition-colors"
              />
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3.5 bg-emerald-800 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm shadow-lg shadow-emerald-900/25 transition-all active:scale-98 flex items-center justify-center gap-2 ${
              loading ? 'opacity-70 cursor-not-allowed' : ''
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>{loading ? 'যাচাই করা হচ্ছে...' : 'লগইন করুন'}</span>
          </button>
        </form>

        {/* Quick Demo Access Helpers */}
        <div className="mt-8 pt-6 border-t border-slate-100">
          <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 text-center">
            টেস্টিং ডেমো ক্রেডেনশিয়াল (ক্লিক করুন)
          </p>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={() => handleQuickDemoFill('admin', 'admin')}
              className="p-2 bg-slate-50 hover:bg-emerald-50 rounded-lg border border-slate-200 text-slate-700 font-semibold text-center hover:border-emerald-300 transition-colors"
            >
              👑 সুপার অ্যাডমিন
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemoFill('manager', 'admin')}
              className="p-2 bg-slate-50 hover:bg-emerald-50 rounded-lg border border-slate-200 text-slate-700 font-semibold text-center hover:border-emerald-300 transition-colors"
            >
              💼 শোরুম ম্যানেজার
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
