import React, { useState } from 'react';
import {
  Package,
  Plus,
  Search,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Star,
  Flame,
  Tag,
  DollarSign
} from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';
import { Product, ProductSize } from '../../types/index.ts';

export const AdminProductManager: React.FC = () => {
  const { products, categories, refreshData } = useStore();

  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('all');

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const [form, setForm] = useState({
    sku: '',
    name: '',
    banglaName: '',
    description: '',
    category: categories[0]?.id || 'cat-formal',
    regularPrice: 2500,
    salePrice: 1950,
    costPrice: 1200,
    images: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600',
    sizes: [
      { size: '39', stock: 5 },
      { size: '40', stock: 8 },
      { size: '41', stock: 12 },
      { size: '42', stock: 10 },
      { size: '43', stock: 6 },
      { size: '44', stock: 4 }
    ],
    colors: 'Black, Brown',
    isFeatured: true,
    isNewArrival: true,
    isBestSeller: false,
    isActive: true
  });

  const handleOpenAdd = () => {
    setEditingProduct(null);
    setForm({
      sku: `FS-${Math.floor(100 + Math.random() * 900)}`,
      name: 'New Leather Shoe',
      banglaName: 'নতুন প্রিমিয়াম লেদার জুতো',
      description: '১০০% অরিজিনাল খাঁটি চামড়ার জুতো। আরামদায়ক কুশন ইনসোল ও অ্যান্টি-স্লিপ গ্রিপ যুক্ত।',
      category: categories[0]?.id || 'cat-formal',
      regularPrice: 2600,
      salePrice: 1990,
      costPrice: 1200,
      images: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600',
      sizes: [
        { size: '39', stock: 5 },
        { size: '40', stock: 8 },
        { size: '41', stock: 12 },
        { size: '42', stock: 10 },
        { size: '43', stock: 6 },
        { size: '44', stock: 4 }
      ],
      colors: 'Black, Dark Brown',
      isFeatured: true,
      isNewArrival: true,
      isBestSeller: false,
      isActive: true
    });
    setModalOpen(true);
  };

  const handleOpenEdit = (p: Product) => {
    setEditingProduct(p);
    setForm({
      sku: p.sku,
      name: p.name,
      banglaName: p.banglaName || p.name,
      description: p.description || '',
      category: p.category,
      regularPrice: p.regularPrice,
      salePrice: p.salePrice,
      costPrice: p.costPrice || Math.round(p.salePrice * 0.6),
      images: p.images.join(', '),
      sizes: p.sizes || [
        { size: '39', stock: 5 },
        { size: '40', stock: 5 },
        { size: '41', stock: 5 },
        { size: '42', stock: 5 }
      ],
      colors: (p.colors || []).join(', '),
      isFeatured: p.isFeatured,
      isNewArrival: p.isNewArrival,
      isBestSeller: p.isBestSeller,
      isActive: p.isActive
    });
    setModalOpen(true);
  };

  const handleSizeStockChange = (size: string, stock: number) => {
    setForm((prev) => ({
      ...prev,
      sizes: prev.sizes.map((s) => (s.size === size ? { ...s, stock: Math.max(0, stock) } : s))
    }));
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const imageList = form.images
      .split(',')
      .map((img) => img.trim())
      .filter(Boolean);

    const colorList = form.colors
      .split(',')
      .map((c) => c.trim())
      .filter(Boolean);

    const totalStock = form.sizes.reduce((sum, s) => sum + Number(s.stock || 0), 0);

    const payload = {
      sku: form.sku,
      name: form.name,
      banglaName: form.banglaName,
      description: form.description,
      category: form.category,
      regularPrice: Number(form.regularPrice),
      salePrice: Number(form.salePrice),
      costPrice: Number(form.costPrice),
      images: imageList.length > 0 ? imageList : ['https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600'],
      sizes: form.sizes,
      totalStock,
      colors: colorList,
      isFeatured: form.isFeatured,
      isNewArrival: form.isNewArrival,
      isBestSeller: form.isBestSeller,
      isActive: form.isActive
    };

    if (editingProduct) {
      await api.updateProduct(editingProduct.id, payload);
    } else {
      await api.createProduct(payload);
    }

    setModalOpen(false);
    await refreshData();
  };

  const handleDelete = async (p: Product) => {
    if (!confirm(`আপনি কি নিশ্চিত যে "${p.banglaName || p.name}" পণ্যটি মুছে ফেলতে চান?`)) return;
    await api.deleteProduct(p.id);
    await refreshData();
  };

  const filteredProducts = products.filter((p) => {
    if (selectedCat !== 'all' && p.category !== selectedCat) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchName = (p.banglaName || '').toLowerCase().includes(q) || p.name.toLowerCase().includes(q);
      const matchSku = p.sku.toLowerCase().includes(q);
      if (!matchName && !matchSku) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            পণ্য স্টক ও ক্যাটালগ ম্যানেজমেন্ট ({products.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            নতুন জুতো যুক্ত করুন, মূল্য ও ছাড় নির্ধারণ করুন, সাইজ ভিত্তিক স্টক হালনাগাদ করুন
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-700/20 active:scale-95 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>নতুন জুতো যুক্ত করুন</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-white rounded-3xl border border-slate-200 p-4 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="পণ্যের নাম বা SKU দিয়ে খুঁজুন..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-bold">
            <button
              onClick={() => setSelectedCat('all')}
              className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
                selectedCat === 'all'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              সব ক্যাটাগরি
            </button>
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCat(c.id)}
                className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
                  selectedCat === c.id
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {c.banglaName}
              </button>
            ))}
          </div>
        </div>

        {/* Products Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
              <tr>
                <th className="py-3 px-3">জুতো ও ছবি</th>
                <th className="py-3 px-3">SKU</th>
                <th className="py-3 px-3">ক্যাটাগরি</th>
                <th className="py-3 px-3 text-right">রেগুলার মূল্য</th>
                <th className="py-3 px-3 text-right">বিক্রয় মূল্য</th>
                <th className="py-3 px-3 text-right">ক্রয় মূল্য (Cost)</th>
                <th className="py-3 px-3 text-center">স্টক সংখ্যা</th>
                <th className="py-3 px-3 text-center">স্ট্যাটাস</th>
                <th className="py-3 px-3 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.map((p) => {
                const discount = p.regularPrice > p.salePrice ? Math.round(((p.regularPrice - p.salePrice) / p.regularPrice) * 100) : 0;
                const catObj = categories.find((c) => c.id === p.category);
                return (
                  <tr key={p.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={p.images[0] || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=100'}
                          alt={p.name}
                          className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                        />
                        <div>
                          <span className="font-bold text-slate-900 block truncate max-w-[200px]">
                            {p.banglaName || p.name}
                          </span>
                          <div className="flex items-center gap-1 mt-0.5">
                            {p.isBestSeller && (
                              <span className="text-[9px] font-bold text-amber-800 bg-amber-100 px-1 rounded">
                                বেস্ট সেলার
                              </span>
                            )}
                            {p.isFeatured && (
                              <span className="text-[9px] font-bold text-emerald-800 bg-emerald-100 px-1 rounded">
                                ফিচার্ড
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-slate-700">{p.sku}</td>
                    <td className="py-3 px-3 text-slate-600">{catObj?.banglaName || p.category}</td>
                    <td className="py-3 px-3 text-right text-slate-400 line-through">
                      ৳{p.regularPrice.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-right font-black text-emerald-800">
                      ৳{p.salePrice.toLocaleString()}
                      {discount > 0 && <span className="block text-[10px] text-red-600 font-bold">(-{discount}%)</span>}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-600">
                      ৳{p.costPrice.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full font-bold text-[11px] ${
                          p.totalStock <= 0
                            ? 'bg-red-100 text-red-800'
                            : p.totalStock <= 5
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {p.totalStock} জোড়া
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className={`text-[10px] font-bold ${p.isActive ? 'text-emerald-700' : 'text-slate-400'}`}>
                        {p.isActive ? 'সক্রিয়' : 'লুকানো'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right space-x-1">
                      <button
                        onClick={() => handleOpenEdit(p)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800"
                        title="এডিট"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(p)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-red-100 text-slate-400 hover:text-red-700"
                        title="ডিলিট"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Product Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl p-6 shadow-2xl my-6 max-h-[90vh] overflow-y-auto">
            <h3 className="font-bold text-base text-slate-900 mb-4">
              {editingProduct ? 'জুতো আপডেট করুন' : 'নতুন জুতো ক্যাটালগে যুক্ত করুন'}
            </h3>

            <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">SKU / আর্টিকেল কোড *</label>
                  <input
                    type="text"
                    required
                    value={form.sku}
                    onChange={(e) => setForm({ ...form, sku: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">বাংলা শিরোনাম *</label>
                  <input
                    type="text"
                    required
                    value={form.banglaName}
                    onChange={(e) => setForm({ ...form, banglaName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">ইংরেজি নাম</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">ক্যাটাগরি *</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.banglaName} ({c.name})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Pricing & Cost */}
              <div className="grid grid-cols-3 gap-3 p-3 bg-emerald-50/70 border border-emerald-100 rounded-2xl">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">রেগুলার মূল্য (৳)</label>
                  <input
                    type="number"
                    required
                    value={form.regularPrice}
                    onChange={(e) => setForm({ ...form, regularPrice: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-900 mb-1">বিক্রয় মূল্য (৳) *</label>
                  <input
                    type="number"
                    required
                    value={form.salePrice}
                    onChange={(e) => setForm({ ...form, salePrice: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 bg-white border border-emerald-300 rounded-xl font-black text-emerald-800"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">ক্রয় মূল্য (Cost) ৳</label>
                  <input
                    type="number"
                    required
                    value={form.costPrice}
                    onChange={(e) => setForm({ ...form, costPrice: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              {/* Sizes and Stock */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">সাইজ ভিত্তিক স্টক সংখ্যা:</span>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {form.sizes.map((s) => (
                    <div key={s.size} className="p-2 bg-white rounded-xl border border-slate-200 text-center">
                      <span className="font-bold text-slate-700 block text-[11px]">সাইজ {s.size}</span>
                      <input
                        type="number"
                        min="0"
                        value={s.stock}
                        onChange={(e) => handleSizeStockChange(s.size, Number(e.target.value))}
                        className="w-full px-1 py-1 mt-1 bg-slate-50 border border-slate-200 rounded-lg text-center font-bold text-xs"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Images */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  ছবির লিঙ্ক (Image URLs - কমা দিয়ে একাধিক দিতে পারেন) *
                </label>
                <textarea
                  rows={2}
                  value={form.images}
                  onChange={(e) => setForm({ ...form, images: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-[11px]"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">বিবরণ</label>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              {/* Flags */}
              <div className="flex flex-wrap gap-4 pt-2">
                <label className="flex items-center gap-1.5 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={form.isFeatured}
                    onChange={(e) => setForm({ ...form, isFeatured: e.target.checked })}
                    className="accent-emerald-700"
                  />
                  <span>ফিচার্ড জুতো</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={form.isBestSeller}
                    onChange={(e) => setForm({ ...form, isBestSeller: e.target.checked })}
                    className="accent-emerald-700"
                  />
                  <span>বেস্ট সেলার</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={form.isNewArrival}
                    onChange={(e) => setForm({ ...form, isNewArrival: e.target.checked })}
                    className="accent-emerald-700"
                  />
                  <span>নতুন কালেকশন</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer font-bold text-emerald-800">
                  <input
                    type="checkbox"
                    checked={form.isActive}
                    onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                    className="accent-emerald-700"
                  />
                  <span>ওয়েবসাইটে দৃশ্যমান রাখুন</span>
                </label>
              </div>

              {/* Buttons */}
              <div className="flex gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex-1 py-2.5 font-bold bg-slate-100 hover:bg-slate-200 rounded-xl text-slate-700"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 font-bold bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl shadow-md"
                >
                  {editingProduct ? 'আপডেট করুন' : 'পণ্য যোগ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
