import React from 'react';
import { Printer, X, CheckCircle, Package } from 'lucide-react';
import { Order, WebsiteSettings } from '../../types/index.ts';

interface PrintInvoiceModalProps {
  order: Order | null;
  settings: WebsiteSettings | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PrintInvoiceModal: React.FC<PrintInvoiceModalProps> = ({
  order,
  settings,
  isOpen,
  onClose
}) => {
  if (!isOpen || !order) return null;

  const handlePrint = () => {
    window.print();
  };

  const deliveryAreaLabel = {
    feni_city: 'ফেনী সিটি / সদর (Feni City)',
    outside_feni: 'ফেনীর বাইরে (Outside Feni)',
    express: 'জরুরি এক্সপ্রেস ডেলিভারি (Express)',
    custom: order.district || 'কাস্টম এরিয়া'
  }[order.deliveryArea] || order.deliveryArea;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Top Controls (Hidden in Print) */}
        <div className="no-print flex items-center justify-between px-6 py-4 bg-emerald-800 text-white">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-emerald-300" />
            <h2 className="text-lg font-bold">ইনভয়েস প্রিন্ট প্রিভিউ - #{order.id}</h2>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-white rounded-lg font-semibold text-sm transition-all shadow-md active:scale-95"
            >
              <Printer className="w-4 h-4" />
              প্রিন্ট করুন
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-emerald-900/50 hover:bg-emerald-900 text-white/80 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Sheet */}
        <div className="p-8 font-sans text-slate-800 bg-white">
          {/* Header */}
          <div className="flex justify-between items-start border-b-2 border-emerald-800 pb-6 mb-6">
            <div>
              <h1 className="text-2xl font-black text-emerald-800 tracking-tight">
                {settings?.brandName || 'FOOT STEPS SHOES'}
              </h1>
              <p className="text-xs text-slate-600 font-medium mt-1">
                {settings?.brandTagline || 'ফেনীর সেরা প্রিমিয়াম লেদার জুতো কালেকশন'}
              </p>
              <p className="text-xs text-slate-500 mt-2 max-w-xs">
                {settings?.shopAddress || 'শপ নং ১২, গ্রিন টাওয়ার, ট্রাঙ্ক রোড, ফেনী সদর, ফেনী'}
              </p>
              <p className="text-xs text-slate-600 mt-1 font-semibold">
                হটলাইন: {settings?.phoneNumber || '01819-876543'} | {settings?.whatsappNumber}
              </p>
            </div>
            <div className="text-right">
              <span className="inline-block px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full mb-2">
                ক্যাশ অন ডেলিভারি মেমো
              </span>
              <p className="text-base font-bold text-slate-900">ইনভয়েস নং: #{order.id}</p>
              <p className="text-xs text-slate-500 mt-1">
                তারিখ: {new Date(order.createdAt).toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
              <p className="text-xs text-slate-500">
                সময়: {new Date(order.createdAt).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>

          {/* Customer & Delivery Information */}
          <div className="grid grid-cols-2 gap-6 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs mb-6">
            <div>
              <p className="font-bold text-emerald-800 uppercase tracking-wider text-[11px] mb-1">
                গ্রাহকের বিবরণ (Customer Details)
              </p>
              <p className="font-bold text-sm text-slate-900">{order.customerName}</p>
              <p className="font-semibold text-slate-700 mt-1 text-sm">{order.customerPhone}</p>
              <p className="text-slate-600 mt-1 leading-relaxed">
                <span className="font-semibold">ঠিকানা:</span> {order.customerAddress}
              </p>
            </div>
            <div>
              <p className="font-bold text-emerald-800 uppercase tracking-wider text-[11px] mb-1">
                ডেলিভারি ও কুরিয়ার তথ্য (Shipping)
              </p>
              <p className="text-slate-700">
                <span className="font-semibold">এলাকা:</span> {deliveryAreaLabel}
              </p>
              <p className="text-slate-700 mt-1">
                <span className="font-semibold">জেলা:</span> {order.district}
              </p>
              {order.courierDetails?.trackingCode ? (
                <div className="mt-2 p-2 bg-emerald-50 border border-emerald-200 rounded">
                  <p className="font-bold text-emerald-800">কুরিয়ার: Steadfast Courier</p>
                  <p className="text-emerald-700 text-[11px]">
                    ট্র্যাকিং কোড: <span className="font-mono font-bold">{order.courierDetails.trackingCode}</span>
                  </p>
                </div>
              ) : (
                <p className="text-slate-500 mt-1">কুরিয়ার: লোকাল হোম ডেলিভারি / পেন্ডিং</p>
              )}
              {order.customerNotes && (
                <p className="text-slate-500 mt-1 italic">
                  <span className="font-semibold">নোট:</span> {order.customerNotes}
                </p>
              )}
            </div>
          </div>

          {/* Order Items Table */}
          <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden mb-6">
            <thead className="bg-emerald-800 text-white font-semibold">
              <tr>
                <th className="py-2.5 px-3">#</th>
                <th className="py-2.5 px-3">পণ্যের বিবরণ (Item)</th>
                <th className="py-2.5 px-3 text-center">সাইজ</th>
                <th className="py-2.5 px-3 text-center">পরিমাণ</th>
                <th className="py-2.5 px-3 text-right">একক মূল্য</th>
                <th className="py-2.5 px-3 text-right">মোট (৳)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {order.items.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 text-slate-500">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">
                    {item.productName}
                    <span className="block text-[10px] text-slate-500 font-mono">SKU: {item.sku}</span>
                  </td>
                  <td className="py-2.5 px-3 text-center font-bold text-slate-700 bg-slate-50">
                    {item.size}
                  </td>
                  <td className="py-2.5 px-3 text-center font-semibold text-slate-700">
                    {item.quantity}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-600">
                    ৳{item.price.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                    ৳{item.total.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totals & COD Amount */}
          <div className="flex justify-between items-start mb-8">
            <div className="max-w-xs text-[11px] text-slate-600 space-y-1">
              <p className="font-bold text-slate-800">নির্দেশনা ও শর্তাবলী:</p>
              <p>১. ডেলিভারি ম্যানের সামনে প্রোডাক্ট দেখে ও ট্রায়াল দিয়ে রিসিভ করুন।</p>
              <p>২. সাইজ পরিবর্তন বা ডিফেক্টের জন্য ৭ দিনের মধ্যে এক্সচেঞ্জ সুবিধা পাবেন।</p>
              <p>৩. যেকোনো প্রয়োজনে ইনভয়েস নং সহ আমাদের কাস্টমার কেয়ারে কল করুন।</p>
            </div>
            <div className="w-64 space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600">সাবটোটাল (Subtotal):</span>
                <span className="font-bold text-slate-800">৳{order.subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600">ডেলিভারি চার্জ:</span>
                <span className="font-bold text-slate-800">
                  {order.deliveryCharge === 0 ? 'ফ্রি (Free)' : `৳${order.deliveryCharge}`}
                </span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between py-1 border-b border-slate-100 text-emerald-600">
                  <span>ডিসকাউন্ট:</span>
                  <span className="font-bold">- ৳{order.discount}</span>
                </div>
              )}
              <div className="flex justify-between py-2 border-t-2 border-emerald-800 text-sm font-black text-emerald-900 bg-emerald-50 px-2 rounded">
                <span>সর্বমোট পরিশোধযোগ্য (COD):</span>
                <span>৳{order.codAmount.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Signatures */}
          <div className="flex justify-between items-end pt-8 border-t border-slate-200 text-xs text-slate-600">
            <div className="text-center">
              <div className="w-36 border-b border-slate-400 mb-1"></div>
              <p>গ্রাহকের স্বাক্ষর</p>
            </div>
            <div className="text-center">
              <p className="font-bold text-emerald-800 mb-1">{settings?.brandName || 'FOOT STEPS SHOES'}</p>
              <div className="w-40 border-b border-slate-400 mb-1"></div>
              <p>কর্তৃপক্ষের স্বাক্ষর ও সিল</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
