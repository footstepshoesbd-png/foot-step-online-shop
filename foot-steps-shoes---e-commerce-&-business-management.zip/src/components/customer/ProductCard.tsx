import React, { useState } from 'react';
import { ShoppingBag, Zap, Eye, Check } from 'lucide-react';
import { Product } from '../../types/index.ts';
import { useStore } from '../../context/StoreContext.tsx';

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onViewDetails }) => {
  const { addToCart, openQuickBuy } = useStore();

  // Find first size that has stock > 0
  const availableSizes = product.sizes.filter((s) => s.stock > 0);
  const defaultSize = availableSizes[0]?.size || product.sizes[0]?.size || '41';
  const [selectedSize, setSelectedSize] = useState<string>(defaultSize);
  const [addedAnimation, setAddedAnimation] = useState(false);

  const discountPercent =
    product.regularPrice > product.salePrice
      ? Math.round(((product.regularPrice - product.salePrice) / product.regularPrice) * 100)
      : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, selectedSize, 1);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1200);
  };

  const handleQuickBuy = (e: React.MouseEvent) => {
    e.stopPropagation();
    openQuickBuy(product, selectedSize);
  };

  const isOutOfStock = product.totalStock <= 0;

  return (
    <div
      onClick={() => onViewDetails(product)}
      className="group relative bg-white rounded-2xl border border-slate-200/90 hover:border-emerald-500/80 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden cursor-pointer"
    >
      {/* 1. Image & Badges Container */}
      <div className="relative aspect-square bg-slate-100 overflow-hidden">
        <img
          src={product.images[0] || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600'}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-500"
          loading="lazy"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start z-10">
          {discountPercent > 0 && (
            <span className="px-2.5 py-1 bg-red-600 text-white text-[11px] font-black rounded-lg shadow-sm">
              {discountPercent}% ছাড়
            </span>
          )}
          {product.isBestSeller && (
            <span className="px-2 py-0.5 bg-amber-500 text-white text-[10px] font-bold rounded-md shadow-sm">
              বেস্ট সেলার
            </span>
          )}
          {product.isNewArrival && (
            <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded-md shadow-sm">
              নতুন কালেকশন
            </span>
          )}
        </div>

        {/* SKU tag */}
        <div className="absolute top-2.5 right-2.5 z-10">
          <span className="px-2 py-0.5 bg-slate-900/75 backdrop-blur-sm text-slate-200 text-[10px] font-mono font-bold rounded-md">
            {product.sku}
          </span>
        </div>

        {/* Quick View Overlay on Hover */}
        <div className="absolute inset-0 bg-slate-900/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="px-3.5 py-1.5 bg-white/95 text-slate-900 font-bold text-xs rounded-full shadow-lg flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-transform">
            <Eye className="w-3.5 h-3.5 text-emerald-700" />
            বিস্তারিত দেখুন
          </span>
        </div>
      </div>

      {/* 2. Product Details */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Title */}
          <h3 className="text-sm font-bold text-slate-900 group-hover:text-emerald-700 transition-colors line-clamp-2 leading-snug">
            {product.banglaName || product.name}
          </h3>

          {/* Price */}
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-lg font-black text-emerald-800 tracking-tight">
              ৳{product.salePrice.toLocaleString()}
            </span>
            {product.regularPrice > product.salePrice && (
              <span className="text-xs text-slate-400 line-through font-medium">
                ৳{product.regularPrice.toLocaleString()}
              </span>
            )}
          </div>

          {/* Size Selector */}
          <div className="mt-3" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between text-[11px] mb-1.5 text-slate-500 font-semibold">
              <span>সাইজ বেছে নিন:</span>
              <span className={product.totalStock <= 5 ? 'text-amber-600 font-bold' : 'text-emerald-700'}>
                {product.totalStock <= 5 ? `মাত্র ${product.totalStock} জোড়া বাকি!` : 'স্টকে আছে'}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {product.sizes.map((s) => {
                const isSelected = selectedSize === s.size;
                const isSizeOut = s.stock <= 0;
                return (
                  <button
                    key={s.size}
                    disabled={isSizeOut}
                    onClick={() => setSelectedSize(s.size)}
                    className={`h-7 min-w-7 px-1.5 rounded-md text-xs font-bold transition-all border ${
                      isSelected
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-sm'
                        : isSizeOut
                        ? 'bg-slate-100 text-slate-300 border-slate-200 line-through cursor-not-allowed'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    {s.size}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* 3. Action Buttons */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col gap-2">
          {/* Fast Order Button */}
          <button
            disabled={isOutOfStock}
            onClick={handleQuickBuy}
            className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-97 ${
              isOutOfStock
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-emerald-700/25'
            }`}
          >
            <Zap className="w-4 h-4 fill-amber-300 text-amber-300" />
            <span>এখনই অর্ডার করুন</span>
          </button>

          {/* Add to Cart Button */}
          <button
            disabled={isOutOfStock}
            onClick={handleAddToCart}
            className={`w-full py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors border ${
              isOutOfStock
                ? 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed'
                : addedAnimation
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200 hover:text-emerald-700'
            }`}
          >
            {addedAnimation ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>কার্টে যোগ হয়েছে!</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5 text-slate-500" />
                <span>কার্টে যোগ করুন</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
