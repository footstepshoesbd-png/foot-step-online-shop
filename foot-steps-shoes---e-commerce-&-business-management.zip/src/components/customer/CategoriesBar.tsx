import React from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import { Sparkles, Briefcase, Footprints, Sun, Activity, Shield } from 'lucide-react';

const iconMap: { [key: string]: any } = {
  Briefcase,
  Footprints,
  Sun,
  Activity,
  Shield,
  Sparkles
};

export const CategoriesBar: React.FC = () => {
  const { categories, selectedCategory, setSelectedCategory, products } = useStore();
  const activeCats = categories.filter((c) => c.isActive).sort((a, b) => a.order - b.order);

  return (
    <section id="categories" className="py-10 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6">
          <div>
            <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">
              কালেকশন সমাহার
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
              জনপ্রিয় ক্যাটাগরি সমূহ
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 sm:mt-0 font-medium">
            আপনার পছন্দের জুতো সহজে বেছে নিন
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 sm:gap-4">
          {/* All category button */}
          <button
            onClick={() => setSelectedCategory('all')}
            className={`p-4 rounded-2xl flex flex-col items-center text-center transition-all border ${
              selectedCategory === 'all'
                ? 'bg-emerald-800 text-white border-emerald-900 shadow-md shadow-emerald-900/20 scale-102'
                : 'bg-slate-50 hover:bg-emerald-50 text-slate-800 border-slate-200/80 hover:border-emerald-200'
            }`}
          >
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center mb-2.5 transition-colors ${
                selectedCategory === 'all' ? 'bg-emerald-700 text-emerald-100' : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              <Sparkles className="w-6 h-6" />
            </div>
            <span className="text-sm font-bold block">সব কালেকশন</span>
            <span
              className={`text-[11px] font-semibold mt-0.5 ${
                selectedCategory === 'all' ? 'text-emerald-200' : 'text-slate-500'
              }`}
            >
              {products.length} টি জুতো
            </span>
          </button>

          {/* Individual Category cards */}
          {activeCats.map((cat) => {
            const IconComponent = iconMap[cat.icon || 'Footprints'] || Footprints;
            const isSelected = selectedCategory === cat.id;
            const count = products.filter((p) => p.category === cat.id).length;

            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`p-4 rounded-2xl flex flex-col items-center text-center transition-all border group ${
                  isSelected
                    ? 'bg-emerald-800 text-white border-emerald-900 shadow-md shadow-emerald-900/20 scale-102'
                    : 'bg-slate-50 hover:bg-emerald-50 text-slate-800 border-slate-200/80 hover:border-emerald-200'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center mb-2.5 transition-colors overflow-hidden ${
                    isSelected ? 'bg-emerald-700 text-emerald-100' : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  <IconComponent className="w-6 h-6 group-hover:scale-110 transition-transform" />
                </div>
                <span className="text-sm font-bold block truncate w-full">{cat.banglaName}</span>
                <span
                  className={`text-[11px] font-semibold mt-0.5 ${
                    isSelected ? 'text-emerald-200' : 'text-slate-500'
                  }`}
                >
                  {count} টি পণ্য
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
