import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight, ShieldCheck, Truck, RefreshCw } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';

export const HeroSlider: React.FC = () => {
  const { banners, deliverySettings } = useStore();
  const activeBanners = banners.filter((b) => b.isActive).sort((a, b) => a.order - b.order);
  const [currentIdx, setCurrentIdx] = useState(0);

  // Auto slide every 6 seconds
  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIdx((prev) => (prev + 1) % activeBanners.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [activeBanners.length]);

  if (activeBanners.length === 0) return null;

  const currentBanner = activeBanners[currentIdx] || activeBanners[0];

  const handlePrev = () => {
    setCurrentIdx((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
  };

  const handleNext = () => {
    setCurrentIdx((prev) => (prev + 1) % activeBanners.length);
  };

  return (
    <section className="relative bg-slate-900 text-white overflow-hidden">
      {/* Background Image with Gradient Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={currentBanner.image}
          alt={currentBanner.title}
          className="w-full h-full object-cover object-center opacity-40 transform scale-105 transition-all duration-1000 ease-out"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-950/95 via-slate-900/90 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20 lg:py-24">
        <div className="max-w-2xl">
          {/* Badge */}
          {currentBanner.tag && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs sm:text-sm font-bold mb-4 backdrop-blur-sm">
              {currentBanner.tag}
            </span>
          )}

          {/* Title */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white leading-tight sm:leading-tight mb-4 tracking-tight drop-shadow-md">
            {currentBanner.title}
          </h1>

          {/* Subtitle */}
          <p className="text-sm sm:text-base lg:text-lg text-slate-300 font-medium mb-8 leading-relaxed">
            {currentBanner.subtitle}
          </p>

          {/* Call to Actions */}
          <div className="flex flex-wrap items-center gap-4">
            <a
              href={currentBanner.ctaLink || '#products'}
              className="inline-flex items-center gap-2 px-6 sm:px-8 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-sm sm:text-base transition-all shadow-lg shadow-emerald-700/40 active:scale-95 group"
            >
              <span>{currentBanner.ctaText || 'অর্ডার করুন'}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>

            <a
              href="#about"
              className="inline-flex items-center gap-2 px-5 py-3.5 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl text-sm sm:text-base backdrop-blur-sm transition-colors border border-white/10"
            >
              আমাদের শোরুম দেখুন
            </a>
          </div>

          {/* Trust points */}
          <div className="grid grid-cols-3 gap-3 sm:gap-6 mt-10 pt-8 border-t border-white/15 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-white text-[13px]">১০০% অরিজিনাল</p>
                <p className="text-[11px] text-slate-400">খাঁটি চামড়ার নিশ্চয়তা</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                <Truck className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-white text-[13px]">দ্রুত ডেলিভারি</p>
                <p className="text-[11px] text-slate-400">
                  ফেনী মাত্র ৳{deliverySettings?.feniCityCharge || 80}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                <RefreshCw className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-white text-[13px]">৭ দিন এক্সচেঞ্জ</p>
                <p className="text-[11px] text-slate-400">সহজ পরিবর্তনের সুযোগ</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Arrows */}
      {activeBanners.length > 1 && (
        <div className="absolute bottom-6 right-6 z-20 flex items-center gap-2">
          <button
            onClick={handlePrev}
            className="p-2.5 rounded-full bg-white/10 hover:bg-white/25 text-white backdrop-blur-md transition-all active:scale-95 border border-white/20"
            aria-label="Previous Banner"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex gap-1.5 px-2">
            {activeBanners.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIdx(i)}
                className={`h-2 rounded-full transition-all ${
                  currentIdx === i ? 'w-6 bg-emerald-400' : 'w-2 bg-white/40'
                }`}
              />
            ))}
          </div>
          <button
            onClick={handleNext}
            className="p-2.5 rounded-full bg-white/10 hover:bg-white/25 text-white backdrop-blur-md transition-all active:scale-95 border border-white/20"
            aria-label="Next Banner"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </section>
  );
};
