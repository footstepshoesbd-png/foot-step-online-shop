import React, { useState } from 'react';
import { CheckCircle2, Printer, Truck, ArrowRight, X, PhoneCall, ShoppingBag } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { PrintInvoiceModal } from '../shared/PrintInvoiceModal.tsx';

export const OrderSuccessModal: React.FC = () => {
  const { placedOrder, setPlacedOrder, settings, setIsTrackModalOpen } = useStore();
  const [printOpen, setPrintOpen] = useState(false);

  if (!placedOrder) return null;

  const handleTrack = () => {
    setPlacedOrder(null);
    setIsTrackModalOpen(true);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
        <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl p-6 sm:p-8 text-center animate-in fade-in zoom-in-95 duration-200">
          <button
            onClick={() => setPlacedOrder(null)}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-inner">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            অভিনন্দন! আপনার অর্ডার সফল হয়েছে 🎉
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            FOOT STEPS SHOES নির্বাচন করার জন্য আপনাকে ধন্যবাদ।
          </p>

          <div className="my-6 p-4 bg-emerald-50/80 border border-emerald-200 rounded-2xl text-left space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-600">অর্ডার নম্বর:</span>
              <span className="font-mono font-black text-emerald-900 text-sm bg-white px-2.5 py-0.5 rounded border border-emerald-200">
                #{placedOrder.id}
              </span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-600">গ্রাহকের নাম:</span>
              <span className="font-bold text-slate-800">{placedOrder.customerName}</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-600">মোবাইল নম্বর:</span>
              <span className="font-bold text-slate-800">{placedOrder.customerPhone}</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-600">ডেলিভারি ঠিকানা:</span>
              <span className="font-medium text-slate-700 truncate max-w-[200px]">{placedOrder.customerAddress}</span>
            </div>
            <div className="pt-2 border-t border-emerald-200 flex justify-between items-center text-xs font-bold">
              <span className="text-emerald-900">ক্যাশ অন ডেলিভারি পরিশোধযোগ্য:</span>
              <span className="text-base font-black text-emerald-950">৳{placedOrder.total.toLocaleString()}</span>
            </div>
          </div>

          <p className="text-xs text-slate-500 mb-6 leading-relaxed">
            খুব শীঘ্রই আমাদের প্রতিনিধি আপনার নম্বরে কল করে অর্ডারটি নিশ্চিত করবে। যেকোনো তথ্যের জন্য কল করুন:{' '}
            <a href={`tel:${settings?.phoneNumber}`} className="text-emerald-700 font-bold underline">
              {settings?.phoneNumber || '01819-876543'}
            </a>
          </p>

          <div className="flex flex-col sm:flex-row gap-2.5">
            <button
              onClick={() => setPrintOpen(true)}
              className="flex-1 py-3 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-1.5 shadow-md shadow-emerald-700/20 active:scale-98 transition-all"
            >
              <Printer className="w-4 h-4" />
              ইনভয়েস রশিদ প্রিন্ট
            </button>
            <button
              onClick={handleTrack}
              className="flex-1 py-3 px-4 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-1.5 active:scale-98 transition-all"
            >
              <Truck className="w-4 h-4 text-emerald-400" />
              লাইভ ট্র্যাক করুন
            </button>
          </div>

          <button
            onClick={() => setPlacedOrder(null)}
            className="w-full mt-3 py-2.5 text-xs text-slate-500 hover:text-slate-800 font-semibold"
          >
            শপিং চালিয়ে যান
          </button>
        </div>
      </div>

      <PrintInvoiceModal
        order={placedOrder}
        settings={settings}
        isOpen={printOpen}
        onClose={() => setPrintOpen(false)}
      />
    </>
  );
};
