import React from 'react';
import { MapPin, Phone, Clock, Mail, MessageCircle, Facebook, Instagram, ShieldCheck, Award, Users } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';

export const AboutAndContactSection: React.FC = () => {
  const { settings } = useStore();

  return (
    <section id="about" className="py-14 bg-slate-50 border-t border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* 1. About Us Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center mb-16">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold mb-3">
              <Award className="w-3.5 h-3.5 text-emerald-600" />
              আমাদের ঐতিহ্য ও কারুকার্য
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mb-4">
              {settings?.aboutUsContent?.title || 'আমাদের গল্প ও গুণগত মান'}
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-6 font-medium">
              {settings?.aboutUsContent?.description ||
                'FOOT STEPS SHOES ফেনী ট্রাঙ্ক রোডে শুরু হয়েছিল সেরা মানের চামড়ার জুতো প্রস্তুত ও সরবরাহের প্রতিশ্রুতি নিয়ে। আমরা কোনো কৃত্রিম রেক্সিন ব্যবহার করি না; প্রতিটি পণ্য খাঁটি টপ-গ্রেইন চামড়ায় তৈরি।'}
            </p>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-4 bg-white rounded-2xl border border-slate-200 text-center shadow-xs">
                <span className="block text-xl font-black text-emerald-800">
                  {settings?.aboutUsContent?.experienceYears || '১০+ বছর'}
                </span>
                <span className="text-[11px] font-bold text-slate-500">কারিগরি অভিজ্ঞতা</span>
              </div>
              <div className="p-4 bg-white rounded-2xl border border-slate-200 text-center shadow-xs">
                <span className="block text-xl font-black text-emerald-800">
                  {settings?.aboutUsContent?.happyCustomers || '১৫,০০০+'}
                </span>
                <span className="text-[11px] font-bold text-slate-500">সন্তুষ্ট গ্রাহক</span>
              </div>
              <div className="p-4 bg-white rounded-2xl border border-slate-200 text-center shadow-xs">
                <span className="block text-xl font-black text-emerald-800">১০০%</span>
                <span className="text-[11px] font-bold text-slate-500">জেনুইন লেদার</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-4/3 rounded-3xl overflow-hidden shadow-xl border-4 border-white bg-slate-200">
              <img
                src={
                  settings?.aboutUsContent?.image ||
                  'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800'
                }
                alt="Foot Steps Showroom"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -left-4 sm:bottom-4 sm:left-4 p-4 bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-slate-100 max-w-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  FS
                </div>
                <div>
                  <p className="font-black text-xs text-slate-900">{settings?.brandName || 'FOOT STEPS SHOES'}</p>
                  <p className="text-[11px] text-slate-500">ফেনীর বিশ্বস্ত ফুটওয়্যার শপ</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 2. Contact and Store Location Section */}
        <div id="contact" className="pt-10 border-t border-slate-200">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">
              সরাসরি আসুন আমাদের শোরুমে
            </span>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
              শোরুম লোকেশন ও যোগাযোগ
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              ফেনী ট্রাঙ্ক রোডে এসে নিজে দেখে ট্রায়াল দিয়ে পছন্দের জুতো বেছে নিন
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Address */}
            <div className="p-5 bg-white rounded-2xl border border-slate-200/90 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3">
                  <MapPin className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                  শোরুমের ঠিকানা
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {settings?.shopAddress || 'শপ নং ১২, গ্রিন টাওয়ার (২য় তলা), ট্রাঙ্ক রোড, ফেনী সদর, ফেনী'}
                </p>
              </div>
              <span className="text-[11px] font-bold text-emerald-700 mt-4 block">
                জেলা: {settings?.shopCity || 'ফেনী'}
              </span>
            </div>

            {/* Opening Hours */}
            <div className="p-5 bg-white rounded-2xl border border-slate-200/90 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3">
                  <Clock className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                  খোলা থাকার সময়
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {settings?.openingHours || 'সকাল ১০:০০ টা - রাত ১০:০০ টা (প্রতিদিন)'}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">সাপ্তাহিক কোনো বন্ধ নেই</p>
              </div>
              <span className="text-[11px] font-bold text-emerald-700 mt-4 block">
                সপ্তাহে ৭ দিন উন্মুক্ত
              </span>
            </div>

            {/* Phone Hotlines */}
            <div className="p-5 bg-white rounded-2xl border border-slate-200/90 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3">
                  <Phone className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                  হটলাইন ও অর্ডার কল
                </h4>
                <p className="text-xs font-bold text-slate-800 mt-1">
                  <a href={`tel:${settings?.phoneNumber}`} className="hover:text-emerald-700">
                    {settings?.phoneNumber || '01819-876543'}
                  </a>
                </p>
                {settings?.secondaryPhone && (
                  <p className="text-xs font-bold text-slate-600 mt-1">
                    <a href={`tel:${settings.secondaryPhone}`} className="hover:text-emerald-700">
                      {settings.secondaryPhone}
                    </a>
                  </p>
                )}
              </div>
              <a
                href={`tel:${settings?.phoneNumber}`}
                className="text-xs font-bold text-emerald-700 mt-4 block hover:underline"
              >
                সরাসরি কল দিন →
              </a>
            </div>

            {/* WhatsApp & Socials */}
            <div className="p-5 bg-white rounded-2xl border border-slate-200/90 shadow-xs flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                  হোয়াটসঅ্যাপ ও সোশ্যাল
                </h4>
                <p className="text-xs text-slate-600 font-medium">
                  যেকোনো প্রশ্ন ও ছবির জন্য হোয়াটসঅ্যাপে মেসেজ করুন:
                </p>
                <p className="text-xs font-bold text-emerald-800 mt-1">{settings?.whatsappNumber}</p>
              </div>
              <div className="flex gap-2 mt-4">
                <a
                  href={`https://wa.me/${(settings?.whatsappNumber || '').replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs"
                >
                  <MessageCircle className="w-3.5 h-3.5" /> চ্যাট করুন
                </a>
                {settings?.facebookUrl && (
                  <a
                    href={settings.facebookUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
                    title="Facebook Page"
                  >
                    <Facebook className="w-4 h-4" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
