import React, { useState } from 'react';
import { X, Check, Truck, ShieldCheck, MapPin, Phone, User, Home, AlertCircle, Sparkles } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { OrderItem } from '../../types/index.ts';
import { api } from '../../lib/api.ts';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    clearCart,
    quickBuyItem,
    deliverySettings,
    setPlacedOrder,
    refreshData
  } = useStore();

  if (!isCheckoutOpen) return null;

  // Checkout items can come from quick buy or cart
  const checkoutItems: OrderItem[] = quickBuyItem
    ? [
        {
          productId: quickBuyItem.product.id,
          productName: quickBuyItem.product.banglaName || quickBuyItem.product.name,
          productImage: quickBuyItem.product.images[0] || '',
          sku: quickBuyItem.product.sku,
          size: quickBuyItem.size,
          price: quickBuyItem.product.salePrice,
          costPrice: quickBuyItem.product.costPrice,
          quantity: 1,
          total: quickBuyItem.product.salePrice
        }
      ]
    : cart.map((item) => ({
        productId: item.product.id,
        productName: item.product.banglaName || item.product.name,
        productImage: item.product.images[0] || '',
        sku: item.product.sku,
        size: item.size,
        price: item.product.salePrice,
        costPrice: item.product.costPrice,
        quantity: item.quantity,
        total: item.product.salePrice * item.quantity
      }));

  const subtotal = checkoutItems.reduce((sum, item) => sum + item.total, 0);

  // Form states
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [deliveryArea, setDeliveryArea] = useState<'feni_city' | 'outside_feni' | 'express' | 'custom'>('feni_city');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('ফেনী (Feni)');
  const [customerNotes, setCustomerNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bkash'>('cod');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Calculate delivery charge dynamically from Admin Settings
  const feniCharge = deliverySettings?.feniCityCharge || 80;
  const outsideCharge = deliverySettings?.outsideFeniCharge || 140;
  const expressCharge = deliverySettings?.expressCharge || 150;
  const freeThreshold = deliverySettings?.freeDeliveryThreshold || 2500;
  const isFreeDelivery = Boolean(deliverySettings?.freeDeliveryEnabled && subtotal >= freeThreshold);

  let calculatedDeliveryCharge = feniCharge;
  if (isFreeDelivery) {
    calculatedDeliveryCharge = 0;
  } else if (deliveryArea === 'feni_city') {
    calculatedDeliveryCharge = feniCharge;
  } else if (deliveryArea === 'outside_feni') {
    calculatedDeliveryCharge = outsideCharge;
  } else if (deliveryArea === 'express') {
    calculatedDeliveryCharge = expressCharge;
  }

  const finalTotal = subtotal + calculatedDeliveryCharge;

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!customerName.trim()) {
      setFormError('অনুগ্রহ করে আপনার পুরো নাম লিখুন।');
      return;
    }
    const cleanPhone = customerPhone.trim().replace(/[^0-9]/g, '');
    if (cleanPhone.length < 11) {
      setFormError('অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 01812345678)');
      return;
    }
    if (!customerAddress.trim()) {
      setFormError('অনুগ্রহ করে আপনার পূর্ণ ডেলিভারি ঠিকানা লিখুন।');
      return;
    }

    if (checkoutItems.length === 0) {
      setFormError('আপনার অর্ডারে কোনো পণ্য নেই।');
      return;
    }

    // Min order amount check
    if (deliverySettings?.minOrderAmount && subtotal < deliverySettings.minOrderAmount) {
      setFormError(`সর্বনিম্ন অর্ডারের পরিমাণ ৳${deliverySettings.minOrderAmount}`);
      return;
    }

    try {
      setIsSubmitting(true);
      const newOrder = await api.createOrder({
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerAddress: customerAddress.trim(),
        deliveryArea,
        district: deliveryArea === 'feni_city' ? 'ফেনী (Feni)' : selectedDistrict,
        items: checkoutItems,
        subtotal,
        deliveryCharge: calculatedDeliveryCharge,
        discount: 0,
        total: finalTotal,
        codAmount: finalTotal,
        paymentMethod,
        customerNotes: customerNotes.trim()
      });

      // Clear cart
      clearCart();
      setIsCheckoutOpen(false);
      setPlacedOrder(newOrder);
      await refreshData();
    } catch (err: any) {
      setFormError(err.message || 'অর্ডার সাবমিট করতে সমস্যা হয়েছে, আবার চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden my-6 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-emerald-900 text-white flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-lg font-bold">অর্ডার সম্পন্ন করুন (ক্যাশ অন ডেলিভারি)</h2>
            <p className="text-xs text-emerald-200">
              পণ্য হাতে পেয়ে চেক করে মূল্য পরিশোধ করুন
            </p>
          </div>
          <button
            onClick={() => setIsCheckoutOpen(false)}
            className="p-1.5 rounded-lg bg-emerald-800/80 hover:bg-emerald-800 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmitOrder} className="flex-1 overflow-y-auto p-6 space-y-6">
          {formError && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* 1. Customer Information */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
              <User className="w-4 h-4" /> গ্রাহকের তথ্য
            </h3>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                আপনার নাম *
              </label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="যেমন: মোঃ আরিফুল ইসলাম"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:border-emerald-600 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                মোবাইল নম্বর (১১ ডিজিট) *
              </label>
              <input
                type="tel"
                required
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="01812345678"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          {/* 2. Delivery Location & Dynamic Charges */}
          <div className="space-y-4 pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
              <Truck className="w-4 h-4" /> ডেলিভারি এলাকা নির্বাচন করুন
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Feni City */}
              <label
                onClick={() => setDeliveryArea('feni_city')}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                  deliveryArea === 'feni_city'
                    ? 'border-emerald-700 bg-emerald-50/70 ring-2 ring-emerald-600/20'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-slate-800">ফেনী সিটি / সদর</span>
                  <input
                    type="radio"
                    name="deliveryArea"
                    checked={deliveryArea === 'feni_city'}
                    onChange={() => setDeliveryArea('feni_city')}
                    className="accent-emerald-700"
                  />
                </div>
                <div className="flex items-baseline justify-between mt-2">
                  <span className="text-[11px] text-slate-500">২৪-৪৮ ঘন্টা</span>
                  <span className="text-xs font-black text-emerald-800">
                    {isFreeDelivery ? 'ফ্রি' : `৳${feniCharge}`}
                  </span>
                </div>
              </label>

              {/* Outside Feni */}
              <label
                onClick={() => setDeliveryArea('outside_feni')}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                  deliveryArea === 'outside_feni'
                    ? 'border-emerald-700 bg-emerald-50/70 ring-2 ring-emerald-600/20'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-slate-800">ফেনীর বাইরে সারা দেশ</span>
                  <input
                    type="radio"
                    name="deliveryArea"
                    checked={deliveryArea === 'outside_feni'}
                    onChange={() => setDeliveryArea('outside_feni')}
                    className="accent-emerald-700"
                  />
                </div>
                <div className="flex items-baseline justify-between mt-2">
                  <span className="text-[11px] text-slate-500">২-৪ দিন (Steadfast)</span>
                  <span className="text-xs font-black text-emerald-800">
                    {isFreeDelivery ? 'ফ্রি' : `৳${outsideCharge}`}
                  </span>
                </div>
              </label>

              {/* Express */}
              <label
                onClick={() => setDeliveryArea('express')}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                  deliveryArea === 'express'
                    ? 'border-emerald-700 bg-emerald-50/70 ring-2 ring-emerald-600/20'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-slate-800">জরুরি এক্সপ্রেস ডেলিভারি</span>
                  <input
                    type="radio"
                    name="deliveryArea"
                    checked={deliveryArea === 'express'}
                    onChange={() => setDeliveryArea('express')}
                    className="accent-emerald-700"
                  />
                </div>
                <div className="flex items-baseline justify-between mt-2">
                  <span className="text-[11px] text-slate-500">দ্রুততম সার্ভিস</span>
                  <span className="text-xs font-black text-emerald-800">
                    {isFreeDelivery ? 'ফ্রি' : `৳${expressCharge}`}
                  </span>
                </div>
              </label>
            </div>

            {deliveryArea !== 'feni_city' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  জেলা নির্বাচন করুন
                </label>
                <select
                  value={selectedDistrict}
                  onChange={(e) => setSelectedDistrict(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:border-emerald-600 outline-none"
                >
                  <option value="ঢাকা (Dhaka)">ঢাকা (Dhaka)</option>
                  <option value="চট্টগ্রাম (Chittagong)">চট্টগ্রাম (Chittagong)</option>
                  <option value="সিলেট (Sylhet)">সিলেট (Sylhet)</option>
                  <option value="কুমিল্লা (Cumilla)">কুমিল্লা (Cumilla)</option>
                  <option value="নোয়াখালী (Noakhali)">নোয়াখালী (Noakhali)</option>
                  <option value="রাজশাহী (Rajshahi)">রাজশাহী (Rajshahi)</option>
                  <option value="খুলনা (Khulna)">খুলনা (Khulna)</option>
                  <option value="বরিশাল (Barisal)">বরিশাল (Barisal)</option>
                  <option value="অন্যান্য জেলা">অন্যান্য জেলা</option>
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                পূর্ণ ঠিকানা (বাসা নং, রোড, এলাকা/উপজেলা) *
              </label>
              <textarea
                required
                rows={2}
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
                placeholder="যেমন: বাসা নং ১৪, রোড নং ৩, ট্রাঙ্ক রোড মোড়, ফেনী"
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:border-emerald-600 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                অর্ডার নোট বা বিশেষ নির্দেশনা (ঐচ্ছিক)
              </label>
              <input
                type="text"
                value={customerNotes}
                onChange={(e) => setCustomerNotes(e.target.value)}
                placeholder="যেমন: বিকাল ৫ টার পর ডেলিভারি দিলে ভালো হয়"
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          {/* 3. Items Summary */}
          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800 mb-2">
              অর্ডারের সারসংক্ষেপ ({checkoutItems.length} টি জুতো)
            </h3>
            <div className="space-y-2 max-h-36 overflow-y-auto divide-y divide-slate-100 bg-slate-50 p-3 rounded-2xl border border-slate-200">
              {checkoutItems.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between pt-1.5 first:pt-0">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-md bg-emerald-800 text-white font-bold text-[10px] flex items-center justify-center">
                      {item.quantity}×
                    </span>
                    <span className="text-xs font-bold text-slate-800 truncate max-w-[200px] sm:max-w-xs">
                      {item.productName}
                    </span>
                    <span className="text-[11px] font-bold text-emerald-700 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                      সাইজ: {item.size}
                    </span>
                  </div>
                  <span className="text-xs font-black text-slate-900">
                    ৳{item.total.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* 4. Payment & Totals */}
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-2 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>জুতো বাবদ মোট:</span>
              <span className="font-bold text-slate-800">৳{subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>ডেলিভারি চার্জ:</span>
              <span className="font-bold text-emerald-800">
                {isFreeDelivery ? 'ফ্রি ডেলিভারি (৳০)' : `৳${calculatedDeliveryCharge}`}
              </span>
            </div>
            {isFreeDelivery && (
              <div className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                ২,৫০০ টাকার অর্ডারে স্পেশাল ফ্রি ডেলিভারি অফার কার্যকর হয়েছে!
              </div>
            )}
            <div className="pt-2 border-t border-emerald-200 flex justify-between items-center text-sm font-black text-emerald-950">
              <span>সর্বমোট প্রদেয় (COD Amount):</span>
              <span className="text-lg text-emerald-800">৳{finalTotal.toLocaleString()}</span>
            </div>
          </div>

          {/* Instructions from admin */}
          {deliverySettings?.deliveryInstructions && (
            <p className="text-[11px] text-slate-500 italic bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              <span className="font-bold">ডেলিভারি নোট:</span> {deliverySettings.deliveryInstructions}
            </p>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full py-4 px-6 rounded-2xl font-black text-base flex items-center justify-center gap-2 shadow-xl transition-all active:scale-98 text-white ${
              isSubmitting
                ? 'bg-slate-400 cursor-not-allowed'
                : 'bg-emerald-700 hover:bg-emerald-800 shadow-emerald-700/30'
            }`}
          >
            {isSubmitting ? (
              <span>অর্ডার গ্রহণ করা হচ্ছে...</span>
            ) : (
              <>
                <Check className="w-5 h-5" />
                <span>অর্ডার নিশ্চিত করুন (৳{finalTotal.toLocaleString()})</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
