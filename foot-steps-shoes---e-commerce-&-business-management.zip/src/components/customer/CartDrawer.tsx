import React from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, Truck } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartTotal,
    setIsCheckoutOpen,
    deliverySettings
  } = useStore();

  if (!isCartOpen) return null;

  const freeDeliveryThreshold = deliverySettings?.freeDeliveryThreshold || 2500;
  const isFreeDeliveryQualified = deliverySettings?.freeDeliveryEnabled && cartTotal >= freeDeliveryThreshold;
  const amountNeededForFreeDelivery = Math.max(0, freeDeliveryThreshold - cartTotal);

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartOpen(false)}
        className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          {/* Header */}
          <div className="px-6 py-4 bg-emerald-900 text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-emerald-300" />
              <h2 className="text-base font-bold">আপনার শপিং ব্যাগ ({cart.length})</h2>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-1.5 rounded-lg bg-emerald-800/80 hover:bg-emerald-800 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free delivery announcement & progress */}
          {deliverySettings?.freeDeliveryEnabled && (
            <div className="bg-emerald-50 px-6 py-3 border-b border-emerald-100">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-900 mb-1.5">
                <span className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-emerald-700" />
                  {isFreeDeliveryQualified ? (
                    <span className="text-emerald-700 font-black">
                      অভিনন্দন! আপনি ফ্রি ডেলিভারি পাচ্ছেন 🎉
                    </span>
                  ) : (
                    <span>
                      আর ৳{amountNeededForFreeDelivery.toLocaleString()} টাকার জুতো কিনলেই <span className="underline">ফ্রি ডেলিভারি</span>!
                    </span>
                  )}
                </span>
                <span>{Math.min(100, Math.round((cartTotal / freeDeliveryThreshold) * 100))}%</span>
              </div>
              <div className="w-full bg-emerald-200 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-600 h-full rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (cartTotal / freeDeliveryThreshold) * 100)}%` }}
                />
              </div>
            </div>
          )}

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto px-6 py-4 divide-y divide-slate-100">
            {cart.length > 0 ? (
              cart.map((item, index) => (
                <div key={`${item.product.id}-${item.size}-${index}`} className="py-4 flex gap-4">
                  <img
                    src={item.product.images[0] || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=200'}
                    alt={item.product.name}
                    className="w-20 h-20 rounded-xl object-cover bg-slate-100 border border-slate-200 shrink-0"
                  />
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between">
                        <h4 className="text-xs font-bold text-slate-900 line-clamp-1">
                          {item.product.banglaName || item.product.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.product.id, item.size)}
                          className="text-slate-400 hover:text-red-500 p-1"
                          title="মুছে ফেলুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                          সাইজ: {item.size}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {item.product.sku}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.size, item.quantity - 1)}
                          className="px-2.5 py-0.5 text-xs font-bold text-slate-600 hover:bg-slate-200"
                        >
                          -
                        </button>
                        <span className="px-2.5 py-0.5 text-xs font-bold text-slate-800">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.size, item.quantity + 1)}
                          className="px-2.5 py-0.5 text-xs font-bold text-slate-600 hover:bg-slate-200"
                        >
                          +
                        </button>
                      </div>
                      <span className="text-sm font-black text-emerald-800">
                        ৳{(item.product.salePrice * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-20 text-center">
                <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <p className="text-base font-bold text-slate-800">আপনার শপিং ব্যাগ খালি</p>
                <p className="text-xs text-slate-500 mt-1">
                  পছন্দের জুতো খুঁজে পেতে কালেকশন ব্রাউজ করুন।
                </p>
              </div>
            )}
          </div>

          {/* Footer & Checkout Trigger */}
          {cart.length > 0 && (
            <div className="p-6 bg-slate-50 border-t border-slate-200">
              <div className="flex justify-between items-center mb-2 text-xs text-slate-600">
                <span>পণ্যের মোট মূল্য:</span>
                <span className="font-bold text-slate-800 text-sm">৳{cartTotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center mb-4 text-xs text-slate-600">
                <span>ডেলিভারি চার্জ:</span>
                <span className="font-bold text-emerald-700">
                  {isFreeDeliveryQualified ? 'সম্পূর্ণ ফ্রি (Free)' : 'পরবর্তী ধাপে নির্ধারিত হবে'}
                </span>
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-between items-center mb-4">
                <span className="text-sm font-bold text-slate-900">আনুমানিক মোট:</span>
                <span className="text-xl font-black text-emerald-900">
                  ৳{cartTotal.toLocaleString()}
                </span>
              </div>

              <button
                onClick={handleProceedToCheckout}
                className="w-full py-3.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-700/25 transition-all active:scale-98"
              >
                <span>অর্ডার সম্পন্ন করতে এগিয়ে যান</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 mt-3 text-[11px] text-slate-500 font-medium">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>ক্যাশ অন ডেলিভারি | পণ্য হাতে পেয়ে টাকা পরিশোধ</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
