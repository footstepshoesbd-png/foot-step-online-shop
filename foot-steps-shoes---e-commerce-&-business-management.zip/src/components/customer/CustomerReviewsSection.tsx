import React, { useState } from 'react';
import { Star, MessageSquarePlus, CheckCircle2, X } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { api } from '../../lib/api.ts';

export const CustomerReviewsSection: React.FC = () => {
  const { reviews, refreshData } = useStore();
  const approvedReviews = reviews.filter((r) => r.isApproved);

  const [modalOpen, setModalOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [location, setLocation] = useState('ফেনী সদর');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [productName, setProductName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState(false);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !comment.trim()) return;

    try {
      setSubmitting(true);
      await api.createReview({
        customerName: customerName.trim(),
        location: location.trim() || 'ফেনী',
        rating,
        comment: comment.trim(),
        productName: productName.trim() || 'লেদার জুতো',
        isApproved: true,
        isFeatured: true
      });
      await refreshData();
      setSuccessMsg(true);
      setTimeout(() => {
        setSuccessMsg(false);
        setModalOpen(false);
        setCustomerName('');
        setComment('');
      }, 1500);
    } catch (e) {
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="reviews" className="py-14 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
          <div>
            <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">
              গ্রাহকদের অভিজ্ঞতা
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-1">
              গ্রাহকরা আমাদের সম্পর্কে কী বলছেন
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
              ১৫,০০০+ সন্তুষ্ট গ্রাহকদের খাঁটি রিভিউ ও ভালোবাসা
            </p>
          </div>

          <button
            onClick={() => setModalOpen(true)}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl font-bold text-xs sm:text-sm border border-emerald-200 transition-all self-start sm:self-auto active:scale-95"
          >
            <MessageSquarePlus className="w-4 h-4 text-emerald-600" />
            <span>আপনার রিভিউ দিন</span>
          </button>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {approvedReviews.map((rev) => (
            <div
              key={rev.id}
              className="p-5 rounded-2xl bg-slate-50 border border-slate-200/90 hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Rating stars */}
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < rev.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-200 fill-slate-200'
                      }`}
                    />
                  ))}
                </div>

                {/* Comment */}
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed italic mb-4">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1">
                    {rev.customerName}
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 inline" />
                  </h4>
                  <span className="text-[11px] text-slate-500 font-medium">{rev.location}</span>
                </div>
                {rev.productName && (
                  <span className="text-[10px] text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded font-semibold max-w-[100px] truncate">
                    {rev.productName}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Review Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl p-6">
            <button
              onClick={() => setModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-slate-900 mb-1">আপনার মূল্যবান মতামত দিন</h3>
            <p className="text-xs text-slate-500 mb-4">
              জুতো এবং সেবার মান কেমন লেগেছে তা অন্য গ্রাহকদের সাথে শেয়ার করুন।
            </p>

            {successMsg ? (
              <div className="py-8 text-center text-emerald-700">
                <CheckCircle2 className="w-12 h-12 mx-auto mb-2 text-emerald-600" />
                <p className="font-bold text-sm">রিভিউ প্রদান সফল হয়েছে!</p>
                <p className="text-xs text-slate-500">ধন্যবাদ আপনার মন্তব্যের জন্য।</p>
              </div>
            ) : (
              <form onSubmit={handleSubmitReview} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    রেটিং বেছে নিন *
                  </label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setRating(num)}
                        className={`p-2 rounded-xl border flex items-center gap-1 text-xs font-bold transition-all ${
                          rating >= num
                            ? 'bg-amber-50 border-amber-300 text-amber-900'
                            : 'bg-slate-50 border-slate-200 text-slate-400'
                        }`}
                      >
                        <Star
                          className={`w-4 h-4 ${
                            rating >= num ? 'text-amber-500 fill-amber-500' : 'text-slate-300'
                          }`}
                        />
                        <span>{num}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">আপনার নাম *</label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="যেমন: তানভীর আহমেদ"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">আপনার এলাকা / জেলা</label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="যেমন: ফেনী সদর, চট্টগ্রাম"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    কোন জুতোটি কিনেছেন? (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    placeholder="যেমন: ফরমাল অক্সফোর্ড শু"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">আপনার রিভিউ লিখুন *</label>
                  <textarea
                    required
                    rows={3}
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="জুতোর কোয়ালিটি, সোলের আরামদায়কতা বা ডেলিভারি কেমন ছিল লিখুন..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl transition-all shadow-md active:scale-98"
                >
                  {submitting ? 'সংরক্ষণ হচ্ছে...' : 'রিভিউ সাবমিট করুন'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
