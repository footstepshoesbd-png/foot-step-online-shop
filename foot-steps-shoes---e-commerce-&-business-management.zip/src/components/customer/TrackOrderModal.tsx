import React, { useState } from 'react';
import { X, Search, Truck, CheckCircle2, Clock, PackageCheck, AlertCircle, ExternalLink, Phone } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';
import { Order } from '../../types/index.ts';

export const TrackOrderModal: React.FC = () => {
  const { isTrackModalOpen, setIsTrackModalOpen, orders, settings } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [searchedOrder, setSearchedOrder] = useState<Order | null>(null);
  const [notFound, setNotFound] = useState(false);

  if (!isTrackModalOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setNotFound(false);
    const term = searchTerm.trim().toLowerCase();
    if (!term) return;

    const cleanNum = term.replace(/[^0-9]/g, '');

    const found = orders.find((o) => {
      const matchId = o.id.toLowerCase() === term || o.id.toLowerCase() === `fs-${term}`;
      const matchPhone = cleanNum.length >= 6 && o.customerPhone.includes(cleanNum);
      const matchTracking = o.courierDetails?.trackingCode?.toLowerCase() === term;
      return matchId || matchPhone || matchTracking;
    });

    if (found) {
      setSearchedOrder(found);
      setNotFound(false);
    } else {
      setSearchedOrder(null);
      setNotFound(true);
    }
  };

  const statusBengali = {
    pending: { label: 'পেন্ডিং (অপেক্ষমান)', color: 'bg-amber-100 text-amber-800 border-amber-200' },
    confirmed: { label: 'অর্ডার নিশ্চিত হয়েছে', color: 'bg-blue-100 text-blue-800 border-blue-200' },
    processing: { label: 'প্রস্তুত হচ্ছে (প্যাকিং)', color: 'bg-indigo-100 text-indigo-800 border-indigo-200' },
    shipped: { label: 'কুরিয়ারে পাঠানো হয়েছে', color: 'bg-purple-100 text-purple-800 border-purple-200' },
    delivered: { label: 'সফলভাবে ডেলিভার্ড', color: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
    cancelled: { label: 'বাতিল হয়েছে', color: 'bg-red-100 text-red-800 border-red-200' },
    returned: { label: 'পার্সেল রিটার্ন', color: 'bg-orange-100 text-orange-800 border-orange-200' }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 bg-emerald-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-emerald-300" />
            <h2 className="text-base font-bold">লাইভ অর্ডার ট্র্যাকিং</h2>
          </div>
          <button
            onClick={() => setIsTrackModalOpen(false)}
            className="p-1.5 rounded-lg bg-emerald-800/80 hover:bg-emerald-800 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Search Box */}
          <form onSubmit={handleSearch} className="mb-6">
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              অর্ডার নম্বর (যেমন: FS-1001) অথবা আপনার মোবাইল নম্বর দিন:
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="FS-1001 বা 01812345678"
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:border-emerald-600 outline-none"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all active:scale-95"
              >
                ট্র্যাক করুন
              </button>
            </div>
          </form>

          {notFound && (
            <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-center text-xs space-y-1">
              <AlertCircle className="w-6 h-6 mx-auto text-red-500 mb-1" />
              <p className="font-bold">কোনো অর্ডার খুঁজে পাওয়া যায়নি!</p>
              <p className="text-slate-500">
                সঠিক অর্ডার নম্বর বা যে নম্বরে অর্ডার করেছেন তা দিয়ে আবার চেষ্টা করুন।
              </p>
            </div>
          )}

          {searchedOrder && (
            <div className="space-y-5 animate-in fade-in duration-200">
              {/* Order status card */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="text-[11px] text-slate-500 block">অর্ডার আইডি</span>
                    <span className="font-mono font-black text-slate-900 text-base">
                      #{searchedOrder.id}
                    </span>
                  </div>
                  <span
                    className={`px-3 py-1 text-xs font-bold rounded-full border ${
                      statusBengali[searchedOrder.status]?.color || 'bg-slate-100 text-slate-800'
                    }`}
                  >
                    {statusBengali[searchedOrder.status]?.label || searchedOrder.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs border-t border-slate-200 pt-3 text-slate-600">
                  <div>
                    <span className="text-slate-400 block text-[10px]">গ্রাহকের নাম:</span>
                    <span className="font-bold text-slate-800">{searchedOrder.customerName}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">পরিশোধযোগ্য COD:</span>
                    <span className="font-black text-emerald-800 text-sm">
                      ৳{searchedOrder.codAmount.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Steadfast Courier Info */}
                {searchedOrder.courierDetails?.trackingCode && (
                  <div className="mt-3 p-3 bg-emerald-50/80 border border-emerald-200 rounded-xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-emerald-700" />
                        <span className="text-xs font-bold text-emerald-900">
                          Steadfast Courier Delivery
                        </span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-700 bg-white px-2 py-0.5 rounded border border-emerald-200">
                        লাইভ পার্সেল
                      </span>
                    </div>
                    <p className="text-xs text-emerald-800 mt-1 font-mono font-bold">
                      ট্র্যাকিং কোড: {searchedOrder.courierDetails.trackingCode}
                    </p>
                    {searchedOrder.courierDetails.consignmentId && (
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        কনসাইনমেন্ট আইডি: #{searchedOrder.courierDetails.consignmentId}
                      </p>
                    )}
                  </div>
                )}
              </div>

              {/* Progress Timeline */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3">
                  অর্ডারের অগ্রগতি (Timeline)
                </h4>
                <div className="space-y-3 pl-3 border-l-2 border-emerald-200 ml-2">
                  {searchedOrder.timeline && searchedOrder.timeline.length > 0 ? (
                    searchedOrder.timeline.map((step, idx) => (
                      <div key={idx} className="relative pl-4 text-xs">
                        <div className="absolute -left-[19px] top-0.5 w-3.5 h-3.5 rounded-full bg-emerald-600 ring-4 ring-white" />
                        <p className="font-bold text-slate-800">
                          {statusBengali[step.status]?.label || step.status}
                        </p>
                        <p className="text-slate-600 mt-0.5">{step.note}</p>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {new Date(step.timestamp).toLocaleString('bn-BD', {
                            dateStyle: 'medium',
                            timeStyle: 'short'
                          })}
                        </span>
                      </div>
                    ))
                  ) : (
                    <div className="text-xs text-slate-500">অগ্রগতি রেকর্ড শীঘ্রই যোগ করা হবে।</div>
                  )}
                </div>
              </div>

              {/* Items ordered */}
              <div className="pt-3 border-t border-slate-100">
                <span className="text-xs font-bold text-slate-700 block mb-2">অর্ডারের জুতো:</span>
                <div className="space-y-1.5">
                  {searchedOrder.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center text-xs text-slate-600 bg-slate-50 p-2 rounded-lg">
                      <span className="truncate max-w-[220px]">
                        {item.productName} (সাইজ: {item.size})
                      </span>
                      <span className="font-bold text-slate-800">
                        {item.quantity}× = ৳{item.total}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Help & Contact */}
              <div className="p-3 bg-slate-100 rounded-xl flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">জরুরি তথ্য জানতে কল করুন:</span>
                <a
                  href={`tel:${settings?.phoneNumber}`}
                  className="flex items-center gap-1 font-bold text-emerald-800 hover:text-emerald-900"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{settings?.phoneNumber || '01819-876543'}</span>
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
