import React from 'react';
import { MessageCircle, Phone } from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';

export const FloatingButtons: React.FC = () => {
  const { settings } = useStore();
  const cleanPhone = (settings?.whatsappNumber || '01819876543').replace(/[^0-9]/g, '');

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col gap-3">
      {/* WhatsApp Button */}
      <a
        href={`https://wa.me/${cleanPhone}`}
        target="_blank"
        rel="noreferrer"
        className="w-13 h-13 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-xl shadow-emerald-700/40 transition-all hover:scale-110 active:scale-95 group relative"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle className="w-7 h-7 fill-white" />
        <span className="absolute right-15 px-3 py-1 bg-slate-900 text-white text-xs font-bold rounded-lg shadow-md whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          হোয়াটসঅ্যাপে চ্যাট করুন
        </span>
      </a>

      {/* Phone Hotline Button */}
      <a
        href={`tel:${settings?.phoneNumber || '01819876543'}`}
        className="w-13 h-13 rounded-full bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center shadow-xl transition-all hover:scale-110 active:scale-95 group relative"
        aria-label="Direct Phone Call"
      >
        <Phone className="w-6 h-6 text-emerald-400" />
        <span className="absolute right-15 px-3 py-1 bg-slate-900 text-white text-xs font-bold rounded-lg shadow-md whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          সরাসরি কল করুন
        </span>
      </a>
    </div>
  );
};
