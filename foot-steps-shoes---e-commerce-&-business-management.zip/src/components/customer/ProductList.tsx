import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import { ProductCard } from './ProductCard.tsx';
import { ProductDetailsModal } from './ProductDetailsModal.tsx';
import { Product } from '../../types/index.ts';
import { Filter, Sparkles, Flame, Tag } from 'lucide-react';

export const ProductList: React.FC = () => {
  const { products, categories, selectedCategory, setSelectedCategory, searchQuery } = useStore();
  const [activeTab, setActiveTab] = useState<'all' | 'featured' | 'bestseller' | 'new'>('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);

  const handleViewDetails = (p: Product) => {
    setSelectedProduct(p);
    setDetailsModalOpen(true);
  };

  // Filter products
  const filteredProducts = products.filter((p) => {
    if (!p.isActive) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = (p.banglaName || '').toLowerCase().includes(q) || p.name.toLowerCase().includes(q);
      const matchSku = p.sku.toLowerCase().includes(q);
      const matchSize = p.sizes.some((s) => s.size.includes(q));
      if (!matchName && !matchSku && !matchSize) return false;
    }

    // Category filter
    if (selectedCategory !== 'all') {
      if (p.category !== selectedCategory) return false;
    }

    // Tabs filter
    if (activeTab === 'featured' && !p.isFeatured) return false;
    if (activeTab === 'bestseller' && !p.isBestSeller) return false;
    if (activeTab === 'new' && !p.isNewArrival) return false;

    return true;
  });

  return (
    <section id="products" className="py-12 bg-slate-50/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading & Filter Tabs */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              এক্সক্লুসিভ চামড়ার জুতো
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              আমাদের ট্রেন্ডিং জুতো কালেকশন
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
              ১০০% জেনুইন লেদার, প্রতিটি জুতোয় আভিজাত্য ও দীর্ঘস্থায়ী স্থায়িত্বের নিশ্চয়তা
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-white border border-slate-200 rounded-xl shadow-xs">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'all'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-emerald-700 hover:bg-slate-50'
              }`}
            >
              সব জুতো ({products.length})
            </button>
            <button
              onClick={() => setActiveTab('featured')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                activeTab === 'featured'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-emerald-700 hover:bg-slate-50'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              ফিচার্ড
            </button>
            <button
              onClick={() => setActiveTab('bestseller')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                activeTab === 'bestseller'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-emerald-700 hover:bg-slate-50'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-red-500" />
              বেস্ট সেলার
            </button>
            <button
              onClick={() => setActiveTab('new')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                activeTab === 'new'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-emerald-700 hover:bg-slate-50'
              }`}
            >
              <Tag className="w-3.5 h-3.5 text-emerald-600" />
              নতুন কালেকশন
            </button>
          </div>
        </div>

        {/* Search query tag feedback */}
        {searchQuery && (
          <div className="mb-6 p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-800 font-semibold">
            <span>
              "{searchQuery}" এর জন্য {filteredProducts.length} টি জুতো পাওয়া গেছে
            </span>
          </div>
        )}

        {/* Product Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        ) : (
          <div className="py-16 text-center bg-white rounded-2xl border border-slate-200 p-8">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
              <Filter className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-1">কোনো জুতো পাওয়া যায়নি</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
              অন্য কোনো ক্যাটাগরি বেছে নিন অথবা সার্চ কিওয়ার্ড পরিবর্তন করে চেষ্টা করুন।
            </p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setActiveTab('all');
              }}
              className="px-4 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800"
            >
              সব জুতো দেখুন
            </button>
          </div>
        )}
      </div>

      {/* Details Modal */}
      <ProductDetailsModal
        product={selectedProduct}
        isOpen={detailsModalOpen}
        onClose={() => setDetailsModalOpen(false)}
      />
    </section>
  );
};
