import React, { useState } from 'react';
import {
  ShoppingBag,
  Search,
  Truck,
  Phone,
  ShieldCheck,
  Menu,
  X,
  MapPin,
  Clock,
  Sparkles
} from 'lucide-react';
import { useStore } from '../../context/StoreContext.tsx';

export const Header: React.FC = () => {
  const {
    settings,
    cartItemsCount,
    setIsCartOpen,
    setIsTrackModalOpen,
    setIsAdminOpen,
    currentUser,
    searchQuery,
    setSearchQuery,
    setSelectedCategory
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white shadow-sm border-b border-slate-100">
      {/* 1. Dynamic Announcement Bar */}
      {settings?.announcementActive && (
        <div className="bg-emerald-800 text-white text-xs py-1.5 px-4 font-medium overflow-hidden">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2 truncate">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-300"></span>
              </span>
              <p className="truncate text-[13px]">{settings.announcementText}</p>
            </div>
            <div className="hidden md:flex items-center gap-4 text-xs shrink-0 text-emerald-100">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" /> {settings.shopCity || 'ফেনী'}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> {settings.openingHours}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 2. Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex items-center justify-between gap-4">
          {/* Logo & Brand Name */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-700 hover:text-emerald-700 rounded-lg hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            <a href="#" className="flex items-center gap-2.5 group">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-emerald-700 to-emerald-900 flex items-center justify-center text-white shadow-md shadow-emerald-900/20 group-hover:scale-105 transition-transform">
                <span className="font-black text-xl tracking-tighter">FS</span>
              </div>
              <div>
                <span className="text-xl sm:text-2xl font-black text-emerald-900 tracking-tight block leading-tight font-sans">
                  {settings?.brandName || 'FOOT STEPS SHOES'}
                </span>
                <span className="text-[11px] sm:text-xs font-semibold text-emerald-600 tracking-wide block">
                  {settings?.brandTagline || 'ফেনীর সেরা প্রিমিয়াম লেদার কালেকশন'}
                </span>
              </div>
            </a>
          </div>

          {/* Search Bar (Desktop) */}
          <div className="hidden lg:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="জুতো, লোফার বা সাইজ দিয়ে খুঁজুন..."
                className="w-full pl-10 pr-4 py-2 bg-slate-100 hover:bg-slate-50 focus:bg-white border border-slate-200 focus:border-emerald-600 rounded-full text-sm outline-none transition-all"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Phone hotline */}
            <a
              href={`tel:${settings?.phoneNumber || '01819876543'}`}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 text-xs font-semibold transition-colors border border-slate-200"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-600" />
              <span>{settings?.phoneNumber || '01819-876543'}</span>
            </a>

            {/* Track Order */}
            <button
              onClick={() => setIsTrackModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition-all border border-emerald-200"
            >
              <Truck className="w-4 h-4 text-emerald-600" />
              <span className="hidden sm:inline">অর্ডার ট্র্যাক</span>
              <span className="sm:hidden">ট্র্যাক</span>
            </button>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white shadow-md shadow-emerald-700/25 transition-all active:scale-95"
              aria-label="Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-amber-500 text-white rounded-full text-[11px] font-black flex items-center justify-center border-2 border-white shadow">
                  {cartItemsCount}
                </span>
              )}
            </button>

            {/* Admin Panel Trigger */}
            <button
              onClick={() => setIsAdminOpen(true)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all border ${
                currentUser
                  ? 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                  : 'bg-slate-800 text-white hover:bg-slate-900 border-slate-700'
              }`}
              title="ম্যানেজমেন্ট অ্যাডমিন প্যানেল"
            >
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span className="hidden md:inline">
                {currentUser ? `${currentUser.fullName.slice(0, 8)}..` : 'অ্যাডমিন প্যানেল'}
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="mt-3 lg:hidden">
          <div className="relative w-full">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="জুতো, লোফার বা কোড দিয়ে খুঁজুন..."
              className="w-full pl-9 pr-4 py-2 bg-slate-100 border border-slate-200 rounded-full text-xs outline-none focus:border-emerald-600"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>
        </div>
      </div>

      {/* 3. Navigation Links */}
      <nav className="border-t border-slate-100 hidden lg:block bg-slate-50/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ul className="flex items-center gap-6 text-sm font-semibold text-slate-700 py-2.5">
            <li>
              <button
                onClick={() => setSelectedCategory('all')}
                className="hover:text-emerald-700 transition-colors flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                সব কালেকশন
              </button>
            </li>
            <li>
              <a href="#categories" className="hover:text-emerald-700 transition-colors">
                ক্যাটাগরি
              </a>
            </li>
            <li>
              <a href="#products" className="hover:text-emerald-700 transition-colors">
                হট ট্রেন্ডিং
              </a>
            </li>
            <li>
              <a href="#features" className="hover:text-emerald-700 transition-colors">
                কেন FOOT STEPS
              </a>
            </li>
            <li>
              <a href="#reviews" className="hover:text-emerald-700 transition-colors">
                গ্রাহক রিভিউ
              </a>
            </li>
            <li>
              <a href="#about" className="hover:text-emerald-700 transition-colors">
                আমাদের গল্প
              </a>
            </li>
            <li>
              <a href="#contact" className="hover:text-emerald-700 transition-colors">
                শোরুম লোকেশন ও যোগাযোগ
              </a>
            </li>
            <li className="ml-auto text-xs font-bold text-emerald-700 bg-emerald-100/70 px-3 py-1 rounded-full">
              📍 ফেনী ট্রাঙ্ক রোড শোরুম
            </li>
          </ul>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-2 shadow-lg">
          <ul className="space-y-2 text-sm font-semibold text-slate-700">
            <li>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left py-1.5 hover:text-emerald-700"
              >
                সব জুতো কালেকশন
              </button>
            </li>
            <li>
              <a
                href="#categories"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-1.5 hover:text-emerald-700"
              >
                ক্যাটাগরি সমূহ
              </a>
            </li>
            <li>
              <a
                href="#products"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-1.5 hover:text-emerald-700"
              >
                ট্রেন্ডিং জুতো
              </a>
            </li>
            <li>
              <a
                href="#reviews"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-1.5 hover:text-emerald-700"
              >
                গ্রাহকদের রিভিউ
              </a>
            </li>
            <li>
              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-1.5 hover:text-emerald-700"
              >
                শোরুম ও যোগাযোগ
              </a>
            </li>
          </ul>
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">হটলাইন: {settings?.phoneNumber}</span>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsAdminOpen(true);
              }}
              className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200"
            >
              অ্যাডমিন ড্যাশবোর্ড
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
