import React, { useState } from 'react';
import { X, ShoppingBag, Zap, CheckCircle2, ShieldCheck, Truck, RefreshCw } from 'lucide-react';
import { Product } from '../../types/index.ts';
import { useStore } from '../../context/StoreContext.tsx';

interface ProductDetailsModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  isOpen,
  onClose
}) => {
  const { addToCart, openQuickBuy, deliverySettings } = useStore();

  if (!isOpen || !product) return null;

  const [activeImgIdx, setActiveImgIdx] = useState(0);
  const availableSizes = product.sizes.filter((s) => s.stock > 0);
  const [selectedSize, setSelectedSize] = useState<string>(
    availableSizes[0]?.size || product.sizes[0]?.size || '41'
  );
  const [quantity, setQuantity] = useState(1);

  const discountPercent =
    product.regularPrice > product.salePrice
      ? Math.round(((product.regularPrice - product.salePrice) / product.regularPrice) * 100)
      : 0;

  const handleAddToCart = () => {
    addToCart(product, selectedSize, quantity);
    onClose();
  };

  const handleQuickBuy = () => {
    onClose();
    openQuickBuy(product, selectedSize);
  };

  const currentSizeObj = product.sizes.find((s) => s.size === selectedSize);
  const isOutOfStock = product.totalStock <= 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Images Section */}
          <div className="p-6 bg-slate-50 flex flex-col justify-between">
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-white border border-slate-200 shadow-inner">
              <img
                src={product.images[activeImgIdx] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover object-center"
              />
              {discountPercent > 0 && (
                <div className="absolute top-3 left-3 bg-red-600 text-white font-black text-xs px-2.5 py-1 rounded-lg shadow-md">
                  {discountPercent}% ছাড়
                </div>
              )}
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-2 mt-4 overflow-x-auto pb-1">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImgIdx(i)}
                    className={`relative w-16 h-16 rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                      activeImgIdx === i ? 'border-emerald-600 ring-2 ring-emerald-600/30' : 'border-slate-200 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="thumbnail" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Guarantees */}
            <div className="mt-6 pt-4 border-t border-slate-200 grid grid-cols-3 gap-2 text-center text-xs text-slate-600">
              <div className="flex flex-col items-center">
                <ShieldCheck className="w-5 h-5 text-emerald-600 mb-1" />
                <span className="font-bold text-[11px] text-slate-800">১০০% লেদার</span>
              </div>
              <div className="flex flex-col items-center">
                <Truck className="w-5 h-5 text-emerald-600 mb-1" />
                <span className="font-bold text-[11px] text-slate-800">হোম ডেলিভারি</span>
              </div>
              <div className="flex flex-col items-center">
                <RefreshCw className="w-5 h-5 text-emerald-600 mb-1" />
                <span className="font-bold text-[11px] text-slate-800">৭ দিন এক্সচেঞ্জ</span>
              </div>
            </div>
          </div>

          {/* Details Section */}
          <div className="p-6 md:p-8 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 bg-slate-100 text-slate-600 rounded-md">
                  SKU: {product.sku}
                </span>
                {product.totalStock > 0 ? (
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> স্টকে আছে
                  </span>
                ) : (
                  <span className="text-[11px] font-bold text-red-700 bg-red-50 px-2 py-0.5 rounded-md">
                    স্টক শেষ
                  </span>
                )}
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
                {product.banglaName || product.name}
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-1">{product.name}</p>

              {/* Price */}
              <div className="flex items-baseline gap-3 my-4 p-3 bg-emerald-50/70 rounded-xl border border-emerald-100">
                <span className="text-2xl sm:text-3xl font-black text-emerald-900">
                  ৳{product.salePrice.toLocaleString()}
                </span>
                {product.regularPrice > product.salePrice && (
                  <span className="text-sm text-slate-400 line-through font-semibold">
                    ৳{product.regularPrice.toLocaleString()}
                  </span>
                )}
                {discountPercent > 0 && (
                  <span className="ml-auto text-xs font-bold text-emerald-700 bg-white px-2 py-1 rounded shadow-xs">
                    সাশ্রয় ৳{(product.regularPrice - product.salePrice).toLocaleString()}
                  </span>
                )}
              </div>

              {/* Size selection */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-2">
                  <span>সাইজ নির্ধারণ করুন:</span>
                  <span className="text-emerald-700 font-semibold text-[11px]">
                    {currentSizeObj ? `এই সাইজে স্টক: ${currentSizeObj.stock} জোড়া` : ''}
                  </span>
                </div>
                <div className="grid grid-cols-6 gap-2">
                  {product.sizes.map((s) => {
                    const isSelected = selectedSize === s.size;
                    const isSizeOut = s.stock <= 0;
                    return (
                      <button
                        key={s.size}
                        disabled={isSizeOut}
                        onClick={() => setSelectedSize(s.size)}
                        className={`py-2 rounded-xl text-xs font-bold transition-all border ${
                          isSelected
                            ? 'bg-emerald-800 text-white border-emerald-900 shadow-md ring-2 ring-emerald-500/20'
                            : isSizeOut
                            ? 'bg-slate-100 text-slate-300 border-slate-200 line-through cursor-not-allowed'
                            : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300'
                        }`}
                      >
                        {s.size}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Quantity */}
              <div className="flex items-center gap-4 mb-6">
                <span className="text-xs font-bold text-slate-700">পরিমাণ:</span>
                <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="px-3 py-1 text-slate-600 hover:bg-slate-200 font-bold"
                  >
                    -
                  </button>
                  <span className="px-4 py-1 text-sm font-bold text-slate-800">{quantity}</span>
                  <button
                    onClick={() => setQuantity((q) => q + 1)}
                    className="px-3 py-1 text-slate-600 hover:bg-slate-200 font-bold"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Highlights / Features */}
              {product.features && product.features.length > 0 && (
                <div className="mb-6">
                  <p className="text-xs font-bold text-slate-800 mb-2">পণ্যের বিশেষত্ব:</p>
                  <ul className="space-y-1.5 text-xs text-slate-600">
                    {product.features.map((feat, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Description */}
              {product.description && (
                <div className="mb-6">
                  <p className="text-xs font-bold text-slate-800 mb-1">বিবরণ:</p>
                  <p className="text-xs text-slate-600 leading-relaxed">{product.description}</p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-slate-100 flex flex-col gap-2.5">
              <button
                disabled={isOutOfStock}
                onClick={handleQuickBuy}
                className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all shadow-lg active:scale-98 ${
                  isOutOfStock
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-emerald-700/30'
                }`}
              >
                <Zap className="w-5 h-5 fill-amber-300 text-amber-300" />
                <span>এখনই অর্ডার করুন (ক্যাশ অন ডেলিভারি)</span>
              </button>

              <button
                disabled={isOutOfStock}
                onClick={handleAddToCart}
                className={`w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors border ${
                  isOutOfStock
                    ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                    : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300 hover:border-emerald-600 hover:text-emerald-700'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>কার্টে যোগ করুন</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
