import {
  WebsiteSettings,
  DeliverySettings,
  SystemSettings,
  Banner,
  WebsiteSection,
  Product,
  Category,
  Order,
  OrderStatus,
  CustomerReview,
  PurchaseRecord,
  ExpenseRecord,
  SalaryRecord,
  CustomerDueRecord,
  FinancialAccount,
  StaffUser,
  ActivityLog,
  SteadfastSettings
} from '../types/index.ts';

const API_BASE = '/api';

async function request<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options?.headers || {})
    }
  });

  if (!res.ok) {
    const errorText = await res.text();
    let parsedError = errorText;
    try {
      const jsonErr = JSON.parse(errorText);
      parsedError = jsonErr.error || jsonErr.message || errorText;
    } catch {}
    throw new Error(parsedError || `Request failed with status ${res.status}`);
  }

  return res.json();
}

export const api = {
  // Settings & CMS
  getSettings: () =>
    request<{
      settings: WebsiteSettings;
      deliverySettings: DeliverySettings;
      systemSettings: SystemSettings;
      sections: WebsiteSection[];
      banners: Banner[];
    }>('/settings'),

  updateGeneralSettings: (data: Partial<WebsiteSettings>) =>
    request<WebsiteSettings>('/settings/general', {
      method: 'PUT',
      body: JSON.stringify(data)
    }),

  updateDeliverySettings: (data: Partial<DeliverySettings>) =>
    request<DeliverySettings>('/settings/delivery', {
      method: 'PUT',
      body: JSON.stringify(data)
    }),

  updateSystemSettings: (data: Partial<SystemSettings>) =>
    request<SystemSettings>('/settings/system', {
      method: 'PUT',
      body: JSON.stringify(data)
    }),

  // Sections
  getSections: () => request<WebsiteSection[]>('/sections'),
  updateSections: (sections: WebsiteSection[]) =>
    request<WebsiteSection[]>('/sections', {
      method: 'PUT',
      body: JSON.stringify(sections)
    }),

  // Banners
  getBanners: () => request<Banner[]>('/banners'),
  createBanner: (banner: Partial<Banner>) =>
    request<Banner>('/banners', {
      method: 'POST',
      body: JSON.stringify(banner)
    }),
  updateBanner: (id: string, banner: Partial<Banner>) =>
    request<Banner>(`/banners/${id}`, {
      method: 'PUT',
      body: JSON.stringify(banner)
    }),
  deleteBanner: (id: string) =>
    request<{ success: boolean }>(`/banners/${id}`, { method: 'DELETE' }),

  // Products
  getProducts: () => request<Product[]>('/products'),
  createProduct: (product: Partial<Product>) =>
    request<Product>('/products', {
      method: 'POST',
      body: JSON.stringify(product)
    }),
  updateProduct: (id: string, product: Partial<Product>) =>
    request<Product>(`/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(product)
    }),
  deleteProduct: (id: string) =>
    request<{ success: boolean }>(`/products/${id}`, { method: 'DELETE' }),

  // Categories
  getCategories: () => request<Category[]>('/categories'),
  createCategory: (cat: Partial<Category>) =>
    request<Category>('/categories', {
      method: 'POST',
      body: JSON.stringify(cat)
    }),
  updateCategory: (id: string, cat: Partial<Category>) =>
    request<Category>(`/categories/${id}`, {
      method: 'PUT',
      body: JSON.stringify(cat)
    }),
  deleteCategory: (id: string) =>
    request<{ success: boolean }>(`/categories/${id}`, { method: 'DELETE' }),

  // Orders
  getOrders: () => request<Order[]>('/orders'),
  createOrder: (order: Partial<Order>) =>
    request<Order>('/orders', {
      method: 'POST',
      body: JSON.stringify(order)
    }),
  updateOrder: (id: string, order: Partial<Order>) =>
    request<Order>(`/orders/${id}`, {
      method: 'PUT',
      body: JSON.stringify(order)
    }),
  updateOrderStatus: (id: string, status: OrderStatus, note?: string) =>
    request<Order>(`/orders/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, note })
    }),
  deleteOrder: (id: string) =>
    request<{ success: boolean }>(`/orders/${id}`, { method: 'DELETE' }),

  // Steadfast Courier
  getSteadfastSettings: () => request<SteadfastSettings & { secretKeyMasked: string; hasKeys: boolean }>('/courier/steadfast/settings'),
  updateSteadfastSettings: (settings: Partial<SteadfastSettings>) =>
    request<{ success: boolean; message: string }>('/courier/steadfast/settings', {
      method: 'PUT',
      body: JSON.stringify(settings)
    }),
  bookSteadfast: (orderId: string, codAmount?: number, note?: string) =>
    request<{ success: boolean; message: string; consignment: any }>('/courier/steadfast/book', {
      method: 'POST',
      body: JSON.stringify({ orderId, codAmount, note })
    }),
  checkSteadfastStatus: (trackingCode: string) =>
    request<any>(`/courier/steadfast/status/${trackingCode}`),

  // Accounting
  getAccountingSummary: () => request<any>('/accounting/summary'),
  getPurchases: () => request<PurchaseRecord[]>('/accounting/purchases'),
  createPurchase: (purchase: Partial<PurchaseRecord>) =>
    request<PurchaseRecord>('/accounting/purchases', {
      method: 'POST',
      body: JSON.stringify(purchase)
    }),
  deletePurchase: (id: string) =>
    request<{ success: boolean }>(`/accounting/purchases/${id}`, { method: 'DELETE' }),

  getExpenses: () => request<ExpenseRecord[]>('/accounting/expenses'),
  createExpense: (expense: Partial<ExpenseRecord>) =>
    request<ExpenseRecord>('/accounting/expenses', {
      method: 'POST',
      body: JSON.stringify(expense)
    }),
  deleteExpense: (id: string) =>
    request<{ success: boolean }>(`/accounting/expenses/${id}`, { method: 'DELETE' }),

  getSalaries: () => request<SalaryRecord[]>('/accounting/salaries'),
  createSalary: (salary: Partial<SalaryRecord>) =>
    request<SalaryRecord>('/accounting/salaries', {
      method: 'POST',
      body: JSON.stringify(salary)
    }),
  deleteSalary: (id: string) =>
    request<{ success: boolean }>(`/accounting/salaries/${id}`, { method: 'DELETE' }),

  getCustomerDues: () => request<CustomerDueRecord[]>('/accounting/customer-dues'),
  createCustomerDue: (due: Partial<CustomerDueRecord>) =>
    request<CustomerDueRecord>('/accounting/customer-dues', {
      method: 'POST',
      body: JSON.stringify(due)
    }),
  updateCustomerDue: (id: string, due: Partial<CustomerDueRecord>) =>
    request<CustomerDueRecord>(`/accounting/customer-dues/${id}`, {
      method: 'PUT',
      body: JSON.stringify(due)
    }),

  getAccounts: () => request<FinancialAccount[]>('/accounting/accounts'),
  updateAccount: (id: string, acc: Partial<FinancialAccount>) =>
    request<FinancialAccount>(`/accounting/accounts/${id}`, {
      method: 'PUT',
      body: JSON.stringify(acc)
    }),

  // Customers
  getCustomers: () => request<any[]>('/customers'),

  // Reviews
  getReviews: () => request<CustomerReview[]>('/reviews'),
  createReview: (review: Partial<CustomerReview>) =>
    request<CustomerReview>('/reviews', {
      method: 'POST',
      body: JSON.stringify(review)
    }),
  updateReview: (id: string, review: Partial<CustomerReview>) =>
    request<CustomerReview>(`/reviews/${id}`, {
      method: 'PUT',
      body: JSON.stringify(review)
    }),
  deleteReview: (id: string) =>
    request<{ success: boolean }>(`/reviews/${id}`, { method: 'DELETE' }),

  // Staff & Auth
  login: (username: string, password: string) =>
    request<{ success: boolean; user: StaffUser; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    }),
  changePassword: (username: string, oldPassword: string, newPassword: string) =>
    request<{ success: boolean; message: string }>('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ username, oldPassword, newPassword })
    }),
  getStaff: () => request<StaffUser[]>('/staff'),
  createStaff: (staff: Partial<StaffUser>) =>
    request<StaffUser>('/staff', {
      method: 'POST',
      body: JSON.stringify(staff)
    }),
  updateStaff: (id: string, staff: Partial<StaffUser>) =>
    request<StaffUser>(`/staff/${id}`, {
      method: 'PUT',
      body: JSON.stringify(staff)
    }),
  deleteStaff: (id: string) =>
    request<{ success: boolean }>(`/staff/${id}`, { method: 'DELETE' }),

  // Activity Logs
  getActivityLogs: () => request<ActivityLog[]>('/activity-logs'),

  // Restore
  restoreBackup: (data: any) =>
    request<{ success: boolean; message: string }>('/restore', {
      method: 'POST',
      body: JSON.stringify(data)
    })
};
