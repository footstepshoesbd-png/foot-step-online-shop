export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled'
  | 'returned';

export type CourierStatus =
  | 'unbooked'
  | 'pending'
  | 'in_review'
  | 'delivered'
  | 'partial_delivered'
  | 'cancelled'
  | 'hold'
  | 'unknown';

export interface ProductSize {
  size: string; // e.g., '39', '40', '41', '42', '43', '44'
  stock: number;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  banglaName?: string;
  slug: string;
  description: string;
  features?: string[];
  category: string;
  regularPrice: number;
  salePrice: number;
  costPrice: number; // For accounting / profit calculation
  images: string[];
  sizes: ProductSize[];
  totalStock: number;
  colors?: string[];
  isFeatured: boolean;
  isNewArrival: boolean;
  isBestSeller: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  banglaName: string;
  slug: string;
  image: string;
  icon?: string;
  itemCount?: number;
  isActive: boolean;
  order: number;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  sku: string;
  size: string;
  color?: string;
  price: number;
  costPrice: number;
  quantity: number;
  total: number;
}

export interface SteadfastBookingDetails {
  consignmentId?: number | string;
  trackingCode?: string;
  courierStatus?: string;
  bookedAt?: string;
  deliveryCharge?: number;
  codAmount?: number;
  notes?: string;
  lastChecked?: string;
}

export interface Order {
  id: string; // e.g., FS-1001
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  deliveryArea: 'feni_city' | 'outside_feni' | 'express' | 'custom';
  district: string;
  items: OrderItem[];
  subtotal: number;
  deliveryCharge: number;
  discount: number;
  total: number;
  codAmount: number;
  paymentMethod: 'cod' | 'bkash' | 'nagad' | 'bank';
  paymentStatus: 'unpaid' | 'paid' | 'partial';
  paidAmount?: number;
  status: OrderStatus;
  courierName?: 'steadfast' | 'pathao' | 'redx' | 'sundarban' | 'manual';
  courierDetails?: SteadfastBookingDetails;
  customerNotes?: string;
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
  timeline: {
    status: OrderStatus;
    timestamp: string;
    note: string;
    updatedBy?: string;
  }[];
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  tag?: string;
  image: string;
  ctaText: string;
  ctaLink: string;
  isActive: boolean;
  order: number;
}

export interface WebsiteSection {
  id: string;
  key: string;
  name: string;
  title: string;
  subtitle?: string;
  isVisible: boolean;
  order: number;
}

export interface CustomerReview {
  id: string;
  customerName: string;
  location: string; // e.g. "ফেনী সদর"
  rating: number; // 1-5
  comment: string;
  productName?: string;
  image?: string;
  date: string;
  isApproved: boolean;
  isFeatured: boolean;
}

export interface DeliverySettings {
  feniCityCharge: number; // e.g. 80
  outsideFeniCharge: number; // e.g. 140
  expressCharge: number; // e.g. 150
  freeDeliveryEnabled: boolean;
  freeDeliveryThreshold: number; // e.g. 2500
  minOrderAmount: number; // e.g. 500
  estimatedTimeFeni: string; // e.g. "২৪-৪৮ ঘন্টা"
  estimatedTimeOutside: string; // e.g. "২-৪ দিন"
  deliveryInstructions: string;
  returnPolicyText: string;
  customDistrictCharges: {
    district: string;
    charge: number;
  }[];
}

export interface SteadfastSettings {
  apiKey: string;
  secretKey: string;
  baseUrl: string;
  senderName: string;
  senderPhone: string;
  senderAddress: string;
  isLive: boolean; // false = realistic simulator mode, true = real steadfast API
  autoBookOnConfirm: boolean;
}

export interface WebsiteSettings {
  brandName: string;
  brandTagline: string;
  websiteTitle: string;
  metaDescription: string;
  keywords: string;
  logoUrl: string;
  faviconUrl?: string;
  primaryColor: string; // e.g. "#059669"
  accentColor: string; // e.g. "#10B981"
  shopAddress: string;
  shopCity: string;
  openingHours: string;
  phoneNumber: string;
  secondaryPhone?: string;
  whatsappNumber: string;
  email: string;
  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  tiktokUrl: string;
  announcementText: string;
  announcementActive: boolean;
  footerAbout: string;
  copyrightText: string;
  aboutUsContent: {
    title: string;
    description: string;
    experienceYears: string;
    happyCustomers: string;
    qualityGuarantee: string;
    image: string;
  };
}

export interface PurchaseRecord {
  id: string;
  supplierName: string;
  invoiceNo: string;
  itemsDescription: string;
  quantity: number;
  totalCost: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: string;
  date: string;
  notes?: string;
}

export interface ExpenseRecord {
  id: string;
  category: 'rent' | 'salary' | 'utility' | 'packaging' | 'marketing' | 'transport' | 'courier_loss' | 'other';
  title: string;
  amount: number;
  paymentMethod: string;
  date: string;
  recipient?: string;
  notes?: string;
}

export interface SalaryRecord {
  id: string;
  staffName: string;
  designation: string;
  month: string;
  amount: number;
  bonus?: number;
  paymentStatus: 'paid' | 'pending';
  paymentDate?: string;
  paymentMethod: string;
  notes?: string;
}

export interface SupplierPayment {
  id: string;
  supplierName: string;
  billAmount: number;
  paidAmount: number;
  balanceDue: number;
  paymentMethod: string;
  date: string;
  notes?: string;
}

export interface CustomerDueRecord {
  id: string;
  customerName: string;
  customerPhone: string;
  orderId?: string;
  totalBill: number;
  paidAmount: number;
  dueAmount: number;
  dueDate?: string;
  isSettled: boolean;
  notes?: string;
  updatedAt: string;
}

export interface FinancialAccount {
  id: string;
  name: string; // "ক্যাশ ইন হ্যান্ড", "বিকাশ মার্চেন্ট", "নগদ পার্সোনাল", "ব্যাংক অ্যাকাউন্ট"
  type: 'cash' | 'bkash' | 'nagad' | 'bank';
  accountNumber?: string;
  balance: number;
  updatedAt: string;
}

export interface StaffUser {
  id: string;
  username: string;
  fullName: string;
  phone: string;
  role: 'super_admin' | 'manager' | 'order_staff' | 'accounts' | 'delivery_staff';
  isActive: boolean;
  password?: string;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  staffName: string;
  action: string;
  module: string;
  details: string;
  timestamp: string;
}

export interface SystemSettings {
  invoicePrefix: string;
  autoConfirmOrders: boolean;
  enableSMS: boolean;
  smsApiKey?: string;
  smsSenderId?: string;
  taxPercentage: number;
  taxEnabled: boolean;
  currencySymbol: string;
  tradeLicenseNo: string;
  tinNo?: string;
}

export interface FullDatabase {
  settings: WebsiteSettings;
  deliverySettings: DeliverySettings;
  steadfastSettings: SteadfastSettings;
  systemSettings: SystemSettings;
  banners: Banner[];
  sections: WebsiteSection[];
  categories: Category[];
  products: Product[];
  orders: Order[];
  reviews: CustomerReview[];
  purchases: PurchaseRecord[];
  expenses: ExpenseRecord[];
  salaries: SalaryRecord[];
  supplierPayments: SupplierPayment[];
  customerDues: CustomerDueRecord[];
  accounts: FinancialAccount[];
  staff: StaffUser[];
  activityLogs: ActivityLog[];
}
