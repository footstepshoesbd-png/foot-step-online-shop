import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  WebsiteSettings,
  DeliverySettings,
  SystemSettings,
  Banner,
  WebsiteSection,
  Product,
  Category,
  Order,
  CustomerReview,
  StaffUser
} from '../types/index.ts';
import { api } from '../lib/api.ts';

export interface CartItem {
  product: Product;
  size: string;
  quantity: number;
}

interface StoreContextType {
  settings: WebsiteSettings | null;
  deliverySettings: DeliverySettings | null;
  systemSettings: SystemSettings | null;
  sections: WebsiteSection[];
  banners: Banner[];
  products: Product[];
  categories: Category[];
  orders: Order[];
  reviews: CustomerReview[];
  isLoading: boolean;
  error: string | null;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, size: string, quantity?: number) => void;
  updateCartQuantity: (productId: string, size: string, quantity: number) => void;
  removeFromCart: (productId: string, size: string) => void;
  clearCart: () => void;
  cartTotal: number;
  cartItemsCount: number;

  // UI Modals
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  quickBuyItem: { product: Product; size: string } | null;
  openQuickBuy: (product: Product, size: string) => void;
  isTrackModalOpen: boolean;
  setIsTrackModalOpen: (open: boolean) => void;
  isAdminOpen: boolean;
  setIsAdminOpen: (open: boolean) => void;
  placedOrder: Order | null;
  setPlacedOrder: (order: Order | null) => void;

  // Filters
  selectedCategory: string;
  setSelectedCategory: (catId: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Auth
  currentUser: StaffUser | null;
  setCurrentUser: (user: StaffUser | null) => void;
  login: (username: string, pass: string) => Promise<boolean>;
  logout: () => void;

  // Refetch
  refreshData: () => Promise<void>;
  updateSettingsState: (newSettings: Partial<WebsiteSettings>) => void;
  updateDeliverySettingsState: (newSettings: Partial<DeliverySettings>) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<WebsiteSettings | null>(null);
  const [deliverySettings, setDeliverySettings] = useState<DeliverySettings | null>(null);
  const [systemSettings, setSystemSettings] = useState<SystemSettings | null>(null);
  const [sections, setSections] = useState<WebsiteSection[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [reviews, setReviews] = useState<CustomerReview[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('fs_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // UI state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [quickBuyItem, setQuickBuyItem] = useState<{ product: Product; size: string } | null>(null);
  const [isTrackModalOpen, setIsTrackModalOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);

  // Filters
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Staff user
  const [currentUser, setCurrentUser] = useState<StaffUser | null>(() => {
    try {
      const saved = localStorage.getItem('fs_admin_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Save cart to local storage
  useEffect(() => {
    try {
      localStorage.setItem('fs_cart', JSON.stringify(cart));
    } catch {}
  }, [cart]);

  // Load all data
  const refreshData = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const [settingsRes, prodsRes, catsRes, ordersRes, reviewsRes] = await Promise.all([
        api.getSettings(),
        api.getProducts(),
        api.getCategories(),
        api.getOrders(),
        api.getReviews()
      ]);

      setSettings(settingsRes.settings);
      setDeliverySettings(settingsRes.deliverySettings);
      setSystemSettings(settingsRes.systemSettings);
      setSections(settingsRes.sections || []);
      setBanners(settingsRes.banners || []);
      setProducts(prodsRes || []);
      setCategories(catsRes || []);
      setOrders(ordersRes || []);
      setReviews(reviewsRes || []);
    } catch (err: any) {
      console.error('Failed to load store data', err);
      setError(err.message || 'ডাটা লোড করতে সমস্যা হয়েছে');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const addToCart = (product: Product, size: string, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id && item.size === size);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id && item.size === size
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, size, quantity }];
    });
    setIsCartOpen(true);
  };

  const updateCartQuantity = (productId: string, size: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId, size);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId && item.size === size ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (productId: string, size: string) => {
    setCart((prev) => prev.filter((item) => !(item.product.id === productId && item.size === size)));
  };

  const clearCart = () => {
    setCart([]);
  };

  const openQuickBuy = (product: Product, size: string) => {
    setQuickBuyItem({ product, size });
    setIsCheckoutOpen(true);
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.product.salePrice * item.quantity, 0);
  const cartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const login = async (username: string, pass: string): Promise<boolean> => {
    try {
      const res = await api.login(username, pass);
      if (res.success && res.user) {
        setCurrentUser(res.user);
        localStorage.setItem('fs_admin_user', JSON.stringify(res.user));
        return true;
      }
      return false;
    } catch (err) {
      return false;
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('fs_admin_user');
  };

  const updateSettingsState = (newSettings: Partial<WebsiteSettings>) => {
    if (settings) {
      setSettings({ ...settings, ...newSettings });
    }
  };

  const updateDeliverySettingsState = (newSettings: Partial<DeliverySettings>) => {
    if (deliverySettings) {
      setDeliverySettings({ ...deliverySettings, ...newSettings });
    }
  };

  return (
    <StoreContext.Provider
      value={{
        settings,
        deliverySettings,
        systemSettings,
        sections,
        banners,
        products,
        categories,
        orders,
        reviews,
        isLoading,
        error,
        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        cartTotal,
        cartItemsCount,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        quickBuyItem,
        openQuickBuy,
        isTrackModalOpen,
        setIsTrackModalOpen,
        isAdminOpen,
        setIsAdminOpen,
        placedOrder,
        setPlacedOrder,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        currentUser,
        setCurrentUser,
        login,
        logout,
        refreshData,
        updateSettingsState,
        updateDeliverySettingsState
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
