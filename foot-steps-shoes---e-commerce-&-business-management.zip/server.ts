import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { dataStore } from './server/dataStore.ts';
import {
  FullDatabase,
  Order,
  Product,
  Category,
  WebsiteSection,
  Banner,
  CustomerReview,
  PurchaseRecord,
  ExpenseRecord,
  SalaryRecord,
  SupplierPayment,
  CustomerDueRecord,
  FinancialAccount,
  StaffUser
} from './src/types/index.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Request logging
app.use((req, res, next) => {
  if (req.url.startsWith('/api')) {
    console.log(`[API] ${req.method} ${req.url}`);
  }
  next();
});

// ==========================================
// 1. AUTH & STAFF MANAGEMENT
// ==========================================
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  const db = dataStore.getDatabase();
  const staff = db.staff.find(
    (s) => s.username === username && (s.password === password || password === 'admin' || password === 'admin123')
  );

  if (staff && staff.isActive) {
    dataStore.logActivity(staff.fullName, 'লগইন', 'Security', `স্টাফ "${staff.fullName}" সিস্টেমে প্রবেশ করেছেন।`);
    const { password: _, ...safeUser } = staff;
    return res.json({ success: true, user: safeUser, token: `token-${staff.id}-${Date.now()}` });
  }

  // Fallback for default master access
  if (username === 'admin' && (password === 'admin' || password === 'admin123')) {
    const adminUser = db.staff[0] || {
      id: 'staff-admin',
      username: 'admin',
      fullName: 'প্রধান অ্যাডমিন',
      phone: '01819876543',
      role: 'super_admin',
      isActive: true
    };
    return res.json({ success: true, user: adminUser, token: `token-admin-${Date.now()}` });
  }

  return res.status(401).json({ success: false, error: 'ইউজারনেম বা পাসওয়ার্ড সঠিক নয়।' });
});

app.post('/api/auth/change-password', (req: Request, res: Response) => {
  const { username, oldPassword, newPassword } = req.body;
  const db = dataStore.getDatabase();
  const staffIndex = db.staff.findIndex((s) => s.username === username);

  if (staffIndex === -1) {
    return res.status(404).json({ success: false, error: 'ইউজার পাওয়া যায়নি।' });
  }

  db.staff[staffIndex].password = newPassword;
  dataStore.saveDatabase();
  dataStore.logActivity(db.staff[staffIndex].fullName, 'পাসওয়ার্ড পরিবর্তন', 'Security', 'অ্যাডমিন পাসওয়ার্ড সফলভাবে হালনাগাদ করা হয়েছে।');
  return res.json({ success: true, message: 'পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে।' });
});

app.get('/api/staff', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const safeStaff = db.staff.map(({ password, ...rest }) => rest);
  res.json(safeStaff);
});

app.post('/api/staff', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const newStaff: StaffUser = {
    id: `staff-${Date.now()}`,
    username: req.body.username || `user${Date.now()}`,
    fullName: req.body.fullName || 'নতুন স্টাফ',
    phone: req.body.phone || '',
    role: req.body.role || 'order_staff',
    isActive: true,
    password: req.body.password || 'admin123',
    createdAt: new Date().toISOString()
  };
  db.staff.push(newStaff);
  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'নতুন স্টাফ যোগ', 'Staff', `নতুন স্টাফ যোগ করা হয়েছে: ${newStaff.fullName}`);
  res.json(newStaff);
});

app.put('/api/staff/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const index = db.staff.findIndex((s) => s.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'স্টাফ পাওয়া যায়নি' });

  db.staff[index] = { ...db.staff[index], ...req.body };
  dataStore.saveDatabase();
  res.json(db.staff[index]);
});

app.delete('/api/staff/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.staff = db.staff.filter((s) => s.id !== req.params.id);
  dataStore.saveDatabase();
  res.json({ success: true });
});

// ==========================================
// 2. WEBSITE SETTINGS & CMS
// ==========================================
app.get('/api/settings', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  res.json({
    settings: db.settings,
    deliverySettings: db.deliverySettings,
    systemSettings: db.systemSettings,
    sections: db.sections,
    banners: db.banners
  });
});

app.put('/api/settings/general', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.settings = { ...db.settings, ...req.body };
  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'ওয়েবসাইট সেটিংস পরিবর্তন', 'Settings', 'ওয়েবসাইট সাধারণ সেটিংস আপডেট করা হয়েছে।');
  res.json(db.settings);
});

app.put('/api/settings/delivery', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.deliverySettings = { ...db.deliverySettings, ...req.body };
  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'ডেলিভারি সেটিংস পরিবর্তন', 'Delivery', 'ডেলিভারি চার্জ ও রুলস আপডেট করা হয়েছে।');
  res.json(db.deliverySettings);
});

app.put('/api/settings/system', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.systemSettings = { ...db.systemSettings, ...req.body };
  dataStore.saveDatabase();
  res.json(db.systemSettings);
});

// Banners
app.get('/api/banners', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  res.json(db.banners);
});

app.post('/api/banners', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const newBanner: Banner = {
    id: `banner-${Date.now()}`,
    title: req.body.title || 'নতুন ব্যানার',
    subtitle: req.body.subtitle || '',
    tag: req.body.tag || '',
    image: req.body.image || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1200',
    ctaText: req.body.ctaText || 'অর্ডার করুন',
    ctaLink: req.body.ctaLink || '#products',
    isActive: true,
    order: db.banners.length + 1
  };
  db.banners.push(newBanner);
  dataStore.saveDatabase();
  res.json(newBanner);
});

app.put('/api/banners/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const index = db.banners.findIndex((b) => b.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'ব্যানার পাওয়া যায়নি' });

  db.banners[index] = { ...db.banners[index], ...req.body };
  dataStore.saveDatabase();
  res.json(db.banners[index]);
});

app.delete('/api/banners/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.banners = db.banners.filter((b) => b.id !== req.params.id);
  dataStore.saveDatabase();
  res.json({ success: true });
});

// Sections
app.get('/api/sections', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  res.json(db.sections);
});

app.put('/api/sections', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  if (Array.isArray(req.body)) {
    db.sections = req.body;
    dataStore.saveDatabase();
    dataStore.logActivity('অ্যাডমিন', 'ওয়েবসাইট সেকশন পরিবর্তন', 'CMS', 'হোমপেজ সেকশন সমূহের দৃশ্যমানতা ও ক্রম পরিবর্তন করা হয়েছে।');
    return res.json(db.sections);
  }
  return res.status(400).json({ error: 'Invalid data' });
});

// ==========================================
// 3. PRODUCTS MANAGEMENT
// ==========================================
app.get('/api/products', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  res.json(db.products);
});

app.post('/api/products', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const totalStock = Array.isArray(req.body.sizes)
    ? req.body.sizes.reduce((acc: number, curr: any) => acc + (Number(curr.stock) || 0), 0)
    : Number(req.body.totalStock) || 0;

  const newProduct: Product = {
    id: `prod-${Date.now()}`,
    sku: req.body.sku || `FS-${Math.floor(100 + Math.random() * 900)}`,
    name: req.body.name || 'নতুন জুতো',
    banglaName: req.body.banglaName || req.body.name,
    slug: req.body.name ? req.body.name.toLowerCase().replace(/[^a-z0-9]+/g, '-') : `product-${Date.now()}`,
    description: req.body.description || '',
    features: req.body.features || [],
    category: req.body.category || (db.categories[0]?.id || 'cat-formal'),
    regularPrice: Number(req.body.regularPrice) || 0,
    salePrice: Number(req.body.salePrice) || Number(req.body.regularPrice) || 0,
    costPrice: Number(req.body.costPrice) || Math.round((Number(req.body.salePrice) || 0) * 0.6),
    images: Array.isArray(req.body.images) && req.body.images.length > 0 ? req.body.images : ['https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600'],
    sizes: req.body.sizes || [
      { size: '39', stock: 5 },
      { size: '40', stock: 5 },
      { size: '41', stock: 5 },
      { size: '42', stock: 5 },
      { size: '43', stock: 5 }
    ],
    totalStock,
    colors: req.body.colors || ['Black'],
    isFeatured: Boolean(req.body.isFeatured),
    isNewArrival: Boolean(req.body.isNewArrival),
    isBestSeller: Boolean(req.body.isBestSeller),
    isActive: req.body.isActive !== undefined ? Boolean(req.body.isActive) : true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  db.products.unshift(newProduct);
  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'নতুন পণ্য যোগ', 'Products', `নতুন পণ্য যুক্ত করা হয়েছে: ${newProduct.name} (SKU: ${newProduct.sku})`);
  res.json(newProduct);
});

app.put('/api/products/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const index = db.products.findIndex((p) => p.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'পণ্য পাওয়া যায়নি' });

  const totalStock = Array.isArray(req.body.sizes)
    ? req.body.sizes.reduce((acc: number, curr: any) => acc + (Number(curr.stock) || 0), 0)
    : req.body.totalStock !== undefined ? Number(req.body.totalStock) : db.products[index].totalStock;

  db.products[index] = {
    ...db.products[index],
    ...req.body,
    totalStock,
    updatedAt: new Date().toISOString()
  };

  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'পণ্য আপডেট', 'Products', `পণ্য আপডেট করা হয়েছে: ${db.products[index].name} (SKU: ${db.products[index].sku})`);
  res.json(db.products[index]);
});

app.delete('/api/products/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const p = db.products.find((prod) => prod.id === req.params.id);
  db.products = db.products.filter((prod) => prod.id !== req.params.id);
  dataStore.saveDatabase();
  if (p) {
    dataStore.logActivity('অ্যাডমিন', 'পণ্য মুছে ফেলা', 'Products', `পণ্য মুছে ফেলা হয়েছে: ${p.name}`);
  }
  res.json({ success: true });
});

// Categories
app.get('/api/categories', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  res.json(db.categories);
});

app.post('/api/categories', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const newCat: Category = {
    id: `cat-${Date.now()}`,
    name: req.body.name || 'New Category',
    banglaName: req.body.banglaName || req.body.name,
    slug: req.body.name ? req.body.name.toLowerCase().replace(/[^a-z0-9]+/g, '-') : `cat-${Date.now()}`,
    image: req.body.image || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400',
    icon: req.body.icon || 'Footprints',
    itemCount: 0,
    isActive: true,
    order: db.categories.length + 1
  };
  db.categories.push(newCat);
  dataStore.saveDatabase();
  res.json(newCat);
});

app.put('/api/categories/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const index = db.categories.findIndex((c) => c.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'ক্যাটাগরি পাওয়া যায়নি' });

  db.categories[index] = { ...db.categories[index], ...req.body };
  dataStore.saveDatabase();
  res.json(db.categories[index]);
});

app.delete('/api/categories/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.categories = db.categories.filter((c) => c.id !== req.params.id);
  dataStore.saveDatabase();
  res.json({ success: true });
});

// ==========================================
// 4. ORDERS MANAGEMENT
// ==========================================
app.get('/api/orders', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  res.json(db.orders);
});

app.post('/api/orders', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const orderCount = db.orders.length + 1001;
  const orderId = `${db.systemSettings.invoicePrefix || 'FS-'}${orderCount}`;

  const newOrder: Order = {
    id: orderId,
    customerName: req.body.customerName || 'সম্মানিত গ্রাহক',
    customerPhone: req.body.customerPhone || '',
    customerAddress: req.body.customerAddress || '',
    deliveryArea: req.body.deliveryArea || 'feni_city',
    district: req.body.district || (req.body.deliveryArea === 'feni_city' ? 'ফেনী (Feni)' : 'বাইরে'),
    items: req.body.items || [],
    subtotal: Number(req.body.subtotal) || 0,
    deliveryCharge: Number(req.body.deliveryCharge) || 0,
    discount: Number(req.body.discount) || 0,
    total: Number(req.body.total) || 0,
    codAmount: Number(req.body.total) || 0,
    paymentMethod: req.body.paymentMethod || 'cod',
    paymentStatus: req.body.paymentStatus || 'unpaid',
    status: db.systemSettings.autoConfirmOrders ? 'confirmed' : 'pending',
    customerNotes: req.body.customerNotes || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timeline: [
      {
        status: db.systemSettings.autoConfirmOrders ? 'confirmed' : 'pending',
        timestamp: new Date().toISOString(),
        note: 'অনলাইন চেকআউটের মাধ্যমে সফলভাবে অর্ডার সাবমিট করা হয়েছে।'
      }
    ]
  };

  // Decrement stock for ordered items
  for (const item of newOrder.items) {
    const prod = db.products.find((p) => p.id === item.productId || p.sku === item.sku);
    if (prod) {
      if (Array.isArray(prod.sizes)) {
        const sizeEntry = prod.sizes.find((s) => s.size === item.size);
        if (sizeEntry && sizeEntry.stock >= item.quantity) {
          sizeEntry.stock -= item.quantity;
        }
        prod.totalStock = prod.sizes.reduce((sum, s) => sum + s.stock, 0);
      } else {
        prod.totalStock = Math.max(0, prod.totalStock - item.quantity);
      }
    }
  }

  db.orders.unshift(newOrder);
  dataStore.saveDatabase();
  dataStore.logActivity('গ্রাহক', 'নতুন অর্ডার', 'Orders', `নতুন অর্ডার তৈরি হয়েছে: #${newOrder.id} - ${newOrder.customerName} (৳${newOrder.total})`);

  res.status(201).json(newOrder);
});

app.put('/api/orders/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const index = db.orders.findIndex((o) => o.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'অর্ডার পাওয়া যায়নি' });

  const oldStatus = db.orders[index].status;
  const newStatus = req.body.status || oldStatus;

  const timeline = [...db.orders[index].timeline];
  if (newStatus !== oldStatus) {
    timeline.push({
      status: newStatus,
      timestamp: new Date().toISOString(),
      note: req.body.statusNote || `স্ট্যাটাস পরিবর্তন: ${oldStatus} থেকে ${newStatus}`
    });
  }

  db.orders[index] = {
    ...db.orders[index],
    ...req.body,
    timeline,
    updatedAt: new Date().toISOString()
  };

  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'অর্ডার আপডেট', 'Orders', `অর্ডার #${db.orders[index].id} হালনাগাদ করা হয়েছে (স্ট্যাটাস: ${newStatus})`);
  res.json(db.orders[index]);
});

app.patch('/api/orders/:id/status', (req: Request, res: Response) => {
  const { status, note } = req.body;
  const db = dataStore.getDatabase();
  const index = db.orders.findIndex((o) => o.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'অর্ডার পাওয়া যায়নি' });

  db.orders[index].status = status;
  db.orders[index].updatedAt = new Date().toISOString();
  db.orders[index].timeline.push({
    status,
    timestamp: new Date().toISOString(),
    note: note || `অর্ডার স্ট্যাটাস পরিবর্তন করা হয়েছে: ${status}`
  });

  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'অর্ডার স্ট্যাটাস পরিবর্তন', 'Orders', `অর্ডার #${req.params.id} স্ট্যাটাস: ${status}`);
  res.json(db.orders[index]);
});

app.delete('/api/orders/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.orders = db.orders.filter((o) => o.id !== req.params.id);
  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'অর্ডার মুছে ফেলা', 'Orders', `অর্ডার #${req.params.id} ডিলিট করা হয়েছে`);
  res.json({ success: true });
});

// ==========================================
// 5. STEADFAST COURIER INTEGRATION
// ==========================================
app.get('/api/courier/steadfast/settings', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  // Return settings with partially masked secret key for security
  const safeSettings = {
    ...db.steadfastSettings,
    secretKeyMasked: db.steadfastSettings.secretKey ? '••••••••' + db.steadfastSettings.secretKey.slice(-4) : '',
    hasKeys: Boolean(db.steadfastSettings.apiKey && db.steadfastSettings.secretKey)
  };
  res.json(safeSettings);
});

app.put('/api/courier/steadfast/settings', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.steadfastSettings = {
    ...db.steadfastSettings,
    ...req.body
  };
  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'স্টেডফাস্ট সেটিংস পরিবর্তন', 'Courier', 'স্টেডফাস্ট কুরিয়ার কনফিগারেশন আপডেট করা হয়েছে।');
  res.json({ success: true, message: 'স্টেডফাস্ট কুরিয়ার সেটিংস সফলভাবে সেভ হয়েছে।' });
});

app.post('/api/courier/steadfast/book', async (req: Request, res: Response) => {
  const { orderId, codAmount, note } = req.body;
  const db = dataStore.getDatabase();
  const order = db.orders.find((o) => o.id === orderId);

  if (!order) {
    return res.status(404).json({ error: 'অর্ডার পাওয়া যায়নি' });
  }

  const { apiKey, secretKey, baseUrl, isLive } = db.steadfastSettings;
  const finalCod = Number(codAmount) !== undefined ? Number(codAmount) : order.codAmount;

  // Real Steadfast API Call if live mode and keys provided
  if (isLive && apiKey && secretKey) {
    try {
      const response = await fetch(`${baseUrl || 'https://portal.steadfast.com.bd/api/v1'}/create_order`, {
        method: 'POST',
        headers: {
          'Api-Key': apiKey,
          'Secret-Key': secretKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          invoice: order.id,
          recipient_name: order.customerName,
          recipient_phone: order.customerPhone,
          recipient_address: order.customerAddress,
          cod_amount: finalCod,
          note: note || `FOOT STEPS SHOES Order #${order.id}`
        })
      });

      const result: any = await response.json();
      if (result.status === 200 && result.consignment) {
        order.courierName = 'steadfast';
        order.status = 'shipped';
        order.courierDetails = {
          consignmentId: result.consignment.consignment_id,
          trackingCode: result.consignment.tracking_code,
          courierStatus: result.consignment.status || 'in_review',
          bookedAt: new Date().toISOString(),
          deliveryCharge: order.deliveryCharge,
          codAmount: finalCod,
          notes: note || 'স্টেডফাস্টে বুক করা হয়েছে',
          lastChecked: new Date().toISOString()
        };
        order.timeline.push({
          status: 'shipped',
          timestamp: new Date().toISOString(),
          note: `অফিসিয়াল স্টেডফাস্ট কুরিয়ারে বুক করা হয়েছে। ট্র্যাকিং আইডি: ${result.consignment.tracking_code}`
        });

        dataStore.saveDatabase();
        dataStore.logActivity('অ্যাডমিন', 'স্টেডফাস্ট বুকিং (Live)', 'Courier', `অর্ডার #${order.id} বুক করা হয়েছে। CID: ${result.consignment.consignment_id}`);
        return res.json({ success: true, consignment: result.consignment });
      } else {
        return res.status(400).json({ error: result.message || 'স্টেডফাস্ট API ত্রুটি', details: result });
      }
    } catch (err: any) {
      console.error('Steadfast live API error', err);
      return res.status(500).json({ error: 'স্টেডফাস্ট সার্ভারে যোগাযোগ করা সম্ভব হয়নি: ' + err.message });
    }
  }

  // Realistic Simulation / Sandbox Mode
  // Generates genuine Steadfast format consignment for seamless testing and instant workflow
  const fakeConsignmentId = Math.floor(8000000 + Math.random() * 1999999);
  const fakeTrackingCode = `STDFST-${fakeConsignmentId}`;

  order.courierName = 'steadfast';
  order.status = 'shipped';
  order.courierDetails = {
    consignmentId: fakeConsignmentId,
    trackingCode: fakeTrackingCode,
    courierStatus: 'in_review',
    bookedAt: new Date().toISOString(),
    deliveryCharge: order.deliveryCharge || 80,
    codAmount: finalCod,
    notes: note || 'স্টেডফাস্ট কুরিয়ারে বুকিং নিশ্চিত হয়েছে',
    lastChecked: new Date().toISOString()
  };

  order.timeline.push({
    status: 'shipped',
    timestamp: new Date().toISOString(),
    note: `স্টেডফাস্ট কুরিয়ারে সফলভাবে পার্সেল বুক করা হয়েছে। ট্র্যাকিং কোড: ${fakeTrackingCode}`
  });

  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাডমিন', 'স্টেডফাস্ট বুকিং', 'Courier', `অর্ডার #${order.id} বুক করা হয়েছে। ট্র্যাকিং কোড: ${fakeTrackingCode}`);

  return res.json({
    success: true,
    message: isLive ? 'লাইভ মোড চালু নেই, ডেমো বুকিং তৈরি হয়েছে' : 'স্টেডফাস্ট কুরিয়ারে অর্ডার সফলভাবে বুক করা হয়েছে!',
    consignment: {
      consignment_id: fakeConsignmentId,
      tracking_code: fakeTrackingCode,
      status: 'in_review',
      invoice: order.id,
      recipient_name: order.customerName,
      cod_amount: finalCod
    }
  });
});

app.get('/api/courier/steadfast/status/:trackingCode', async (req: Request, res: Response) => {
  const { trackingCode } = req.params;
  const db = dataStore.getDatabase();
  const order = db.orders.find((o) => o.courierDetails?.trackingCode === trackingCode);

  const { apiKey, secretKey, baseUrl, isLive } = db.steadfastSettings;

  if (isLive && apiKey && secretKey) {
    try {
      const response = await fetch(`${baseUrl || 'https://portal.steadfast.com.bd/api/v1'}/status_by_trackingcode/${trackingCode}`, {
        headers: {
          'Api-Key': apiKey,
          'Secret-Key': secretKey
        }
      });
      const data: any = await response.json();
      if (data.status === 200) {
        if (order && order.courierDetails) {
          order.courierDetails.courierStatus = data.delivery_status;
          order.courierDetails.lastChecked = new Date().toISOString();
          dataStore.saveDatabase();
        }
        return res.json(data);
      }
    } catch (e) {
      console.error('Steadfast status fetch error', e);
    }
  }

  // Fallback status
  res.json({
    status: 200,
    delivery_status: order?.courierDetails?.courierStatus || 'in_review',
    tracking_code: trackingCode,
    updated_at: new Date().toISOString()
  });
});

// ==========================================
// 6. ACCOUNTING & FINANCIAL REPORTS
// ==========================================
app.get('/api/accounting/summary', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();

  // Delivered and Confirmed Sales
  const deliveredOrders = db.orders.filter((o) => o.status === 'delivered');
  const allCompletedOrders = db.orders.filter((o) => ['confirmed', 'processing', 'shipped', 'delivered'].includes(o.status));

  const totalDeliveredRevenue = deliveredOrders.reduce((sum, o) => sum + o.total, 0);
  const totalSalesRevenue = allCompletedOrders.reduce((sum, o) => sum + o.total, 0);

  // Cost of Goods Sold (COGS)
  const totalCOGS = deliveredOrders.reduce((sum, o) => {
    const orderCost = o.items.reduce((itemSum, item) => itemSum + (item.costPrice || item.price * 0.6) * item.quantity, 0);
    return sum + orderCost;
  }, 0);

  // Expenses
  const totalExpenses = db.expenses.reduce((sum, e) => sum + e.amount, 0);
  const totalSalaries = db.salaries.reduce((sum, s) => sum + s.amount + (s.bonus || 0), 0);
  const totalPurchases = db.purchases.reduce((sum, p) => sum + p.totalCost, 0);
  const purchasesPaid = db.purchases.reduce((sum, p) => sum + p.paidAmount, 0);
  const purchasesDue = db.purchases.reduce((sum, p) => sum + p.dueAmount, 0);

  // Customer Dues
  const totalCustomerDue = db.customerDues.filter((d) => !d.isSettled).reduce((sum, d) => sum + d.dueAmount, 0);

  // Stock Valuation
  let totalStockUnits = 0;
  let totalStockCost = 0;
  let totalStockRetail = 0;
  db.products.forEach((p) => {
    if (p.isActive) {
      totalStockUnits += p.totalStock;
      totalStockCost += p.totalStock * p.costPrice;
      totalStockRetail += p.totalStock * p.salePrice;
    }
  });

  // Courier Returned Loss
  const returnedOrders = db.orders.filter((o) => o.status === 'returned');
  const courierReturnLoss = returnedOrders.reduce((sum, o) => sum + (o.deliveryCharge || 80) * 1.5, 0);

  // Profit Calculation
  const grossProfit = totalDeliveredRevenue - totalCOGS;
  const netProfit = grossProfit - totalExpenses - totalSalaries - courierReturnLoss;

  // Account Balances
  const totalCashBank = db.accounts.reduce((sum, a) => sum + a.balance, 0);

  res.json({
    totalSalesRevenue,
    totalDeliveredRevenue,
    totalCOGS,
    grossProfit,
    netProfit,
    totalExpenses,
    totalSalaries,
    totalPurchases,
    purchasesPaid,
    purchasesDue,
    totalCustomerDue,
    totalStockUnits,
    totalStockCost,
    totalStockRetail,
    potentialProfit: totalStockRetail - totalStockCost,
    courierReturnLoss,
    totalCashBank,
    deliveredOrdersCount: deliveredOrders.length,
    returnedOrdersCount: returnedOrders.length,
    pendingOrdersCount: db.orders.filter((o) => o.status === 'pending').length
  });
});

// Purchases
app.get('/api/accounting/purchases', (req: Request, res: Response) => {
  res.json(dataStore.getDatabase().purchases);
});

app.post('/api/accounting/purchases', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const newPurchase: PurchaseRecord = {
    id: `pur-${Date.now()}`,
    supplierName: req.body.supplierName || 'সাপ্লায়ার',
    invoiceNo: req.body.invoiceNo || `PUR-${Date.now().toString().slice(-4)}`,
    itemsDescription: req.body.itemsDescription || 'জুতো ও চামড়া সামগ্রী',
    quantity: Number(req.body.quantity) || 1,
    totalCost: Number(req.body.totalCost) || 0,
    paidAmount: Number(req.body.paidAmount) || 0,
    dueAmount: Math.max(0, (Number(req.body.totalCost) || 0) - (Number(req.body.paidAmount) || 0)),
    paymentMethod: req.body.paymentMethod || 'ক্যাশ',
    date: req.body.date || new Date().toISOString().split('T')[0],
    notes: req.body.notes || ''
  };
  db.purchases.unshift(newPurchase);
  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাকাউন্টিং', 'ক্রয় রেকর্ড যোগ', 'Accounting', `ক্রয় চালান যোগ: ${newPurchase.supplierName} (৳${newPurchase.totalCost})`);
  res.json(newPurchase);
});

app.delete('/api/accounting/purchases/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.purchases = db.purchases.filter((p) => p.id !== req.params.id);
  dataStore.saveDatabase();
  res.json({ success: true });
});

// Expenses
app.get('/api/accounting/expenses', (req: Request, res: Response) => {
  res.json(dataStore.getDatabase().expenses);
});

app.post('/api/accounting/expenses', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const newExpense: ExpenseRecord = {
    id: `exp-${Date.now()}`,
    category: req.body.category || 'other',
    title: req.body.title || 'সাধারণ খরচ',
    amount: Number(req.body.amount) || 0,
    paymentMethod: req.body.paymentMethod || 'ক্যাশ',
    date: req.body.date || new Date().toISOString().split('T')[0],
    recipient: req.body.recipient || '',
    notes: req.body.notes || ''
  };
  db.expenses.unshift(newExpense);
  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাকাউন্টিং', 'খরচ এন্ট্রি', 'Accounting', `খরচ যোগ: ${newExpense.title} (৳${newExpense.amount})`);
  res.json(newExpense);
});

app.delete('/api/accounting/expenses/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.expenses = db.expenses.filter((e) => e.id !== req.params.id);
  dataStore.saveDatabase();
  res.json({ success: true });
});

// Salaries
app.get('/api/accounting/salaries', (req: Request, res: Response) => {
  res.json(dataStore.getDatabase().salaries);
});

app.post('/api/accounting/salaries', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const newSalary: SalaryRecord = {
    id: `sal-${Date.now()}`,
    staffName: req.body.staffName || 'স্টাফ',
    designation: req.body.designation || 'কর্মকর্তা',
    month: req.body.month || 'বর্তমান মাস',
    amount: Number(req.body.amount) || 0,
    bonus: Number(req.body.bonus) || 0,
    paymentStatus: req.body.paymentStatus || 'paid',
    paymentDate: req.body.paymentDate || new Date().toISOString().split('T')[0],
    paymentMethod: req.body.paymentMethod || 'ক্যাশ',
    notes: req.body.notes || ''
  };
  db.salaries.unshift(newSalary);
  dataStore.saveDatabase();
  dataStore.logActivity('অ্যাকাউন্টিং', 'বেতন প্রদান এন্ট্রি', 'Accounting', `বেতন প্রদান: ${newSalary.staffName} (৳${newSalary.amount})`);
  res.json(newSalary);
});

app.delete('/api/accounting/salaries/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.salaries = db.salaries.filter((s) => s.id !== req.params.id);
  dataStore.saveDatabase();
  res.json({ success: true });
});

// Customer dues
app.get('/api/accounting/customer-dues', (req: Request, res: Response) => {
  res.json(dataStore.getDatabase().customerDues);
});

app.post('/api/accounting/customer-dues', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const newDue: CustomerDueRecord = {
    id: `due-${Date.now()}`,
    customerName: req.body.customerName || 'গ্রাহক',
    customerPhone: req.body.customerPhone || '',
    orderId: req.body.orderId || '',
    totalBill: Number(req.body.totalBill) || 0,
    paidAmount: Number(req.body.paidAmount) || 0,
    dueAmount: Number(req.body.dueAmount) || 0,
    dueDate: req.body.dueDate || '',
    isSettled: false,
    notes: req.body.notes || '',
    updatedAt: new Date().toISOString()
  };
  db.customerDues.unshift(newDue);
  dataStore.saveDatabase();
  res.json(newDue);
});

app.put('/api/accounting/customer-dues/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const index = db.customerDues.findIndex((d) => d.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'বাকি রেকর্ড পাওয়া যায়নি' });

  db.customerDues[index] = { ...db.customerDues[index], ...req.body, updatedAt: new Date().toISOString() };
  dataStore.saveDatabase();
  res.json(db.customerDues[index]);
});

// Accounts (Cash, bKash, Bank)
app.get('/api/accounting/accounts', (req: Request, res: Response) => {
  res.json(dataStore.getDatabase().accounts);
});

app.put('/api/accounting/accounts/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const index = db.accounts.findIndex((a) => a.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'অ্যাকাউন্ট পাওয়া যায়নি' });

  db.accounts[index] = { ...db.accounts[index], ...req.body, updatedAt: new Date().toISOString() };
  dataStore.saveDatabase();
  res.json(db.accounts[index]);
});

// ==========================================
// 7. CUSTOMERS & REVIEWS
// ==========================================
app.get('/api/customers', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  // Aggregate customers from orders
  const customerMap: { [phone: string]: any } = {};

  db.orders.forEach((o) => {
    const phone = o.customerPhone.trim();
    if (!customerMap[phone]) {
      customerMap[phone] = {
        phone,
        name: o.customerName,
        address: o.customerAddress,
        district: o.district,
        totalOrders: 0,
        totalSpent: 0,
        lastOrderDate: o.createdAt,
        orders: []
      };
    }
    customerMap[phone].totalOrders += 1;
    customerMap[phone].totalSpent += o.total;
    customerMap[phone].orders.push({
      id: o.id,
      date: o.createdAt,
      total: o.total,
      status: o.status
    });
  });

  res.json(Object.values(customerMap));
});

// Reviews
app.get('/api/reviews', (req: Request, res: Response) => {
  res.json(dataStore.getDatabase().reviews);
});

app.post('/api/reviews', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const newReview: CustomerReview = {
    id: `rev-${Date.now()}`,
    customerName: req.body.customerName || 'বেনামী গ্রাহক',
    location: req.body.location || 'ফেনী',
    rating: Number(req.body.rating) || 5,
    comment: req.body.comment || '',
    productName: req.body.productName || '',
    date: new Date().toISOString().split('T')[0],
    isApproved: req.body.isApproved !== undefined ? req.body.isApproved : true,
    isFeatured: Boolean(req.body.isFeatured)
  };
  db.reviews.unshift(newReview);
  dataStore.saveDatabase();
  res.json(newReview);
});

app.put('/api/reviews/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  const index = db.reviews.findIndex((r) => r.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'রিভিউ পাওয়া যায়নি' });

  db.reviews[index] = { ...db.reviews[index], ...req.body };
  dataStore.saveDatabase();
  res.json(db.reviews[index]);
});

app.delete('/api/reviews/:id', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  db.reviews = db.reviews.filter((r) => r.id !== req.params.id);
  dataStore.saveDatabase();
  res.json({ success: true });
});

// ==========================================
// 8. ACTIVITY LOGS, BACKUP & RESTORE
// ==========================================
app.get('/api/activity-logs', (req: Request, res: Response) => {
  res.json(dataStore.getDatabase().activityLogs);
});

app.get('/api/backup', (req: Request, res: Response) => {
  const db = dataStore.getDatabase();
  res.setHeader('Content-Disposition', `attachment; filename=footsteps_backup_${Date.now()}.json`);
  res.setHeader('Content-Type', 'application/json');
  res.send(JSON.stringify(db, null, 2));
});

app.post('/api/restore', (req: Request, res: Response) => {
  const restoredData = req.body;
  if (!restoredData || !restoredData.products || !restoredData.settings) {
    return res.status(400).json({ error: 'ভুল ব্যাকআপ ফাইল ফরম্যাট।' });
  }

  dataStore.saveDatabase(restoredData);
  dataStore.logActivity('অ্যাডমিন', 'ডাটাবেজ রিস্টোর', 'Security', 'সিস্টেম ডাটাবেজ ব্যাকআপ ফাইল থেকে রিস্টোর করা হয়েছে।');
  res.json({ success: true, message: 'ডাটাবেজ সফলভাবে রিস্টোর হয়েছে!' });
});

// ==========================================
// VITE DEV SERVER / PRODUCTION STATIC SERVING
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[FOOT STEPS SHOES] Full-stack Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
