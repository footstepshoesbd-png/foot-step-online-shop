import fs from 'fs';
import path from 'path';
import { FullDatabase } from '../src/types/index.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

export const defaultDatabase: FullDatabase = {
  settings: {
    brandName: 'FOOT STEPS SHOES',
    brandTagline: 'ফেনীর সেরা প্রিমিয়াম লেদার জুতো ও ক্যাজুয়াল কালেকশন',
    websiteTitle: 'FOOT STEPS SHOES - প্রিমিয়াম জুতোর বিশ্বস্ত ঠিকানা',
    metaDescription: 'ফেনী সদর ও সারা বাংলাদেশে অরিজিনাল লেদার জুতো, লোফার, কেডস এবং চামড়ার স্যান্ডেল দ্রুততম ডেলিভারি ও ক্যাশ অন ডেলিভারিতে অর্ডার করুন।',
    keywords: 'shoes feni, leather shoes bangladesh, formal shoes feni, footwear bd, loafers, sandals feni',
    logoUrl: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=150&auto=format&fit=crop&q=80',
    primaryColor: '#047857',
    accentColor: '#10B981',
    shopAddress: 'শপ নং ১২, গ্রিন টাওয়ার (২য় তলা), ট্রাঙ্ক রোড, ফেনী সদর, ফেনী',
    shopCity: 'ফেনী',
    openingHours: 'সকাল ১০:০০ টা - রাত ১০:০০ টা (প্রতিদিন খোলা)',
    phoneNumber: '01819-876543',
    secondaryPhone: '01712-345678',
    whatsappNumber: '+8801819876543',
    email: 'footstepshoesbd@gmail.com',
    facebookUrl: 'https://facebook.com/footstepsshoesbd',
    instagramUrl: 'https://instagram.com/footstepsshoesbd',
    youtubeUrl: 'https://youtube.com',
    tiktokUrl: 'https://tiktok.com',
    announcementText: '🔥 ধামাকা অফার: ২,৫০০ টাকার অর্ডারে সারা বাংলাদেশে ফ্রি ডেলিভারি! ফেনী সিটিতে হোম ডেলিভারি মাত্র ৮০ টাকা।',
    announcementActive: true,
    footerAbout: 'FOOT STEPS SHOES - ফেনীর শীর্ষস্থানীয় প্রিমিয়াম লেদার ফুটওয়্যার ব্র্যান্ড। আমরা গ্রাহকদের দিই শতভাগ জেনুইন লেদার, সেরা ফিনিশিং এবং সর্বোচ্চ আরামদায়ক জুতো।',
    copyrightText: '© 2026 FOOT STEPS SHOES. সর্বস্বত্ব সংরক্ষিত। ফেনী, বাংলাদেশ।',
    aboutUsContent: {
      title: 'আমাদের গল্প ও গুণগত মান',
      description: 'FOOT STEPS SHOES ফেনী ট্রাঙ্ক রোডে শুরু হয়েছিল একটি লক্ষ্য নিয়ে—সবার কাছে সেরা মানের টেকসই এবং আরামদায়ক চামড়ার জুতো সুলভ মূল্যে পৌঁছে দেওয়া। প্রতিটি জুতো অত্যন্ত যত্ন সহকারে দক্ষ কারিগর দ্বারা প্রস্তুত করা হয়।',
      experienceYears: '১০+ বছর',
      happyCustomers: '১৫,০০০+',
      qualityGuarantee: '১০০% অরিজিনাল লেদার',
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80'
    }
  },
  deliverySettings: {
    feniCityCharge: 80,
    outsideFeniCharge: 140,
    expressCharge: 150,
    freeDeliveryEnabled: true,
    freeDeliveryThreshold: 2500,
    minOrderAmount: 300,
    estimatedTimeFeni: '২৪-৪৮ ঘন্টা',
    estimatedTimeOutside: '২-৪ দিন',
    deliveryInstructions: 'ডেলিভারি ম্যানের সামনে পার্সেলটি খুলে চেক করে মূল্য পরিশোধ করুন। কোনো সমস্যা হলে তৎক্ষণাৎ রিটার্ন করার সুযোগ রয়েছে।',
    returnPolicyText: 'সাইজে সমস্যা হলে বা কোনো ডিফেক্ট থাকলে ৭ দিনের মধ্যে ফ্রেন্ডলি এক্সচেঞ্জ গ্যারান্টি। কোনো অতিরিক্ত ঝামেলা ছাড়াই পরিবর্তনযোগ্য।',
    customDistrictCharges: [
      { district: 'ঢাকা (Dhaka)', charge: 120 },
      { district: 'চট্টগ্রাম (Chittagong)', charge: 120 },
      { district: 'সিলেট (Sylhet)', charge: 140 },
      { district: 'রাজশাহী (Rajshahi)', charge: 140 },
      { district: 'খুলনা (Khulna)', charge: 140 },
      { district: 'বরিশাল (Barisal)', charge: 140 },
      { district: 'রংপুর (Rangpur)', charge: 140 },
      { district: 'ময়মনসিংহ (Mymensingh)', charge: 140 },
      { district: 'কুমিল্লা (Cumilla)', charge: 100 },
      { district: 'নোয়াখালী (Noakhali)', charge: 100 }
    ]
  },
  steadfastSettings: {
    apiKey: '',
    secretKey: '',
    baseUrl: 'https://portal.steadfast.com.bd/api/v1',
    senderName: 'FOOT STEPS SHOES',
    senderPhone: '01819876543',
    senderAddress: 'Shop 12, Green Tower, Trunk Road, Feni',
    isLive: false,
    autoBookOnConfirm: false
  },
  systemSettings: {
    invoicePrefix: 'FS-',
    autoConfirmOrders: false,
    enableSMS: false,
    smsApiKey: '',
    smsSenderId: '',
    taxPercentage: 0,
    taxEnabled: false,
    currencySymbol: '৳',
    tradeLicenseNo: 'TRAD/FENI/004821',
    tinNo: 'TIN-9842104928'
  },
  banners: [
    {
      id: 'banner-1',
      title: 'প্রিমিয়াম অরিজিনাল লেদার জুতো কালেকশন ২০২৬',
      subtitle: 'হাতে তৈরি খাঁটি চামড়ার জুতো, আরামদায়ক সোলে সারাদিনের প্রশান্তি। ফেনী সিটিতে হোম ডেলিভারি মাত্র ৮০ টাকা!',
      tag: '🔥 হট ট্রেন্ডিং ২০২৬',
      image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1200&auto=format&fit=crop&q=80',
      ctaText: 'কালেকশন দেখুন ও কিনুন',
      ctaLink: '#products',
      isActive: true,
      order: 1
    },
    {
      id: 'banner-2',
      title: 'এক্সক্লুসিভ ইতালিয়ান হ্যান্ডক্রাফটেড লোফার',
      subtitle: 'অফিস, পার্টি কিংবা ক্যাজুয়াল আড্ডা—আপনার ব্যক্তিত্বে আনবে রাজকীয় আভিজাত্য।',
      tag: '✨ ২৫% পর্যন্ত ছাড়',
      image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=1200&auto=format&fit=crop&q=80',
      ctaText: 'অফারটি লুফে নিন',
      ctaLink: '#products',
      isActive: true,
      order: 2
    },
    {
      id: 'banner-3',
      title: 'প্রিমিয়াম জেনুইন লেদার স্যান্ডেল',
      subtitle: 'চরম গরমেও সর্বোচ্চ আরাম ও ডিউরেবিলিটি। প্রতিটি পদক্ষেপে রাজকীয় ফিল।',
      tag: '⭐ গ্রাহকদের পছন্দের শীর্ষে',
      image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=1200&auto=format&fit=crop&q=80',
      ctaText: 'স্যান্ডেল দেখুন',
      ctaLink: '#products',
      isActive: true,
      order: 3
    }
  ],
  sections: [
    { id: 'sec-hero', key: 'hero', name: 'হিরো স্লাইডার ব্যানার', title: 'হিরো ব্যানার', isVisible: true, order: 1 },
    { id: 'sec-categories', key: 'categories', name: 'ক্যাটাগরি বার', title: 'জনপ্রিয় ক্যাটাগরি সমূহ', subtitle: 'আপনার পছন্দের ক্যাটাগরি বেছে নিন', isVisible: true, order: 2 },
    { id: 'sec-features', key: 'features', name: 'কেন আমাদের নির্বাচন করবেন', title: 'আমাদের বিশেষত্ব ও সুবিধা', subtitle: 'আমরা দিচ্ছি সেরা গুণগত মান ও সর্বোচ্চ সেবা', isVisible: true, order: 3 },
    { id: 'sec-products', key: 'products', name: 'পণ্য সমূহ', title: 'আমাদের ট্রেন্ডিং জুতো কালেকশন', subtitle: 'সবচেয়ে সেরা মানের জুতো সেরা দামে', isVisible: true, order: 4 },
    { id: 'sec-deal', key: 'deal', name: 'স্পেশাল ধামাকা অফার ব্যানার', title: 'লিমিটেড টাইম ধামাকা অফার', subtitle: 'আজই অর্ডার করুন এবং উপভোগ করুন আকর্ষণীয় মূল্যছাড়', isVisible: true, order: 5 },
    { id: 'sec-reviews', key: 'reviews', name: 'গ্রাহকদের মতামত ও রিভিউ', title: 'গ্রাহকরা আমাদের সম্পর্কে কী বলছেন', subtitle: '১৫,০০০+ সন্তুষ্ট গ্রাহকদের নির্ভরযোগ্য ভালোবাসায় আমরা ধন্য', isVisible: true, order: 6 },
    { id: 'sec-about', key: 'about', name: 'আমাদের সম্পর্কে', title: 'FOOT STEPS SHOES ফেনী', subtitle: 'চামড়ার জুতোর ঐতিহ্যে আধুনিকতার ছোঁয়া', isVisible: true, order: 7 },
    { id: 'sec-contact', key: 'contact', name: 'শপ লোকেশন ও যোগাযোগ', title: 'আমাদের শোরুমে সরাসরি আসুন', subtitle: 'ফেনী ট্রাঙ্ক রোডে অবস্থিত আমাদের আউটলেটে আপনাকে স্বাগতম', isVisible: true, order: 8 }
  ],
  categories: [
    {
      id: 'cat-formal',
      name: 'Formal Shoes',
      banglaName: 'ফরমাল শু',
      slug: 'formal-shoes',
      image: 'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=400&auto=format&fit=crop&q=80',
      icon: 'Briefcase',
      itemCount: 8,
      isActive: true,
      order: 1
    },
    {
      id: 'cat-loafers',
      name: 'Leather Loafers',
      banglaName: 'লেদার লোফার',
      slug: 'leather-loafers',
      image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=400&auto=format&fit=crop&q=80',
      icon: 'Footprints',
      itemCount: 12,
      isActive: true,
      order: 2
    },
    {
      id: 'cat-sandals',
      name: 'Leather Sandals',
      banglaName: 'লেদার স্যান্ডেল',
      slug: 'leather-sandals',
      image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=400&auto=format&fit=crop&q=80',
      icon: 'Sun',
      itemCount: 10,
      isActive: true,
      order: 3
    },
    {
      id: 'cat-sneakers',
      name: 'Sneakers & Sports',
      banglaName: 'স্নিকার্স ও কেডস',
      slug: 'sneakers-sports',
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&auto=format&fit=crop&q=80',
      icon: 'Activity',
      itemCount: 15,
      isActive: true,
      order: 4
    },
    {
      id: 'cat-boots',
      name: 'Leather Boots',
      banglaName: 'লেদার বুট',
      slug: 'leather-boots',
      image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=400&auto=format&fit=crop&q=80',
      icon: 'Shield',
      itemCount: 6,
      isActive: true,
      order: 5
    },
    {
      id: 'cat-nagra',
      name: 'Traditional Nagra',
      banglaName: 'ট্রেডিশনাল নাগরা',
      slug: 'traditional-nagra',
      image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=400&auto=format&fit=crop&q=80',
      icon: 'Sparkles',
      itemCount: 5,
      isActive: true,
      order: 6
    }
  ],
  products: [
    {
      id: 'prod-101',
      sku: 'FS-101',
      name: 'Royal Italian Leather Formal Oxford',
      banglaName: 'রয়্যাল ইটালিয়ান লেদার ফরমাল অক্সফোর্ড শু - ব্ল্যাক',
      slug: 'royal-italian-leather-formal-oxford',
      description: '১০০% অরিজিনাল কাউ লেদার দিয়ে প্রস্তুত এই ফরমাল অক্সফোর্ড শু। প্রিমিয়াম ফিনিশিং, আরামদায়ক ইনসোল এবং অ্যান্টি-স্কিড রাবার সোল এটিকে করেছে অনন্য। অফিস, বিয়ে বা যেকোনো ফরমাল ইভেন্টের জন্য সেরা চয়েস।',
      features: ['১০০% জেনুইন কাউ লেদার আপার', 'অ্যান্টি-স্লিপ হাই কোয়ালিটি রাবার সোল', 'মেমোরি ফোম কমফোর্ট ইনসোল', 'ডিউরেবল হ্যান্ড স্টিচ ফিনিশিং'],
      category: 'cat-formal',
      regularPrice: 2850,
      salePrice: 2250,
      costPrice: 1400,
      images: [
        'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=600&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600&auto=format&fit=crop&q=80'
      ],
      sizes: [
        { size: '39', stock: 8 },
        { size: '40', stock: 12 },
        { size: '41', stock: 15 },
        { size: '42', stock: 10 },
        { size: '43', stock: 6 },
        { size: '44', stock: 4 }
      ],
      totalStock: 55,
      colors: ['Black', 'Dark Brown'],
      isFeatured: true,
      isNewArrival: false,
      isBestSeller: true,
      isActive: true,
      createdAt: '2026-03-01T10:00:00Z',
      updatedAt: '2026-03-01T10:00:00Z'
    },
    {
      id: 'prod-102',
      sku: 'FS-102',
      name: 'Executive Handcrafted Leather Loafer',
      banglaName: 'এক্সিকিউটিভ হ্যান্ডক্রাফটেড লেদার লোফার - চকোলেট ব্রাউন',
      slug: 'executive-handcrafted-leather-loafer',
      description: 'অত্যন্ত এলিগেন্ট লুকের স্লিপ-অন লোফার। সফট চামড়ার ফ্লেক্সিবল গঠন আপনার পায়ে দেবে অতুলনীয় প্রশান্তি। দীর্ঘ সময় ব্যবহারের পরেও পায়ে ক্লান্তি আসবে না।',
      features: ['আমদানিকৃত টপ গ্রেইন লেদার', 'সুপার ফ্লেক্সিবল লাইটওয়েট সোল', 'সফট কুশন ইনসোল', 'প্রিমিয়াম মেটাল বাকল ডিজাইন'],
      category: 'cat-loafers',
      regularPrice: 2600,
      salePrice: 1990,
      costPrice: 1200,
      images: [
        'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=600&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=600&auto=format&fit=crop&q=80'
      ],
      sizes: [
        { size: '39', stock: 5 },
        { size: '40', stock: 9 },
        { size: '41', stock: 14 },
        { size: '42', stock: 11 },
        { size: '43', stock: 7 },
        { size: '44', stock: 3 }
      ],
      totalStock: 49,
      colors: ['Chocolate Brown', 'Black'],
      isFeatured: true,
      isNewArrival: true,
      isBestSeller: true,
      isActive: true,
      createdAt: '2026-03-02T10:00:00Z',
      updatedAt: '2026-03-02T10:00:00Z'
    },
    {
      id: 'prod-103',
      sku: 'FS-103',
      name: 'Premium Genuine Leather Two-Strap Sandal',
      banglaName: 'প্রিমিয়াম জেনুইন লেদার টু-স্ট্র্যাপ স্যান্ডেল',
      slug: 'premium-genuine-leather-two-strap-sandal',
      description: 'প্রতিদিনের আরামদায়ক চলাফেরার জন্য খাঁটি চামড়ার স্যান্ডেল। উন্নত গ্রিপ যুক্ত সোল এবং টেকসই সেলাই যা পানিতেও সহজে নষ্ট হয় না।',
      features: ['খাঁটি ফুল গ্রেইন লেদার', 'শক্তিশালী গ্রিপ যুক্ত নন-স্লিপ সোল', 'ওয়াটার রেজিসটেন্ট ট্রিটেড লেদার', 'ডাবল স্টিচ কনস্ট্রাকশন'],
      category: 'cat-sandals',
      regularPrice: 1650,
      salePrice: 1250,
      costPrice: 750,
      images: [
        'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=600&auto=format&fit=crop&q=80'
      ],
      sizes: [
        { size: '39', stock: 10 },
        { size: '40', stock: 15 },
        { size: '41', stock: 20 },
        { size: '42', stock: 18 },
        { size: '43', stock: 12 },
        { size: '44', stock: 5 }
      ],
      totalStock: 80,
      colors: ['Tan Brown', 'Dark Black'],
      isFeatured: true,
      isNewArrival: false,
      isBestSeller: true,
      isActive: true,
      createdAt: '2026-03-03T10:00:00Z',
      updatedAt: '2026-03-03T10:00:00Z'
    },
    {
      id: 'prod-104',
      sku: 'FS-104',
      name: 'Ultra-Light Breathable Sport Sneaker',
      banglaName: 'আল্ট্রা-লাইট স্পোর্টস স্নিকার্স - ব্ল্যাক & হোয়াইট',
      slug: 'ultra-light-breathable-sport-sneaker',
      description: 'রানিং, জিম ও ক্যাজুয়াল পোশাকের সাথে দারুণ মানানসই আল্ট্রা লাইটওয়েট স্নিকার্স। ব্রিদেবল মেশ ফেব্রিক সারাদিন পা রাখবে ঠাণ্ডা ও ঘামমুক্ত।',
      features: ['ব্রিদেবল এয়ার মেশ ফেব্রিক', 'শক-অ্যাবজরবিং ইভা (EVA) কুশন সোল', 'লাইটওয়েট মাত্র ৩৫০ গ্রাম', 'ফ্যাশনিস্ট মডার্ন অ্যাথলেটিক কাট'],
      category: 'cat-sneakers',
      regularPrice: 2200,
      salePrice: 1690,
      costPrice: 950,
      images: [
        'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=600&auto=format&fit=crop&q=80'
      ],
      sizes: [
        { size: '39', stock: 4 },
        { size: '40', stock: 10 },
        { size: '41', stock: 12 },
        { size: '42', stock: 8 },
        { size: '43', stock: 5 },
        { size: '44', stock: 2 }
      ],
      totalStock: 41,
      colors: ['Black & White', 'All White', 'Navy Blue'],
      isFeatured: false,
      isNewArrival: true,
      isBestSeller: false,
      isActive: true,
      createdAt: '2026-03-04T10:00:00Z',
      updatedAt: '2026-03-04T10:00:00Z'
    },
    {
      id: 'prod-105',
      sku: 'FS-105',
      name: 'Classic Suede Tassel Loafer',
      banglaName: 'ক্লাসিক সোয়েড ট্যাসেল লোফার - রয়্যাল নেভি ব্লু',
      slug: 'classic-suede-tassel-loafer',
      description: 'অভিজাত্যের প্রতীক রয়্যাল নেভি ব্লু সোয়েড লেদার লোফার। ক্লাসিক ট্যাসেল ডিজাইন যেকোনো পার্টি বা বিয়েতে আপনাকে করবে সবার চেয়ে আলাদা।',
      features: ['প্রিমিয়াম ভেলভেট সোয়েড লেদার', 'হ্যান্ডক্রাফটেড ট্যাসেল ডেকোরেশন', 'নরম কুশন ফুটবেড', 'স্মুথ রাবার আউটসোল'],
      category: 'cat-loafers',
      regularPrice: 2750,
      salePrice: 2150,
      costPrice: 1300,
      images: [
        'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=600&auto=format&fit=crop&q=80'
      ],
      sizes: [
        { size: '39', stock: 3 },
        { size: '40', stock: 7 },
        { size: '41', stock: 10 },
        { size: '42', stock: 8 },
        { size: '43', stock: 4 },
        { size: '44', stock: 2 }
      ],
      totalStock: 34,
      colors: ['Navy Blue', 'Coffee Brown'],
      isFeatured: true,
      isNewArrival: true,
      isBestSeller: false,
      isActive: true,
      createdAt: '2026-03-05T10:00:00Z',
      updatedAt: '2026-03-05T10:00:00Z'
    },
    {
      id: 'prod-106',
      sku: 'FS-106',
      name: 'Handcrafted Traditional Leather Nagra',
      banglaName: 'হাতে তৈরি খাঁটি চামড়ার ঐতিহ্যবাহী নাগরা',
      slug: 'handcrafted-traditional-leather-nagra',
      description: 'পাঞ্জাবি কিংবা শেরওয়ানির সাথে খাঁটি ঐতিহ্যবাহী নাগরা জুতো। নরম চামড়ায় তৈরি হওয়ায় পায়ে কোনো ধরনের ফোস্কা বা ব্যথা হবে না।',
      features: ['১০০% নরম পিওর লেদার', 'ট্র্যাডিশনাল রয়েল কারুকাজ', 'হ্যান্ডমেড আরামদায়ক সোল', 'ঈদ ও বিয়ের সেরা চয়েস'],
      category: 'cat-nagra',
      regularPrice: 1800,
      salePrice: 1390,
      costPrice: 800,
      images: [
        'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600&auto=format&fit=crop&q=80'
      ],
      sizes: [
        { size: '39', stock: 6 },
        { size: '40', stock: 12 },
        { size: '41', stock: 14 },
        { size: '42', stock: 10 },
        { size: '43', stock: 5 }
      ],
      totalStock: 47,
      colors: ['Mustard Brown', 'Jet Black'],
      isFeatured: false,
      isNewArrival: false,
      isBestSeller: true,
      isActive: true,
      createdAt: '2026-03-06T10:00:00Z',
      updatedAt: '2026-03-06T10:00:00Z'
    },
    {
      id: 'prod-107',
      sku: 'FS-107',
      name: 'Urban Ankle Chelsea Leather Boot',
      banglaName: 'আরবান আংকেল চেলসি লেদার বুট - ডার্ক ট্যান',
      slug: 'urban-ankle-chelsea-leather-boot',
      description: 'স্মার্ট ও বোল্ড লুকের চেলসি বুট। উভয় পাশে ইলাস্টিক থাকার কারণে পরা ও খোলা অত্যন্ত সহজ। নিখুঁত চামড়ার টেক্সচার ও লং লাস্টিং কোয়ালিটি।',
      features: ['হেভি ডিউটি প্রিমিয়াম লেদার', 'প্রিমিয়াম সাইড ইলাস্টিক গোরিং', 'হেভি গ্রিপ কমব্যাট সোল', 'ওয়েল্টেড কনস্ট্রাকশন'],
      category: 'cat-boots',
      regularPrice: 3400,
      salePrice: 2850,
      costPrice: 1750,
      images: [
        'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=600&auto=format&fit=crop&q=80'
      ],
      sizes: [
        { size: '40', stock: 5 },
        { size: '41', stock: 8 },
        { size: '42', stock: 9 },
        { size: '43', stock: 4 }
      ],
      totalStock: 26,
      colors: ['Dark Tan', 'Classic Black'],
      isFeatured: true,
      isNewArrival: true,
      isBestSeller: false,
      isActive: true,
      createdAt: '2026-03-07T10:00:00Z',
      updatedAt: '2026-03-07T10:00:00Z'
    },
    {
      id: 'prod-108',
      sku: 'FS-108',
      name: 'Casual Slip-on Driving Moccasin',
      banglaName: 'ক্যাজুয়াল স্লিপ-অন ড্রাইভিং মকাসিন - অলিভ ট্যান',
      slug: 'casual-slip-on-driving-moccasin',
      description: 'অত্যন্ত হালকা ও ফ্লেক্সিবল মকাসিন শু। বিশেষ পেবলড রাবার সোল দীর্ঘক্ষণ ড্রাইভিং এবং হাঁটার সময় সর্বোচ্চ গ্রিপ এবং আরাম নিশ্চিত করে।',
      features: ['সফট বাটার লেদার', 'পেবলড গ্রিপ ড্রাইভিং সোল', 'আল্ট্রা ফ্লেক্সিবল ফ্রেম', 'ডেইলি ক্যাজুয়াল ওয়্যার'],
      category: 'cat-loafers',
      regularPrice: 2400,
      salePrice: 1850,
      costPrice: 1100,
      images: [
        'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=600&auto=format&fit=crop&q=80'
      ],
      sizes: [
        { size: '39', stock: 4 },
        { size: '40', stock: 8 },
        { size: '41', stock: 11 },
        { size: '42', stock: 9 },
        { size: '43', stock: 6 },
        { size: '44', stock: 3 }
      ],
      totalStock: 41,
      colors: ['Olive Tan', 'Espresso'],
      isFeatured: false,
      isNewArrival: false,
      isBestSeller: true,
      isActive: true,
      createdAt: '2026-03-08T10:00:00Z',
      updatedAt: '2026-03-08T10:00:00Z'
    }
  ],
  orders: [
    {
      id: 'FS-1001',
      customerName: 'তানভীর আহমেদ',
      customerPhone: '01812345678',
      customerAddress: 'বাসা নং ৪২, এসএসকে রোড, ট্রাঙ্ক রোড মোড়',
      deliveryArea: 'feni_city',
      district: 'ফেনী (Feni)',
      items: [
        {
          productId: 'prod-101',
          productName: 'রয়্যাল ইটালিয়ান লেদার ফরমাল অক্সফোর্ড শু - ব্ল্যাক',
          productImage: 'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=600&auto=format&fit=crop&q=80',
          sku: 'FS-101',
          size: '41',
          color: 'Black',
          price: 2250,
          costPrice: 1400,
          quantity: 1,
          total: 2250
        }
      ],
      subtotal: 2250,
      deliveryCharge: 80,
      discount: 0,
      total: 2330,
      codAmount: 2330,
      paymentMethod: 'cod',
      paymentStatus: 'unpaid',
      status: 'pending',
      customerNotes: 'বিকেলের দিকে ডেলিভারি দিলে ভালো হয়।',
      createdAt: '2026-03-08T14:20:00Z',
      updatedAt: '2026-03-08T14:20:00Z',
      timeline: [
        {
          status: 'pending',
          timestamp: '2026-03-08T14:20:00Z',
          note: 'অর্ডার সাবমিট করা হয়েছে।'
        }
      ]
    },
    {
      id: 'FS-1002',
      customerName: 'রাকিবুল হাসান',
      customerPhone: '01798765432',
      customerAddress: 'হোল্ডিং ৯, গ্রিন রোড, ধানমন্ডি',
      deliveryArea: 'outside_feni',
      district: 'ঢাকা (Dhaka)',
      items: [
        {
          productId: 'prod-102',
          productName: 'এক্সিকিউটিভ হ্যান্ডক্রাফটেড লেদার লোফার - চকোলেট ব্রাউন',
          productImage: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=600&auto=format&fit=crop&q=80',
          sku: 'FS-102',
          size: '42',
          color: 'Chocolate Brown',
          price: 1990,
          costPrice: 1200,
          quantity: 1,
          total: 1990
        }
      ],
      subtotal: 1990,
      deliveryCharge: 140,
      discount: 0,
      total: 2130,
      codAmount: 2130,
      paymentMethod: 'cod',
      paymentStatus: 'unpaid',
      status: 'shipped',
      courierName: 'steadfast',
      courierDetails: {
        consignmentId: 8842109,
        trackingCode: 'STDFST-8842109',
        courierStatus: 'in_review',
        bookedAt: '2026-03-08T11:00:00Z',
        deliveryCharge: 140,
        codAmount: 2130,
        notes: 'ঢাকা ধানমন্ডি হাবের পথে'
      },
      createdAt: '2026-03-07T18:15:00Z',
      updatedAt: '2026-03-08T11:00:00Z',
      timeline: [
        { status: 'pending', timestamp: '2026-03-07T18:15:00Z', note: 'অর্ডার গৃহীত' },
        { status: 'confirmed', timestamp: '2026-03-07T19:00:00Z', note: 'ফোনে নিশ্চিত করা হয়েছে' },
        { status: 'shipped', timestamp: '2026-03-08T11:00:00Z', note: 'স্টেডফাস্ট কুরিয়ারে বুক করা হয়েছে' }
      ]
    },
    {
      id: 'FS-1003',
      customerName: 'মেহেদী হাসান চৌধুরী',
      customerPhone: '01855223344',
      customerAddress: 'দোকান ৩, কলেজ রোড বাজার, ফেনী',
      deliveryArea: 'feni_city',
      district: 'ফেনী (Feni)',
      items: [
        {
          productId: 'prod-103',
          productName: 'প্রিমিয়াম জেনুইন লেদার টু-স্ট্র্যাপ স্যান্ডেল',
          productImage: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=600&auto=format&fit=crop&q=80',
          sku: 'FS-103',
          size: '41',
          color: 'Tan Brown',
          price: 1250,
          costPrice: 750,
          quantity: 2,
          total: 2500
        }
      ],
      subtotal: 2500,
      deliveryCharge: 0, // Free delivery reached (>= 2500)
      discount: 0,
      total: 2500,
      codAmount: 2500,
      paymentMethod: 'cod',
      paymentStatus: 'paid',
      status: 'delivered',
      courierName: 'steadfast',
      courierDetails: {
        consignmentId: 8839401,
        trackingCode: 'STDFST-8839401',
        courierStatus: 'delivered',
        bookedAt: '2026-03-06T10:00:00Z',
        deliveryCharge: 80,
        codAmount: 2500,
        notes: 'সফলভাবে ডেলিভারি সম্পন্ন ও ক্যাশ আদায়'
      },
      createdAt: '2026-03-05T09:30:00Z',
      updatedAt: '2026-03-07T15:40:00Z',
      timeline: [
        { status: 'pending', timestamp: '2026-03-05T09:30:00Z', note: 'অর্ডার প্লেস করা হয়েছে' },
        { status: 'confirmed', timestamp: '2026-03-05T10:00:00Z', note: 'কনফার্ম' },
        { status: 'shipped', timestamp: '2026-03-06T10:00:00Z', note: 'কুরিয়ারে হস্তান্তর' },
        { status: 'delivered', timestamp: '2026-03-07T15:40:00Z', note: 'গ্রাহক রিসিভ করেছেন' }
      ]
    }
  ],
  reviews: [
    {
      id: 'rev-1',
      customerName: 'আরিফুল ইসলাম',
      location: 'ফেনী সদর',
      rating: 5,
      comment: 'জুতোটা হাতে পেয়ে সত্যি মুগ্ধ হয়েছি! ১০০% অরিজিনাল চামড়া, একদম যেমন ছবিতে দেখেছি তেমনই। ফেনী সিটিতে পরদিনই পেয়েছি। ধন্যবাদ FOOT STEPS SHOES!',
      productName: 'রয়্যাল ইটালিয়ান লেদার ফরমাল অক্সফোর্ড শু',
      date: '২০২৬-০৩-০৪',
      isApproved: true,
      isFeatured: true
    },
    {
      id: 'rev-2',
      customerName: 'মাহমুদুল করিম',
      location: 'মাস্টারপাড়া, ফেনী',
      rating: 5,
      comment: 'লোফারটা খুবই নরম এবং আরামদায়ক। অফিসে সারা দিন পরে থাকার পরেও পায়ে কোনো ব্যথা হয় না। ফিনিশিং ও কালার খুব প্রিমিয়াম।',
      productName: 'এক্সিকিউটিভ হ্যান্ডক্রাফটেড লোফার',
      date: '২০২৬-০৩-০৫',
      isApproved: true,
      isFeatured: true
    },
    {
      id: 'rev-3',
      customerName: 'শামসুল হক',
      location: 'সোনাগাজী, ফেনী',
      rating: 5,
      comment: 'স্যান্ডেলের চামড়া ও সোলের কোয়ালিটি দুর্দান্ত। ডেলিভারি ম্যান খুব ভদ্র ছিলেন এবং সামনে দেখে ট্রায়াল দিয়ে টাকা পরিশোধ করতে পেরেছি।',
      productName: 'প্রিমিয়াম জেনুইন লেদার স্যান্ডেল',
      date: '২০২৬-০৩-০৬',
      isApproved: true,
      isFeatured: true
    },
    {
      id: 'rev-4',
      customerName: 'জাহিদুল ইসলাম',
      location: 'জিইসি মোড়, চট্টগ্রাম',
      rating: 5,
      comment: 'অনলাইনে জুতো কিনতে একটু দ্বিধায় ছিলাম, কিন্তু FOOT STEPS SHOES ভরসা রাখার মতো। সাইজ একদম পারফেক্ট এসেছে।',
      productName: 'আল্ট্রা-লাইট স্পোর্টস স্নিকার্স',
      date: '২০২৬-০৩-০৭',
      isApproved: true,
      isFeatured: true
    }
  ],
  purchases: [
    {
      id: 'pur-1',
      supplierName: 'ঢাকা ট্যানারি সাপ্লাইয়ার্স',
      invoiceNo: 'PUR-2026-081',
      itemsDescription: 'ইতালিয়ান ক্রাস্ট লেদার ও অক্সফোর্ড জুতো কালেকশন (৫০ জোড়া)',
      quantity: 50,
      totalCost: 70000,
      paidAmount: 50000,
      dueAmount: 20000,
      paymentMethod: 'ব্যাংক ট্রান্সফার',
      date: '2026-03-01',
      notes: 'বাকি ২০,০০০ টাকা পরবর্তী চালানের সময় পরিশোধ করা হবে।'
    },
    {
      id: 'pur-2',
      supplierName: 'রয়াল সোল ম্যানুফ্যাকচারিং',
      invoiceNo: 'PUR-2026-082',
      itemsDescription: 'অ্যান্টি-স্কিড রাবার সোল ও ইনসোল (১০০ পিস)',
      quantity: 100,
      totalCost: 25000,
      paidAmount: 25000,
      dueAmount: 0,
      paymentMethod: 'ক্যাশ',
      date: '2026-03-03',
      notes: 'সম্পূর্ণ বিল পরিশোধিত'
    }
  ],
  expenses: [
    {
      id: 'exp-1',
      category: 'rent',
      title: 'মার্চ মাসের দোকান ভাড়া (গ্রিন টাওয়ার)',
      amount: 15000,
      paymentMethod: 'ব্যাংক চেক',
      date: '2026-03-01',
      recipient: 'মার্কেট মালিক',
      notes: 'মাসিক দোকান ভাড়া পরিশোধ'
    },
    {
      id: 'exp-2',
      category: 'utility',
      title: 'শোরুম বিদ্যুৎ বিল',
      amount: 2800,
      paymentMethod: 'বিকাশ',
      date: '2026-03-04',
      recipient: 'পল্লী বিদ্যুৎ ফেনী'
    },
    {
      id: 'exp-3',
      category: 'packaging',
      title: 'প্রিমিয়াম জুতো বক্স ও শপিং ব্যাগ (৫০০ পিস)',
      amount: 6500,
      paymentMethod: 'ক্যাশ',
      date: '2026-03-05',
      recipient: 'ফেনী প্রিন্টিং প্রেস'
    },
    {
      id: 'exp-4',
      category: 'marketing',
      title: 'ফেসবুক পেজ বুস্টিং ও ডিজিটাল বিজ্ঞাপন',
      amount: 4500,
      paymentMethod: 'কার্ড',
      date: '2026-03-06',
      recipient: 'মেটা অ্যাডস'
    }
  ],
  salaries: [
    {
      id: 'sal-1',
      staffName: 'মো: সোহেল রানা',
      designation: 'শোরুম সেলস এক্সিকিউটিভ',
      month: 'ফেব্রুয়ারি ২০২৬',
      amount: 12000,
      bonus: 1000,
      paymentStatus: 'paid',
      paymentDate: '2026-03-01',
      paymentMethod: 'ক্যাশ',
      notes: 'বেতন ও সেলস ইনসেনটিভ পরিশোধ'
    },
    {
      id: 'sal-2',
      staffName: 'কামাল হোসেন',
      designation: 'অনলাইন অর্ডার ও প্যাকিং অফিসার',
      month: 'ফেব্রুয়ারি ২০২৬',
      amount: 10000,
      bonus: 500,
      paymentStatus: 'paid',
      paymentDate: '2026-03-01',
      paymentMethod: 'বিকাশ',
      notes: 'মাসিক বেতন পরিশোধ'
    }
  ],
  supplierPayments: [
    {
      id: 'sp-1',
      supplierName: 'ঢাকা ট্যানারি সাপ্লাইয়ার্স',
      billAmount: 70000,
      paidAmount: 50000,
      balanceDue: 20000,
      paymentMethod: 'ব্যাংক ট্রান্সফার',
      date: '2026-03-01',
      notes: 'ইনভয়েস PUR-2026-081 এর আংশিক পরিশোধ'
    }
  ],
  customerDues: [
    {
      id: 'due-1',
      customerName: 'জাহিদুল ইসলাম শামীম',
      customerPhone: '01833445566',
      orderId: 'FS-984',
      totalBill: 3500,
      paidAmount: 2000,
      dueAmount: 1500,
      dueDate: '2026-03-15',
      isSettled: false,
      notes: 'ফেনী শোরুম থেকে সরাসরি কেনা, বাকি টাকা আগামী সপ্তাহে দেবে।',
      updatedAt: '2026-03-02T12:00:00Z'
    }
  ],
  accounts: [
    {
      id: 'acc-cash',
      name: 'ক্যাশ ইন হ্যান্ড (দোকানের ড্রয়ার)',
      type: 'cash',
      balance: 18500,
      updatedAt: '2026-03-08T18:00:00Z'
    },
    {
      id: 'acc-bkash',
      name: 'বিকাশ মার্চেন্ট অ্যাকাউন্ট',
      type: 'bkash',
      accountNumber: '01819876543',
      balance: 42300,
      updatedAt: '2026-03-08T18:00:00Z'
    },
    {
      id: 'acc-nagad',
      name: 'নগদ পার্সোনাল / মার্চেন্ট',
      type: 'nagad',
      accountNumber: '01712345678',
      balance: 15400,
      updatedAt: '2026-03-08T18:00:00Z'
    },
    {
      id: 'acc-bank',
      name: 'ইসলামী ব্যাংক বাংলাদেশ (ফেনী শাখা)',
      type: 'bank',
      accountNumber: '2050183020094821',
      balance: 125000,
      updatedAt: '2026-03-08T18:00:00Z'
    }
  ],
  staff: [
    {
      id: 'staff-admin',
      username: 'admin',
      fullName: 'প্রধান অ্যাডমিন (মালিক)',
      phone: '01819876543',
      role: 'super_admin',
      isActive: true,
      password: 'admin', // default pin/pass
      createdAt: '2026-01-01T00:00:00Z'
    },
    {
      id: 'staff-manager',
      username: 'manager',
      fullName: 'ম্যানেজার সাহেব',
      phone: '01811223344',
      role: 'manager',
      isActive: true,
      password: 'admin',
      createdAt: '2026-01-15T00:00:00Z'
    },
    {
      id: 'staff-order',
      username: 'orderstaff',
      fullName: 'অর্ডার এক্সিকিউটিভ',
      phone: '01711223344',
      role: 'order_staff',
      isActive: true,
      password: 'admin',
      createdAt: '2026-02-01T00:00:00Z'
    }
  ],
  activityLogs: [
    {
      id: 'log-1',
      staffName: 'প্রধান অ্যাডমিন',
      action: 'সিস্টেম স্টার্ট',
      module: 'Security',
      details: 'FOOT STEPS SHOES ই-কমার্স সিস্টেম সফলভাবে শুরু হয়েছে।',
      timestamp: '2026-03-08T10:00:00Z'
    },
    {
      id: 'log-2',
      staffName: 'প্রধান অ্যাডমিন',
      action: 'পণ্য স্টক আপডেট',
      module: 'Products',
      details: 'FS-101 অক্সফোর্ড শু-এর নতুন স্টক ডাটাবেজে অন্তর্ভুক্ত করা হয়েছে।',
      timestamp: '2026-03-08T10:15:00Z'
    }
  ]
};

class DataStore {
  private db: FullDatabase;

  constructor() {
    this.ensureDataDir();
    this.db = this.loadDatabase();
  }

  private ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadDatabase(): FullDatabase {
    try {
      if (fs.existsSync(DB_FILE)) {
        const content = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(content);
        return {
          ...defaultDatabase,
          ...parsed,
          settings: { ...defaultDatabase.settings, ...(parsed.settings || {}) },
          deliverySettings: { ...defaultDatabase.deliverySettings, ...(parsed.deliverySettings || {}) },
          steadfastSettings: { ...defaultDatabase.steadfastSettings, ...(parsed.steadfastSettings || {}) },
          systemSettings: { ...defaultDatabase.systemSettings, ...(parsed.systemSettings || {}) }
        };
      }
    } catch (err) {
      console.error('Failed to parse database file, falling back to default', err);
    }
    this.saveDatabase(defaultDatabase);
    return JSON.parse(JSON.stringify(defaultDatabase));
  }

  public saveDatabase(data?: FullDatabase): void {
    try {
      this.ensureDataDir();
      if (data) {
        this.db = data;
      }
      const tempFile = `${DB_FILE}.tmp`;
      fs.writeFileSync(tempFile, JSON.stringify(this.db, null, 2), 'utf-8');
      fs.renameSync(tempFile, DB_FILE);
    } catch (err) {
      console.error('Failed to save database file', err);
    }
  }

  public getDatabase(): FullDatabase {
    return this.db;
  }

  public logActivity(staffName: string, action: string, module: string, details: string) {
    const newLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      staffName,
      action,
      module,
      details,
      timestamp: new Date().toISOString()
    };
    this.db.activityLogs.unshift(newLog);
    if (this.db.activityLogs.length > 500) {
      this.db.activityLogs = this.db.activityLogs.slice(0, 500);
    }
    this.saveDatabase();
  }
}

export const dataStore = new DataStore();
